# Sable Front — Campaign Edition 0.2

An original, offline **Godot 4.6 squad RTS for landscape mobile play**, combining a turn-based regional campaign with real-time combined-arms battles.

Command expeditionary armies across **15 connected provinces**, sustain them through regional markets and a supply network, and bring the surviving veterans back from battle. Capture **Iron Crown and at least nine provinces** while protecting your capital, **Haven**, to win.

![The Meridian regional campaign](docs/screenshots/campaign-v02.png)

## Download and run

- **Android:** download `SableFront-android.apk` from the repository's `downloads` branch and open it to install. Requires Android **7.0+ (API 24)**, ARM32 or ARM64, and OpenGL ES 3.0. This is a development-signed build. Version code 2 uses the same package and signing certificate as 0.1, allowing an upgrade that retains local saves.
- **Godot:** extract the source ZIP, import `SableFront/project.godot` in **Godot 4.6.3**, and press F5. No plugins or runtime dependencies are required.
- **Linux:** run the exported `SableFront-linux.x86_64`, or use `./tools/run.sh` for the source project. The wrapper keeps local saves and editor caches in ignored `.local/` directories unless XDG paths are already set.
- **Browser:** serve `builds/web` through an HTTP server, for example `python3 -m http.server 8000 --directory builds/web`, and open it in a WebGL 2-capable browser. Opening the HTML directly from disk does not work.

Choose **New Campaign** for the strategic game, **Continue Campaign** to resume, or **Quick Skirmish** for a standalone battle. Existing 0.1 skirmish saves remain available through **Continue Skirmish**. No account, server, ads, or Internet permission is required.

## The strategic campaign

You start with four provinces and two armies. Select an army card, tap a province, and confirm **March Here** or **Attack Province**. The atlas supports one-finger panning and two-finger zooming. Movement can cross friendly territory, but a hostile province must be the final destination. Each province crossed costs one movement point and one fuel. Each army has two movement points per turn, increased to three by Motorized Logistics. Another allied army blocks its province until it moves.

An attack opens a battle preview with both rosters and their strength. **Command Battle** deploys the actual army; **Auto Resolve** spends ammunition and supplies and calculates persistent wounds and casualties. A committed battle result applies only once. Attacking armies occupy the province only after victory. Defeated defenders retreat to an empty friendly neighbour when possible; trapped formations are lost.

Army sections retain **health, experience, kills, and identity** between battles. Tactical recruits return as new members of the same strategic army. The limit is **four allied armies**, each with **eight sections**. Reinforce wounded formations in supplied provinces or choose a stance:

| Stance | Effect |
| --- | --- |
| March | Full strategic movement. |
| Entrench | One movement point; +50 command strength when defending. |
| Replenish | No movement; restores 12% health per supplied turn, or 24% with Field Hospitals. |

Changing stances never refunds movement already spent. Isolated armies lose supply and eventually health. Provinces must trace an allied route back to Haven to produce income and cargo or receive recruitment and replacements. Captured provinces recover loyalty over time, improving their income.

**End Turn** collects income, pays upkeep, produces cargo, advances construction and research, and lets the opposition recruit and manoeuvre. Defensive battles interrupt this phase and return control when their results are resolved. Opposing armies use a finite credit budget, pay upkeep, require supply connections for recruitment, counter nearby armor, and protect their capital before advancing. Relaxed and Veteran difficulty change the economic pressure and aggression.

### Provinces and research

Develop Industry for income and commodity output, Fortifications for garrison sections and defensive command strength, and Supply Depots for extra supplies. Construction takes one or two turns, with one project per province and three levels per building. Construction is lost if the province falls.

Research projects take two or three turns. Signal Corps unlocks pathfinders and marksmen; Advanced Ordnance unlocks mortars and anti-tank guns; Mechanized Warfare unlocks tanks and flame pioneers. Motorized Logistics adds movement and reduces upkeep by 20%. Field Hospitals doubles replenishment recovery.

Each province has its own **commodity stock, demand, prices, and 24-step price history**. Local industry, supply isolation, recent fighting, shipments, disruptions, and purchases affect prices. Trade is available at Haven or where a supplied allied army is present. Moving between markets can create trade opportunities, while the buy/sell spread prevents free instant resale. Cargo capacity is 999 per commodity; full warehouses reject additional purchases before charging credits.

## Mobile battle controls

![Mobile tactical battle](docs/screenshots/campaign-battle-v02.png)

| Action | Touch | Mouse / keyboard |
| --- | --- | --- |
| Select section | Tap unit or bottom card | Click / keys 1–8 |
| Add/remove selections | MULTI toggle, then tap cards; or long-press units | Shift-click |
| Select platoon | Select All | Select All |
| Move or attack | Tap ground or visible enemy | Left- or right-click |
| Pan / zoom | One-finger drag / two-finger pinch | Drag or WASD / mouse wheel |
| Focus | Sector letters, MAP overview, or section card | Same; F focuses selection; Home focuses HQ |
| Retreat / hold | Command buttons | R / H |
| Ability | Tap ability, then a target in its range ring | Same; G toggles targeting |
| Pause | Pause button or Android Back | Esc / Space |

**Smart Move** is enabled by default: sections stop to engage enemies they encounter. Disable it to continue moving while firing with a movement penalty. Buttons and cards are larger than 0.1, the minimap is collapsible, and camera bounds prevent blank map edges. Settings provide larger controls, sound, haptics, 30/60 FPS, and reduced effects. The UI also applies the display safe area reported by Android. On Android, 30 FPS is the default. Battery and effects settings are also available during a paused battle.

Drag gestures never issue movement orders on release; pinching never issues orders or selects a province. Android Back closes menus, pauses battles, or offers an exit confirmation on the home screen.

### Twelve unit roles

| Section | Battlefield role | Ability |
| --- | --- | --- |
| Rifle section | Versatile infantry; captures and holds sectors. | Grenade |
| Assault section | Fast, powerful close-range flanker. | Grenade |
| MG section | Long-range suppression and defensive fire. | Grenade |
| Engineer section | Faster capture; repairs nearby vehicles using supplies. | Build sandbags |
| Scout carrier | Fast armored support; consumes fuel; cannot capture. | Smoke screen |
| Field medics | Heals nearby infantry out of combat. | Emergency field aid |
| Pathfinders | Fast capture and extended sight. | Timed reconnaissance flare |
| Marksman team | Long-range infantry specialist. | Aimed shot |
| Mortar battery | Indirect area fire; deployment delay and minimum range. | Heavy barrage |
| Anti-tank gun | Deployed armor-piercing fire. | Overcharged AP round |
| Vanguard tank | Strong frontal armor and cannon splash. | Smoke screen |
| Flame pioneers | Short-range area attack that ignores cover. | Persistent fire bomb |

Quick skirmishes permit all twelve roles. Campaign recruitment follows research unlocks. Garrisons without an attached field army cannot buy new tactical sections.

Units automatically fire at visible enemies within range and line of sight. Buildings block movement and direct fire. Mortars can fire over buildings if the enemy is spotted, but cannot shoot at point-blank range. Infantry captures sectors; carriers, tanks, mortars, and anti-tank guns cannot. Hold three of five sectors to drain enemy command strength.

Sandbags protect frontal approaches; flanking weakens that protection. MGs and mortars build suppression, pinning infantry. Tank armor is strongest at the front, and vehicles cannot be pinned by infantry suppression. Medics heal infantry after combat; engineers repair vehicles. Grenades and barrages break packed defenses. Retreat gives increased speed and reduced incoming damage; reinforcement at HQ replaces losses while retaining veterans.

Battles vary with the province: canals have bridge chokepoints; forests provide cover and slow movement; ridges provide cover and increased sight; cities add building obstacles; farmland offers more open manoeuvre space. Tactical AI distributes forces across objectives, seeks cover and high ground, places support units behind the line, flanks exposed defenders, retreats wounded sections, helps them recover, and recruits counters to armor it can see. Campaign enemy reinforcements are limited.

## Saves and victory

Campaign actions save immediately. Active battles save every 20 seconds and when the app enters the background or returns to the main menu. Writes use an atomic temporary-file replacement. Campaign and skirmish saves occupy separate slots.

Campaign saves include the regional economy, every market, armies, research, construction, pending invasions, the enemy phase queue, and an active or completed tactical battle. Resuming a completed battle shows its result again until you commit it; it does not replay combat or grant rewards twice. Invalid saves are rejected without replacing the live campaign. Settings are stored separately on the device.

On victory, the campaign ends when Iron Crown and at least nine provinces are held. Losing Haven ends the campaign. You can withdraw from a tactical battle through a confirmation in the pause menu; that records a defeat and returns surviving sections to the campaign according to normal retreat rules.

## Development and validation

```sh
./tools/run.sh --headless --editor --import --quit
./tools/run.sh --headless --script res://tests/test_simulation.gd
./tools/run.sh --headless --script res://tests/test_campaign.gd
./tools/run.sh --headless --script res://tests/test_theater_battles.gd
# Requires a real or virtual display; injects native touch events.
./tools/run.sh --audio-driver Dummy --script res://tests/test_interface.gd
./tools/run.sh --audio-driver Dummy --script res://tests/test_campaign_interface.gd
```

For exports, install matching Godot 4.6.3 templates. Android additionally needs JDK 17+, Android SDK/build-tools 36, and a debug keystore configured in Godot Editor Settings. The included presets export Android, Linux and Web:

```sh
mkdir -p builds/web
./tools/run.sh --headless --export-debug Android builds/SableFront-android.apk
./tools/run.sh --headless --export-release Linux builds/SableFront-linux.x86_64
./tools/run.sh --headless --export-release Web builds/web/index.html
```

See [validation results and limits](docs/VALIDATION.md). Tests cover complete skirmishes on all five biomes, an actual campaign battle played and committed back to the strategic map, strategic victories and defeats, save restoration, and the full mobile campaign flow. Physical Android device testing and mobile performance benchmarking remain pending.

## Architecture and assets

`campaign.gd` owns strategic rules; `campaign_ui.gd` and `region_atlas.gd` present the world map and management screens. `battle.gd` owns fixed-step combat, `squad.gd` defines roles and balance, and `economy.gd` models markets. `mobile_ui.gd` provides the tactical touch interface. `main.gd` manages transitions and atomic saves. `preferences.gd` manages device settings.

The static map is cached, movement is interpolated from a 10 Hz simulation, and infantry/vehicle artwork is drawn from one original texture atlas. Smooth fog and animated canal highlights use compatibility-renderer shaders. Reduced effects lower vegetation, tracer and water-animation costs without changing gameplay.

All game code, maps, sprites, icons, terrain material and synthesized sounds are original. No code or assets from the reference APK were copied. Open Sans and DejaVu retain their included licenses. `tools/generate_art.py` regenerates original art with Pillow; `tools/generate_audio.py` regenerates original sounds with the Python standard library. Runtime assets are already included.

Original work is MIT-licensed. Source archives exclude build outputs, signing keys, local saves, editor state and toolchains. This is an offline single-player campaign release; multiplayer, diplomacy, an app-store listing and physical-device certification are outside this version.

Made with [Godot Engine](https://godotengine.org/) ([engine license](https://godotengine.org/license/)).
