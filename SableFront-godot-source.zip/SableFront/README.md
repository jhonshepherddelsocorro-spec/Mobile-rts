# Sable Front

An original, offline **Godot 4.6 squad RTS for landscape mobile play**. Lead a platoon across the Meridian canal, control territory, and keep a supply network alive while regional commodity prices respond to the war.

This is a playable first prototype: one hand-illustrated battlefield, single-player skirmishes, three difficulty settings, and complete win/loss and replay flows. It is not a commercial-scale campaign or a multiplayer game.

![Sable Front battlefield](docs/screenshots/battle.png)

## Play

- **Android:** install `builds/SableFront-android.apk`, then open **Sable Front**. Requires Android 7.0+ (API 24), an ARMv7 or ARM64 device, and OpenGL ES 3.0. The APK is a development-signed, sideloadable build, not a Play Store release. No account, network connection, or Internet permission is needed.
- **Godot editor:** import `project.godot` in Godot **4.6.3** and press **F6/F5** to run the main scene/project. No plugins or external dependencies are required.
- **Cloud/Linux:** `./tools/run.sh` runs the game; `./tools/run.sh --editor` opens the editor. The wrapper keeps saves and editor state under ignored `.local/` when XDG directories have not already been configured.
- **Linux build:** `chmod +x builds/SableFront-linux.x86_64 && builds/SableFront-linux.x86_64`.
- **Web build:** serve `builds/web` with `python3 -m http.server 8000 --directory builds/web`, then open the server in a browser. Opening the HTML directly from disk does not load WebAssembly correctly.

Choose **Deploy Platoon**, capture at least **three of five sectors**, and reduce enemy command strength to zero. You begin with rifle, assault, and engineer sections. The Orchard (A) is already allied and connected to HQ.

## Controls

| Action | Touch | Mouse / keyboard |
| --- | --- | --- |
| Select a squad | Tap squad or bottom card | Left-click / keys 1–8 |
| Add a squad to selection | Long-press a squad | Shift-click |
| Select the entire platoon | Select All button | Select All button |
| Move / attack a visible enemy | Tap ground / enemy | Left-click ground / enemy, or right-click |
| Pan | One-finger drag | Drag or WASD / arrows |
| Zoom | Two-finger pinch or + / − | Mouse wheel or + / − |
| Focus a location | Tap minimap / sector letter | Same; F focuses selection; Home focuses HQ |
| Retreat / hold | Command buttons | R / H |
| Grenade / engineer sandbags | Ability button, then tap a target | Same; G toggles targeting |
| Pause / market / recruitment | HUD buttons; Android Back pauses | Space or Esc / M / B |

**Attack Move** orders a squad to advance and stop to engage on contact. Normal movement continues toward the destination while firing with a movement penalty. Squads automatically engage visible enemies within range and line of sight. Buildings block movement and bullets; the canal can be crossed only at its three bridges.

## Tactics and the economy

Five recruitable roles have distinct health, range, speed, squad sizes, and costs. Machine guns build suppression; heavily suppressed infantry becomes pinned. Sandbags reduce incoming frontal fire, while flanking reduces their protection. Engineers capture territory faster and build additional sandbags. Grenades deal area damage and suppression. Combat experience grants veteran damage bonuses.

Retreat grants faster movement and reduced incoming damage. Wounded squads can be reinforced for credits and supplies within the HQ ring. The command limit is eight active squads. Scout carriers provide armored fire support, consume fuel while moving, and cannot capture territory.

Infantry standing inside a sector's ring captures it over time. Enemy ownership must first be neutralized. Contested capture freezes. Allied supply links must trace through the Orchard to HQ; disconnected sectors retain ownership and count toward victory, but stop producing resources. A connected sector generates credits and its commodity every six simulation seconds. Squad upkeep reduces credit income.

The regional market maintains **stock, demand, price, and 24-step price history** for supplies, munitions, and fuel. Commodity consumption, combat intensity, shipment arrivals, disruptions, and player transactions change prices. Buy/sell spreads prevent free instant resale. Munitions are consumed in combat; shortages reduce firepower. Convoys provide bulk cargo after 24 seconds but can be intercepted by enemies near the HQ road.

Menus pause the simulation, including delivery and market clocks. Close a menu to resume time. Local operation progress autosaves every 30 active seconds and on leaving a match. **Continue Operation** restores units, orders, territory, veteran status, ability cooldowns, cargo, market history, and inbound convoys. **Save & Return to Briefing** saves immediately. A completed match clears the active save. Android backgrounding pauses and saves the match.

## Validate and export

```sh
./tools/run.sh --headless --editor --import --quit
./tools/run.sh --headless --script res://tests/test_simulation.gd
# Requires a real or virtual display; exercises native touch and captures screenshots.
./tools/run.sh --audio-driver Dummy --script res://tests/test_interface.gd

# Requires matching official 4.6.3 export templates.
mkdir -p builds builds/web
./tools/run.sh --headless --export-release Linux builds/SableFront-linux.x86_64
./tools/run.sh --headless --export-release Web builds/web/index.html
# Android additionally needs JDK 17+ and Android SDK paths/debug keystore
# configured in Godot Editor Settings. SDK/build-tools 36 were used here.
./tools/run.sh --headless --export-debug Android builds/SableFront-android.apk
```

The simulation suite runs actual pathfinding, capture, supply disconnection, market transactions and pricing, combat, cover, reinforcement, recruitment, abilities, convoy delivery/interception, save validation, and three complete AI matches. The UI suite injects native touch events through the real controls, checks pan/pinch gestures, local save/resume, victory/restart, and a 20:9 landscape layout. See [validation notes](docs/VALIDATION.md) for measured outcomes and testing limits.

## Source and assets

`scripts/battle.gd` owns the fixed-step simulation; `squad.gd` defines unit balance; `economy.gd` models commodity markets. `terrain.gd` draws the seeded map once, `battlefield.gd` renders troops/effects and handles gestures, and `game_ui.gd` builds the responsive command interface. Rendering interpolates 10 Hz simulation movement, caps the active army, and uses the compatibility renderer for mobile. `main.gd` manages deployment, pause, and atomic local saves.

The code, map, icons, and synthesized sounds are original. The uploaded Rusted Warfare APK was inspected only as reference; no code, textures, sounds, or executable content were copied into this project. Open Sans and DejaVu fonts are included with their license notices in `assets/fonts/`. `tools/generate_audio.py` regenerates the original sound assets using Python's standard library.

Project code and original assets are MIT-licensed. The source archive excludes generated caches, user saves, signing keys, and build outputs. Nothing has been uploaded to GitHub or published to an app store.
