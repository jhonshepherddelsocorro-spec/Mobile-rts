# Validation — Sable Front 0.1.0

Validated on 29 October 2026 using Godot **4.6.3 stable**, Debian Linux x86_64, and a software-rendered virtual display. These results describe the current prototype and builds, not certification on physical mobile devices.

| Check | Result |
| --- | --- |
| Simulation regression suite | **420 assertions, 0 failures** |
| Rendered interface integration suite | **45 assertions, 0 failures** |
| Full AI matches | Three completed matches; both allied and opposition victories exercised |
| Native touch input | Deployment, guide navigation, selection/orders, recruitment, buying, market close, pan, two-finger pinch, and restart passed |
| Layouts | 1440×900 and 1920×864 (20:9); HUD, market, and camera bounds checked |
| Save/resume | Actual atomic file save and restore passed; malformed save rejection tested |
| Android export | Development-signed APK built successfully; ARMv7 + ARM64 libraries present |
| APK verification | Android signature schemes v2 and v3 verified; 16 KB native library alignment verified |
| APK metadata | Package `org.sablefront.command`; minimum API 24; target API 36; landscape; OpenGL ES 3.0 |
| Android permissions | No requested permissions, including no Internet permission |
| Linux release export | Exported executable launched a match and shut down cleanly through the app's shutdown path |
| Web release export | Chromium/WebGL smoke test loaded the briefing, deployed via touch, and opened the market; no browser console or JavaScript errors |
| Distribution notices | Bundled Open Sans and DejaVu font license files verified inside APK |

The simulation tests exercise navigation across actual bridges, building collision and line of sight, contested capture, disconnected supply production, atomic trade transfers, market scarcity and oversupply, bounded price history, combat suppression, directional cover, retreat protection, veterancy, reinforcement at HQ, unit recruitment and limits, grenade/sandbag abilities, convoy arrival/interception, and JSON save round trips. Complete match tests issue real orders and run real AI rather than forcing a victory result.

| Match seed | Simulated duration | Winner | Weapon fire events |
| --- | --- | --- | --- |
| 42 | 314 seconds | Allied | 387 |
| 77 | 222 seconds | Opposition | 437 |
| 123 | 592 seconds | Allied | 877 |

The rendered UI suite captures the briefing, battlefield, recruitment, market, pause, phone layout, and victory screens. Browser screenshots separately verify the exported WebAssembly build. The virtual display reports that VSync cannot be changed; this is a display-driver limitation, not a game script failure.

## Remaining limits

- **No physical Android device or Android emulator was available.** APK building, signing, architecture/manifest inspection, native-library alignment, and desktop-native touch tests passed, but installation, GPU compatibility, thermal behavior, battery use, hardware audio, suspend/resume, and touch ergonomics on real phones remain unverified.
- Performance has not been benchmarked on low-end mobile hardware. The renderer uses OpenGL compatibility, a cached static map, interpolated fixed-step simulation, and an eight-squad player limit, but those choices are not a measured mobile frame-rate guarantee.
- This is an offline single-player vertical slice with one map and a per-operation economy. Multiplayer, campaign progression, strategic travel between markets, a map editor, and store-release signing are not implemented.
- Cover, suppression, squad health, logistics, and market events are deliberately simplified. Soldier figures represent a shared squad health pool; they are not separate individual combat agents.

Reproduce the checks with the commands in [README.md](../README.md). Build outputs are in `builds/` and are intentionally excluded from Git and the source archive. No repository push, app-store upload, web deployment, or cloud-environment publication was performed.
