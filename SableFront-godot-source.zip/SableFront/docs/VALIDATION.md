# Validation — Sable Front Campaign Edition 0.2.0

Validated on 29 October 2026 with Godot **4.6.3 stable**, Debian Linux x86_64, a virtual graphical display, and Chromium/WebGL. These results describe the current game and build artifacts. They do not certify performance or compatibility on physical phones.

## Automated suites

All five suites passed: **853 assertions, 0 failures**.

| Suite | Assertions | Result |
| --- | ---: | --- |
| Core tactical simulation regression | 424 | Passed |
| Strategic campaign, economy, persistence, specialist units | 214 | Passed |
| Complete battles across regional biomes and campaign integration | 23 | Passed |
| Existing skirmish touch-interface regression | 45 | Passed |
| Mobile campaign-to-battle interface integration | 147 | Passed |

The core tactical suite tests actual bridge navigation, collision, line of sight, contested capture, disconnected production, market transfers and pricing, suppression, cover, retreat, veterancy, reinforcement, recruitment limits, abilities, convoys, and save validation. Its three AI matches completed with weapon-fire events, not merely zero-test exits.

The campaign suite tests fifteen-province initialization, bidirectional adjacency, exact movement/fuel charges, unavailable routes, army limits, technology locks, construction and research timers, connected production, attrition, stance commitment, reinforcement, provincial pricing and access, warehouse limits, survivor identity, tactical recruits returning to the army, and duplicate-result rejection. It validates pending and completed campaign saves, rejects malformed fields, and exercises both battle-based and undefended-capital victories. Strategic AI simulations reach a genuine campaign defeat after capturing Haven.

Specialist-unit tests execute medic healing, emergency aid, anti-armor damage, mortar indirect fire and minimum range, timed reconnaissance, smoke protection, precision shots, and persistent fire damage/expiry.

## Complete tactical matches

| Scenario | Duration | Winner | Weapon-fire events |
| --- | ---: | --- | ---: |
| Canal, seed 42 | 308 seconds | Opposition | 759 |
| Canal, seed 77 | 208 seconds | Opposition | 455 |
| Canal, seed 123 | 188 seconds | Opposition | 437 |
| Forest, combined arms | 214 seconds | Allied | 388 |
| Ridge, combined arms | 186 seconds | Allied | 258 |
| City, combined arms | 212 seconds | Allied | 327 |
| Farmland, combined arms | 502 seconds | Allied | 969 |
| Actual campaign attack on Sunfield | 126 seconds | Allied | 119 |

The Sunfield campaign battle used the campaign's real army and shared treasury, played to completion using the real tactical simulation and AI, then committed its surviving five sections back to the strategic map. Resulting ownership and the post-battle save were checked.

## Mobile flow and rendered validation

The interface suite injects native touch events through real Godot controls. It starts a campaign, selects provinces, recruits, buys cargo, queues research and construction, previews an attack, deploys the exact army, uses multi-selection and the collapsible map, recruits medics, saves an active battle, restores it, handles Android background/back notifications, changes battery/effects preferences, withdraws through confirmation, restores the completed result after leaving the game, and commits survivors to the campaign. It then processes real turns and defensive auto-resolves, checks completed research/construction, and resumes the strategic save from the main menu.

Regression checks explicitly preserve persistent section IDs, injury-recovery delay, weapon deployment state, and smoke duration through tactical saves. A touch-sensor jitter test ensures tiny finger movements do not become an unintended drag.

Layouts were exercised at **1440×900** and **1920×864 (20:9)**. Atlas pinch gestures and their non-selection behavior were checked. The existing one-finger pan, two-finger tactical pinch, trading, recruitment, save and victory/restart regression suite also passes. The application applies Android's reported display safe area to its UI; real cutout behavior still needs device testing.

Screenshots in `docs/screenshots/` show the actual home, campaign, army, research, markets, preview, battle, results, settings and wide-phone layouts. The virtual display reports unsupported VSync selection; this is a software-display limitation, not a game script error.

## Exported builds

- **Android:** version **0.2.0**, version code **2**, package `org.sablefront.command`, minimum API **24**, target API **36**, landscape, OpenGL ES **3.0**. ARMv7 and ARM64 libraries are present.
- Android signature schemes **v2 and v3** verified. Native-library **16 KB page alignment** verified. ZIP integrity and embedded font/project license notices checked.
- The signing certificate matches the previous **0.1.0 APK**, allowing normal upgrade installation with local save retention. Old skirmish JSON format remains supported; campaign data uses a separate slot.
- The only requested Android permission is **VIBRATE** for optional haptics. No Internet permission is requested.
- **Linux release:** exported executable started a campaign, rendered it, and shut down through the application shutdown path without game errors.
- **Web release:** Chromium loaded the actual exported WebAssembly build, started a campaign through touch, attacked Sunfield, deployed a tactical battle, saved and returned home, reloaded the page, resumed the saved battle from persisted browser storage, withdrew, committed the result, and ended a strategic turn. No browser console or JavaScript errors were recorded.
- Source/build archives exclude editor state, local saves, signing keys, toolchains, and nested build outputs. Download artifacts are SHA-256 checked after uploading to GitHub.

## Remaining testing limits

**No physical Android device or Android emulator was available.** Building, signing, architecture/manifest inspection, update-certificate comparison, native-library alignment, desktop-native touch integration and browser runtime checks passed. Actual APK installation, GPU behavior, haptics, hardware audio, cutouts, thermal/battery use, suspension and ergonomics on phones remain unverified. No measured low-end mobile frame-rate guarantee is made.

This version is a complete playable offline campaign loop with an ending and resumable battles. It is not an app-store-certified release. Multiplayer, diplomacy and a map editor are outside version 0.2. Soldier figures share a squad health pool rather than running independent soldier-level combat simulations. Economy, cover and auto-resolve are deliberately simplified.

Reproduce the suites and exports with the commands in [README.md](../README.md). Cloud-environment publication and app-store deployment are not part of this update.
