class_name BattlefieldAudio
extends Node

var battle: BattleSimulation
var enabled: bool = true:
	set(value):
		enabled = value
		if is_instance_valid(ambience): ambience.volume_db = -25 if enabled else -80
var ambience: AudioStreamPlayer
var players: Array[AudioStreamPlayer] = []
var cursor: int = 0
var last_shot: int = 0
var rifle: AudioStream = preload("res://assets/audio/rifle.wav")
var cannon: AudioStream = preload("res://assets/audio/cannon.wav")
var blast: AudioStream = preload("res://assets/audio/blast.wav")
var capture: AudioStream = preload("res://assets/audio/capture.wav")

func _ready() -> void:
	for i in range(8):
		var player = AudioStreamPlayer.new()
		player.playback_type = AudioServer.PLAYBACK_TYPE_STREAM
		add_child(player)
		players.append(player)
	ambience = AudioStreamPlayer.new()
	ambience.playback_type = AudioServer.PLAYBACK_TYPE_STREAM
	ambience.stream = preload("res://assets/audio/wind.wav")
	ambience.volume_db = -25
	add_child(ambience)
	ambience.play()
	ambience.finished.connect(_loop_wind)
	battle.shot.connect(func(a, b, _team, heavy):
		if Time.get_ticks_msec() - last_shot < 85: return
		if not battle.visible_at(a) and not battle.visible_at(b): return
		last_shot = Time.get_ticks_msec()
		play(cannon if heavy else rifle, -17 if heavy else -23))
	battle.explosion.connect(func(_p, _r): play(blast, -14))
	battle.notice.connect(func(text):
		if "secured" in text or "delivered" in text: play(capture, -15))

func play(stream: AudioStream, volume: float) -> void:
	if not enabled: return
	var player = players[cursor % players.size()]
	cursor += 1
	player.stream = stream
	player.volume_db = volume
	player.pitch_scale = 0.94 + fmod(float(cursor) * 0.13, 0.12)
	player.play()

func _exit_tree() -> void:
	stop_all()

func stop_all() -> void:
	enabled = false
	if is_instance_valid(ambience):
		ambience.stop()
		ambience.stream = null
	for player in players:
		player.stop()
		player.stream = null

func _loop_wind() -> void:
	if is_inside_tree() and enabled: ambience.play()
