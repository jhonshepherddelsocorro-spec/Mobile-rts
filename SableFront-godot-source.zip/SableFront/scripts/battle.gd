class_name BattleSimulation
extends Node

signal changed
signal notice(text: String)
signal shot(from: Vector2, to: Vector2, team: int, heavy: bool)
signal explosion(at: Vector2, radius: float)
signal match_ended(winner: int)

const WORLD = Vector2(2560, 1792)
const BASES = [Vector2(290, 1450), Vector2(2250, 300)]
const LINKS = [[0, 1], [0, 2], [1, 2], [1, 4], [2, 3], [3, 4]]
const CELL = 40
const SQUAD_LIMIT = 8
var economy = WarEconomy.new()
var squads: Array[CombatSquad] = []
var points: Array[Dictionary] = []
var covers: Array[Dictionary] = []
var buildings: Array[Rect2] = []
var selected: Array[int] = []
var tickets = [300.0, 300.0]
var elapsed: float = 0.0
var paused: bool = false
var finished: bool = false
var winner: int = -1
var difficulty: int = 1
var next_id: int = 0
var combat_heat: float = 0.0
var enemy_credits: float = 220.0
var kills = [0, 0]
var captures: int = 0
var convoys: Array[Dictionary] = []
var fog: bool = true
var explored = {}
var pathfinder = AStarGrid2D.new()
var rng = RandomNumberGenerator.new()
var _accumulator: float = 0.0
var _market_clock: float = 0.0
var _ai_clock: float = 0.0
var _ticket_clock: float = 0.0

func setup(level: int = 1, seed_value: int = 42) -> void:
	difficulty = level
	rng.seed = seed_value
	economy = WarEconomy.new(seed_value)
	points = [
		{"name": "ORCHARD", "code": "A", "pos": Vector2(600, 1040), "good": "supplies", "owner": 0, "progress": -1.0, "contested": false, "linked": true},
		{"name": "RAIL DEPOT", "code": "B", "pos": Vector2(1030, 540), "good": "ammo", "owner": -1, "progress": 0.0, "contested": false, "linked": false},
		{"name": "THE CROSSING", "code": "C", "pos": Vector2(1510, 1030), "good": "supplies", "owner": -1, "progress": 0.0, "contested": false, "linked": false},
		{"name": "FUEL WORKS", "code": "D", "pos": Vector2(1940, 1330), "good": "fuel", "owner": -1, "progress": 0.0, "contested": false, "linked": false},
		{"name": "SIGNAL HILL", "code": "E", "pos": Vector2(1960, 600), "good": "ammo", "owner": 1, "progress": 1.0, "contested": false, "linked": true}
	]
	buildings = [Rect2(720, 590, 170, 100), Rect2(860, 760, 145, 105), Rect2(500, 620, 110, 150), Rect2(1650, 760, 175, 110), Rect2(1740, 980, 110, 90), Rect2(2110, 1070, 130, 160), Rect2(1670, 350, 140, 105), Rect2(780, 1200, 145, 115)]
	covers.clear()
	for pair in [[Vector2(510, 960), Vector2(625, 960)], [Vector2(930, 455), Vector2(1050, 455)], [Vector2(1470, 925), Vector2(1580, 925)], [Vector2(1820, 1250), Vector2(1950, 1250)], [Vector2(1870, 505), Vector2(1980, 505)], [Vector2(960, 1020), Vector2(1060, 1020)], [Vector2(1590, 620), Vector2(1590, 730)], [Vector2(400, 1250), Vector2(510, 1250)]]:
		covers.append({"a": pair[0], "b": pair[1]})
	_prepare_navigation()
	_spawn(0, "rifle", Vector2(440, 1260))
	_spawn(0, "assault", Vector2(560, 1360))
	_spawn(0, "engineer", Vector2(350, 1210))
	_spawn(1, "rifle", Vector2(1860, 670))
	_spawn(1, "support", Vector2(2080, 520))
	_spawn(1, "rifle", Vector2(2060, 850))
	if difficulty == 2:
		_spawn(1, "assault", Vector2(2280, 600))
	selected = [0]
	_reconnect()
	_update_visibility()
	changed.emit()

static func river_x(y: float) -> float:
	return 1260.0 + sin((y - 150.0) / 320.0) * 135.0

static func is_water(p: Vector2) -> bool:
	if absf(p.x - river_x(p.y)) >= 78.0:
		return false
	for bridge_y in [540.0, 1030.0, 1470.0]:
		if absf(p.y - bridge_y) < 58.0:
			return false
	return true

func _prepare_navigation() -> void:
	pathfinder.region = Rect2i(0, 0, int(WORLD.x / CELL), int(WORLD.y / CELL))
	pathfinder.cell_size = Vector2(CELL, CELL)
	pathfinder.offset = Vector2(CELL / 2.0, CELL / 2.0)
	pathfinder.diagonal_mode = AStarGrid2D.DIAGONAL_MODE_ONLY_IF_NO_OBSTACLES
	pathfinder.update()
	for y in range(pathfinder.region.size.y):
		for x in range(pathfinder.region.size.x):
			var p = Vector2(x * CELL + CELL / 2.0, y * CELL + CELL / 2.0)
			var solid = is_water(p)
			for building in buildings:
				if building.grow(12).has_point(p): solid = true
			pathfinder.set_point_solid(Vector2i(x, y), solid)

func walkable(p: Vector2) -> Vector2:
	var cell = Vector2i(clampi(int(p.x / CELL), 0, pathfinder.region.size.x - 1), clampi(int(p.y / CELL), 0, pathfinder.region.size.y - 1))
	if not pathfinder.is_point_solid(cell):
		return Vector2(cell) * CELL + Vector2.ONE * CELL / 2.0
	for radius in range(1, 10):
		for y in range(-radius, radius + 1):
			for x in range(-radius, radius + 1):
				var c = cell + Vector2i(x, y)
				if pathfinder.region.has_point(c) and not pathfinder.is_point_solid(c):
					return Vector2(c) * CELL + Vector2.ONE * CELL / 2.0
	return BASES[0]

func path_between(from: Vector2, to: Vector2) -> Array[Vector2]:
	var start = Vector2i(walkable(from) / CELL)
	var end = Vector2i(walkable(to) / CELL)
	var path: Array[Vector2] = []
	for p in pathfinder.get_point_path(start, end): path.append(p)
	return path

func _spawn(team: int, kind: String, at: Vector2) -> CombatSquad:
	var squad = CombatSquad.new(next_id, team, kind, walkable(at))
	next_id += 1
	squads.append(squad)
	return squad

func get_squad(id: int) -> CombatSquad:
	for squad in squads:
		if squad.id == id: return squad
	return null

func living(team: int) -> Array[CombatSquad]:
	var result: Array[CombatSquad] = []
	for squad in squads:
		if squad.alive and squad.team == team: result.append(squad)
	return result

func visible_at(p: Vector2) -> bool:
	if not fog: return true
	if p.distance_to(BASES[0]) < 330.0: return true
	for squad in squads:
		if squad.alive and squad.team == 0 and squad.pos.distance_to(p) < 440.0:
			return true
	for point in points:
		if point.owner == 0 and point.pos.distance_to(p) < 210.0: return true
	return false

func _update_visibility() -> void:
	for squad in living(0):
		var origin = Vector2i(squad.pos / 160.0)
		for y in range(-3, 4):
			for x in range(-3, 4):
				explored[origin + Vector2i(x, y)] = true

func select_at(at: Vector2, additive: bool = false) -> bool:
	var nearest: CombatSquad = null
	var distance = 65.0
	for squad in living(0):
		var d = squad.pos.distance_to(at)
		if d < distance:
			distance = d
			nearest = squad
	if nearest:
		select_squad(nearest.id, additive)
		return true
	return false

func select_squad(id: int, additive: bool = false) -> void:
	var squad = get_squad(id)
	if squad == null or not squad.alive or squad.team != 0: return
	if not additive: selected.clear()
	if id in selected:
		selected.erase(id)
	else:
		selected.append(id)
	changed.emit()

func select_all() -> void:
	selected.clear()
	for squad in living(0): selected.append(squad.id)
	changed.emit()

func command(at: Vector2, attack_move: bool = false) -> void:
	if finished: return
	var target: CombatSquad = null
	for enemy in living(1):
		if visible_at(enemy.pos) and enemy.pos.distance_to(at) < 65.0:
			target = enemy
	var index = 0
	for id in selected:
		var squad = get_squad(id)
		if squad == null or not squad.alive or squad.order == "retreat": continue
		var offset = Vector2((index % 3) * 58.0, (index / 3) * 58.0) if selected.size() > 1 else Vector2.ZERO
		_move(squad, at + offset, "attack" if target or attack_move else "move")
		squad.target_id = target.id if target else -1
		index += 1
	changed.emit()

func _move(squad: CombatSquad, at: Vector2, order: String) -> void:
	squad.destination = walkable(at)
	squad.route = path_between(squad.pos, squad.destination)
	squad.order = order
	squad.deployed = false

func retreat_selected() -> void:
	for id in selected:
		var squad = get_squad(id)
		if squad and squad.alive:
			squad.target_id = -1
			_move(squad, BASES[0] + Vector2(rng.randf_range(-60, 60), rng.randf_range(-50, 50)), "retreat")
	notice.emit("Fall back! Retreating squads take reduced damage. Reinforce at HQ.")
	changed.emit()

func hold_selected() -> void:
	for id in selected:
		var squad = get_squad(id)
		if squad and squad.alive and squad.order != "retreat":
			squad.route.clear()
			squad.destination = squad.pos
			squad.order = "hold"
			squad.target_id = -1
	changed.emit()

func reinforce() -> bool:
	var done = false
	for id in selected:
		var squad = get_squad(id)
		if not squad or not squad.alive or squad.pos.distance_to(BASES[0]) > 240.0 or squad.hp >= squad.max_hp - 1.0: continue
		var missing = (squad.max_hp - squad.hp) / squad.max_hp
		if economy.pay({"credits": ceil(70.0 * missing), "supplies": ceil(20.0 * missing)}):
			squad.hp = squad.max_hp
			squad.suppression = 0.0
			done = true
	notice.emit("Squad reinforced and resupplied." if done else "Move wounded squads within the HQ ring. Reinforcement requires credits and supplies.")
	changed.emit()
	return done

func recruit(kind: String) -> bool:
	if finished or not CombatSquad.TYPES.has(kind): return false
	if living(0).size() >= SQUAD_LIMIT:
		notice.emit("Command limit reached: 8 squads.")
		return false
	if not economy.pay(CombatSquad.TYPES[kind].cost):
		notice.emit("Insufficient resources. Trade at the field market or connect more sectors.")
		return false
	var squad = _spawn(0, kind, BASES[0] + Vector2(rng.randf_range(-85, 85), rng.randf_range(-100, 30)))
	select_squad(squad.id)
	notice.emit("%s reporting for duty at HQ." % squad.data().name)
	changed.emit()
	return true

func ability(at: Vector2) -> bool:
	if selected.is_empty() or finished: return false
	var squad = get_squad(selected[0])
	if not squad or not squad.alive or squad.order == "retreat": return false
	if squad.ability_cd > 0:
		notice.emit("Ability recharging: %ds." % int(ceil(squad.ability_cd)))
		return false
	if squad.kind == "engineer":
		if squad.pos.distance_to(at) > 180.0:
			notice.emit("Build cover within 180m of the engineers.")
			return false
		if is_water(at) or not economy.pay({"supplies": 12}):
			notice.emit("Sandbags require dry ground and 12 supplies.")
			return false
		covers.append({"a": at - Vector2(48, 0), "b": at + Vector2(48, 0)})
		squad.ability_cd = 18.0
		notice.emit("Sandbag cover built. Position infantry alongside it.")
	else:
		if squad.pos.distance_to(at) > 310.0:
			notice.emit("Grenade target is out of range (310m).")
			return false
		if not economy.pay({"ammo": 12}):
			notice.emit("A grenade costs 12 munitions.")
			return false
		explosion.emit(at, 95.0)
		for enemy in living(1):
			if enemy.pos.distance_to(at) < 95.0:
				_damage(enemy, 75.0, squad)
				enemy.suppression = minf(100.0, enemy.suppression + 45.0)
		squad.ability_cd = 24.0
		notice.emit("Frag out! Area damage and suppression.")
	changed.emit()
	return true

func dispatch_convoy() -> bool:
	if finished: return false
	if not convoys.is_empty():
		notice.emit("A supply convoy is already en route.")
		return false
	if not economy.pay({"credits": 140, "fuel": 8}):
		notice.emit("A convoy requires 140 credits and 8 fuel.")
		return false
	convoys.append({"time": 24.0, "total": 24.0, "hp": 100.0, "pos": Vector2(110, 1720), "reward": {"supplies": 45.0, "ammo": 35.0, "fuel": 15.0}})
	notice.emit("Convoy inbound. Delivery in 24 seconds. Keep enemies away from your HQ road.")
	changed.emit()
	return true

func _process(delta: float) -> void:
	if paused or finished: return
	_accumulator += minf(delta, 0.25)
	while _accumulator >= 0.1:
		step(0.1)
		_accumulator -= 0.1

func step(delta: float) -> void:
	if finished or paused: return
	elapsed += delta
	combat_heat = move_toward(combat_heat, 0.0, delta * 0.12)
	for squad in squads:
		if squad.alive: _update_squad(squad, delta)
	_capture(delta)
	_update_convoys(delta)
	_market_clock += delta
	_ai_clock += delta
	_ticket_clock += delta
	if _market_clock >= 6.0:
		_market_clock -= 6.0
		_market_tick()
	if _ai_clock >= 3.0:
		_ai_clock -= 3.0
		_ai()
		_update_visibility()
	if _ticket_clock >= 2.0:
		_ticket_clock -= 2.0
		var owned = [0, 0]
		for point in points:
			if point.owner >= 0: owned[point.owner] += 1
		if owned[0] >= 3: tickets[1] = maxf(0.0, tickets[1] - (owned[0] - 2) * 2.0)
		if owned[1] >= 3: tickets[0] = maxf(0.0, tickets[0] - (owned[1] - 2) * 2.0)
		for team in [0, 1]:
			if tickets[team] <= 0:
				finished = true
				winner = 1 - team
				match_ended.emit(winner)
		changed.emit()

func _update_squad(squad: CombatSquad, delta: float) -> void:
	squad.cooldown = maxf(0.0, squad.cooldown - delta)
	squad.ability_cd = maxf(0.0, squad.ability_cd - delta)
	squad.shot_flash = maxf(0.0, squad.shot_flash - delta)
	squad.suppression = maxf(0.0, squad.suppression - delta * (14.0 if squad.order == "retreat" else 5.0))
	squad.cover = cover_at(squad.pos)
	squad.moving = false
	# Clear dead targets; friendly squads never attack enemies hidden by fog.
	var target = get_squad(squad.target_id)
	if target and (not target.alive or (squad.team == 0 and not visible_at(target.pos))): target = null
	var reach: float = squad.data().range
	if target and squad.order != "attack" and not line_of_sight(squad.pos, target.pos): target = null
	if target == null or target.pos.distance_to(squad.pos) > reach * 1.35:
		target = null
		var closest = reach
		for other in squads:
			if other.alive and other.team != squad.team and (squad.team == 1 or visible_at(other.pos)):
				var distance = squad.pos.distance_to(other.pos)
				if distance < closest and line_of_sight(squad.pos, other.pos):
					closest = distance
					target = other
	squad.target_id = target.id if target else -1
	var stop_to_fire = target != null and squad.order == "attack" and squad.pos.distance_to(target.pos) <= reach * 0.9 and line_of_sight(squad.pos, target.pos)
	if squad.route.size() > 0 and not stop_to_fire:
		var speed: float = squad.data().speed
		if squad.suppression > 72.0: speed *= 0.25
		elif squad.suppression > 40.0: speed *= 0.65
		if squad.order == "retreat": speed *= 1.65
		if squad.kind == "armor" and squad.team == 0:
			if economy.cargo.fuel <= 0.0: speed *= 0.3
			else: economy.cargo.fuel = maxf(0.0, economy.cargo.fuel - delta * 0.035)
		var goal: Vector2 = squad.route[0]
		var direction = squad.pos.direction_to(goal)
		squad.facing = lerp_angle(squad.facing, direction.angle(), delta * 8.0)
		squad.pos = squad.pos.move_toward(goal, speed * delta)
		squad.moving = true
		if squad.pos.distance_to(goal) < 3.0: squad.route.pop_front()
		if squad.route.is_empty():
			squad.order = "hold"
			squad.moving = false
	elif squad.order == "attack" and target and (squad.pos.distance_to(target.pos) > reach or not line_of_sight(squad.pos, target.pos)):
		_move(squad, target.pos, "attack")
	if squad.order == "retreat": return
	if target and squad.pos.distance_to(target.pos) <= reach and squad.cooldown <= 0.0 and squad.suppression < 85.0 and line_of_sight(squad.pos, target.pos):
		_fire(squad, target)
	if squad.pos.distance_to(BASES[squad.team]) < 200.0:
		squad.suppression = maxf(0.0, squad.suppression - delta * 15.0)

func _fire(attacker: CombatSquad, target: CombatSquad) -> void:
	attacker.facing = attacker.pos.angle_to_point(target.pos)
	attacker.cooldown = attacker.data().rate * (1.0 + attacker.suppression * 0.012)
	attacker.shot_flash = 0.15
	var strength = 0.5 + attacker.hp / attacker.max_hp * 0.5
	var damage: float = attacker.data().damage * strength * (1.0 + attacker.rank() * 0.12)
	if attacker.moving: damage *= 0.6
	if attacker.team == 0:
		if economy.cargo.ammo > 0.3:
			economy.cargo.ammo -= 0.3
		else: damage *= 0.4
	if attacker.kind == "assault" and attacker.pos.distance_to(target.pos) < 125.0: damage *= 1.4
	if target.kind == "armor" and attacker.kind != "armor": damage *= 0.45
	# Cover is directional: shots from the far side receive protection; flanks do not.
	var protection = target.cover
	for cover in covers:
		var nearest = Geometry2D.get_closest_point_to_segment(target.pos, cover.a, cover.b)
		if nearest.distance_to(target.pos) < 55.0:
			if (target.pos - nearest).dot(attacker.pos - nearest) > 0.0: protection *= 0.3
	if target.moving: protection *= 0.35
	if target.order == "retreat": damage *= 0.48
	damage *= 1.0 - protection
	_damage(target, damage, attacker)
	var suppress = 15.0 if attacker.kind == "support" else 4.0
	target.suppression = minf(100.0, target.suppression + suppress * (1.0 - protection * 0.4))
	combat_heat = minf(10.0, combat_heat + 0.2)
	shot.emit(attacker.pos, target.pos, attacker.team, attacker.kind == "armor")

func _damage(target: CombatSquad, damage: float, attacker: CombatSquad) -> void:
	if not target.alive: return
	target.hp = maxf(0.0, target.hp - damage)
	attacker.veterancy += damage * 0.5
	if target.hp <= 0.0:
		target.alive = false
		selected.erase(target.id)
		kills[attacker.team] += 1
		attacker.kills += 1
		tickets[target.team] = maxf(0.0, tickets[target.team] - 12.0)
		if attacker.team == 0: economy.credits += 35.0
		notice.emit("%s lost. Preserve veterans: retreat before they are overrun." % target.title if target.team == 0 else "Enemy section eliminated. +35 salvage credits.")
		changed.emit()

func cover_at(at: Vector2) -> float:
	for cover in covers:
		if Geometry2D.get_closest_point_to_segment(at, cover.a, cover.b).distance_to(at) < 55.0: return 0.55
	for building in buildings:
		if building.grow(50.0).has_point(at): return 0.3
	return 0.0

func line_of_sight(from: Vector2, to: Vector2) -> bool:
	for building in buildings:
		if building.has_point(from) or building.has_point(to): return false
		var a = building.position
		var b = Vector2(building.end.x, building.position.y)
		var c = building.end
		var d = Vector2(building.position.x, building.end.y)
		for edge in [[a, b], [b, c], [c, d], [d, a]]:
			if Geometry2D.segment_intersects_segment(from, to, edge[0], edge[1]) != null: return false
	return true

func _capture(delta: float) -> void:
	var ownership_changed = false
	for point in points:
		var strength = [0.0, 0.0]
		for squad in squads:
			if squad.alive and squad.order != "retreat" and squad.kind != "armor" and squad.suppression < 72.0 and squad.pos.distance_to(point.pos) < 105.0:
				strength[squad.team] += 1.5 if squad.kind == "engineer" else 1.0
		point.contested = strength[0] > 0.0 and strength[1] > 0.0
		if point.contested: continue
		var team = 0 if strength[0] > 0.0 else (1 if strength[1] > 0.0 else -1)
		if team < 0: continue
		var before: int = point.owner
		var direction = -1.0 if team == 0 else 1.0
		point.progress = clampf(point.progress + direction * delta * 0.085 * minf(strength[team], 2.0), -1.0, 1.0)
		if before == 1 and point.progress <= 0.0: point.owner = -1
		if before == 0 and point.progress >= 0.0: point.owner = -1
		if point.progress <= -1.0: point.owner = 0
		elif point.progress >= 1.0: point.owner = 1
		if before != point.owner:
			ownership_changed = true
			if point.owner >= 0:
				if point.owner == 0:
					captures += 1
					economy.credits += 40.0
				notice.emit("%s secured. %s" % [point.name.capitalize(), "+40 credits. Supply route updated." if point.owner == 0 else "Enemy control. Your supply routes may be cut."])
	if ownership_changed:
		_reconnect()
		changed.emit()

func _reconnect() -> void:
	for point in points: point.linked = false
	for team in [0, 1]:
		var start = 0 if team == 0 else 4
		if points[start].owner != team: continue
		var open = [start]
		points[start].linked = true
		while not open.is_empty():
			var here = open.pop_front()
			for link in LINKS:
				var next = link[1] if link[0] == here else (link[0] if link[1] == here else -1)
				if next >= 0 and not points[next].linked and points[next].owner == team:
					points[next].linked = true
					open.append(next)

func _market_tick() -> void:
	var production = {"supplies": 2.0, "ammo": 1.0, "fuel": 0.5}
	var connected = 0
	for point in points:
		if point.owner == 0 and point.linked:
			production[point.good] += 5.0
			connected += 1
	economy.tick(production, living(0).size(), combat_heat, connected)
	enemy_credits += (38.0 if difficulty == 2 else (24.0 if difficulty == 1 else 16.0))
	for point in points:
		if point.owner == 1 and point.linked: enemy_credits += 10.0
	changed.emit()

func _update_convoys(delta: float) -> void:
	for i in range(convoys.size() - 1, -1, -1):
		var convoy = convoys[i]
		convoy.time -= delta
		convoy.pos = Vector2(110, 1720).lerp(BASES[0], 1.0 - convoy.time / convoy.total)
		for enemy in living(1):
			if enemy.pos.distance_to(convoy.pos) < 230.0: convoy.hp -= delta * 10.0
		if convoy.hp <= 0.0:
			notice.emit("Convoy lost. The delivery road was interdicted by enemy infantry.")
			convoys.remove_at(i)
		elif convoy.time <= 0.0:
			for good in convoy.reward: economy.cargo[good] = minf(999.0, economy.cargo[good] + convoy.reward[good])
			notice.emit("Convoy delivered: +45 supplies, +35 munitions, +15 fuel.")
			convoys.remove_at(i)
			changed.emit()

func _ai() -> void:
	var enemies = living(1)
	if enemies.size() < (6 if difficulty == 2 else 5) and enemy_credits >= 180.0:
		var kind = ["rifle", "assault", "support", "engineer"][rng.randi_range(0, 3)]
		if enemy_credits >= CombatSquad.TYPES[kind].cost.credits:
			enemy_credits -= CombatSquad.TYPES[kind].cost.credits
			_spawn(1, kind, BASES[1] + Vector2(rng.randf_range(-60, 60), rng.randf_range(-50, 100)))
	for squad in enemies:
		if squad.hp < squad.max_hp * 0.22 and squad.order != "retreat":
			_move(squad, BASES[1], "retreat")
			continue
		if squad.pos.distance_to(BASES[1]) < 160.0 and squad.hp < squad.max_hp and enemy_credits >= 45.0:
			enemy_credits -= 45.0
			squad.hp = minf(squad.max_hp, squad.hp + 100.0)
		if squad.order == "retreat": continue
		if squad.moving and squad.route.size() > 4: continue
		var best: Dictionary = {}
		var score = -INF
		for point in points:
			var value = 500.0 if point.owner != 1 else 30.0
			value -= squad.pos.distance_to(point.pos) * 0.25
			for other in enemies:
				if other.id != squad.id and other.destination.distance_to(point.pos) < 140.0: value -= 170.0
			if value > score:
				score = value
				best = point
		if not best.is_empty(): _move(squad, best.pos + Vector2(rng.randf_range(-45, 45), rng.randf_range(-45, 45)), "attack")

func snapshot() -> Dictionary:
	var units = []
	for squad in squads:
		units.append({"id": squad.id, "team": squad.team, "kind": squad.kind, "pos": [squad.pos.x, squad.pos.y], "destination": [squad.destination.x, squad.destination.y], "hp": squad.hp, "suppression": squad.suppression, "cooldown": squad.cooldown, "veterancy": squad.veterancy, "facing": squad.facing, "order": squad.order, "target_id": squad.target_id, "alive": squad.alive, "ability_cd": squad.ability_cd, "kills": squad.kills})
	var sectors = []
	for point in points: sectors.append({"owner": point.owner, "progress": point.progress})
	var fortifications = []
	for cover in covers: fortifications.append([cover.a.x, cover.a.y, cover.b.x, cover.b.y])
	var deliveries = []
	for convoy in convoys:
		var entry = convoy.duplicate(true)
		entry.pos = [convoy.pos.x, convoy.pos.y]
		deliveries.append(entry)
	return {"version": 1, "difficulty": difficulty, "elapsed": elapsed, "tickets": tickets.duplicate(), "kills": kills.duplicate(), "captures": captures, "next_id": next_id, "enemy_credits": enemy_credits, "rng_state": str(rng.state), "economy_rng": str(economy.rng.state), "selected": selected.duplicate(), "squads": units, "points": sectors, "covers": fortifications, "convoys": deliveries, "economy": {"credits": economy.credits, "cargo": economy.cargo.duplicate(), "stock": economy.stock.duplicate(), "demand": economy.demand.duplicate(), "prices": economy.prices.duplicate(), "history": economy.history.duplicate(true), "headline": economy.headline, "turn": economy.turn, "income": economy.income}, "clocks": [_market_clock, _ai_clock, _ticket_clock]}

func restore(data: Dictionary) -> bool:
	# Validate the complete external save before changing the running operation.
	if data.get("version") != 1 or not data.get("squads") is Array or not data.get("points") is Array or not data.get("economy") is Dictionary: return false
	if data.points.size() != 5 or data.squads.size() > 200 or not data.get("tickets") is Array or data.tickets.size() != 2: return false
	for key in ["elapsed", "difficulty", "captures", "next_id", "enemy_credits"]:
		if data.has(key) and not _number(data[key]): return false
	for key in ["covers", "convoys", "selected", "kills", "clocks"]:
		if data.has(key) and not data[key] is Array: return false
	for key in ["selected", "kills", "clocks"]:
		for value in data.get(key, []):
			if not _number(value): return false
	if data.get("kills", [0, 0]).size() != 2 or data.get("clocks", [0, 0, 0]).size() != 3: return false
	for point in data.points:
		if not point is Dictionary or not point.has_all(["owner", "progress"]): return false
		if not _number(point.owner) or not _number(point.progress) or int(point.owner) < -1 or int(point.owner) > 1: return false
	var ids = {}
	for unit in data.squads:
		if not unit is Dictionary or not unit.has_all(["id", "team", "kind", "pos", "hp", "destination"]): return false
		if not CombatSquad.TYPES.has(unit.kind) or not _number(unit.id) or not _number(unit.team) or not _number(unit.hp): return false
		if not _valid_position(unit.pos) or not _valid_position(unit.destination) or int(unit.team) not in [0, 1] or ids.has(int(unit.id)): return false
		for key in ["suppression", "veterancy", "cooldown", "ability_cd", "facing", "kills", "target_id"]:
			if unit.has(key) and not _number(unit[key]): return false
		ids[int(unit.id)] = true
	var econ: Dictionary = data.economy
	for key in ["cargo", "stock", "demand", "prices", "history"]:
		if not econ.get(key) is Dictionary: return false
		for good in WarEconomy.GOODS:
			if not econ[key].has(good): return false
			if key == "history":
				if not econ[key][good] is Array or econ[key][good].size() > 24: return false
				for value in econ[key][good]:
					if not _number(value): return false
			elif not _number(econ[key][good]): return false
	if not _number(econ.get("credits")): return false
	for key in ["turn", "income"]:
		if econ.has(key) and not _number(econ[key]): return false
	for ticket in data.tickets:
		if not _number(ticket): return false
	for cover in data.get("covers", []):
		if not cover is Array or cover.size() != 4: return false
		for value in cover:
			if not _number(value): return false
	for convoy in data.get("convoys", []):
		if not convoy is Dictionary or not _valid_position(convoy.get("pos")) or not convoy.has_all(["time", "hp", "total", "reward"]): return false
		if not _number(convoy.time) or not _number(convoy.hp) or not _number(convoy.total) or convoy.total <= 0: return false
		if not convoy.reward is Dictionary: return false
		for good in WarEconomy.GOODS:
			if not _number(convoy.reward.get(good)): return false
	squads.clear()
	for unit in data.squads:
		var squad = CombatSquad.new(int(unit.id), int(unit.team), unit.kind, Vector2(unit.pos[0], unit.pos[1]))
		squad.hp = clampf(unit.hp, 0.0, squad.max_hp)
		squad.alive = squad.hp > 0
		squad.suppression = clampf(unit.get("suppression", 0.0), 0.0, 100.0)
		squad.veterancy = maxf(0, unit.get("veterancy", 0.0))
		squad.cooldown = maxf(0, unit.get("cooldown", 0.0))
		squad.ability_cd = maxf(0, unit.get("ability_cd", 0.0))
		squad.facing = unit.get("facing", 0.0)
		squad.kills = int(unit.get("kills", 0))
		squad.target_id = int(unit.get("target_id", -1))
		var order_value = str(unit.get("order", "hold"))
		if squad.alive and order_value in ["move", "attack", "retreat"]:
			_move(squad, Vector2(unit.destination[0], unit.destination[1]), order_value)
		squads.append(squad)
	for i in range(5):
		points[i].owner = int(data.points[i].owner)
		points[i].progress = clampf(data.points[i].progress, -1.0, 1.0)
		points[i].contested = false
	covers.clear()
	for cover in data.get("covers", []): covers.append({"a": Vector2(cover[0], cover[1]), "b": Vector2(cover[2], cover[3])})
	convoys.clear()
	for convoy in data.get("convoys", []):
		var entry: Dictionary = convoy.duplicate(true)
		entry.pos = Vector2(convoy.pos[0], convoy.pos[1])
		convoys.append(entry)
	economy.credits = maxf(0, econ.credits)
	for key in ["cargo", "stock", "demand", "prices", "history"]: economy.set(key, econ[key].duplicate(true))
	economy.headline = str(econ.get("headline", "Trade lanes open."))
	economy.turn = int(econ.get("turn", 0))
	economy.income = float(econ.get("income", 0))
	economy.rng.state = int(data.get("economy_rng", "17"))
	rng.state = int(data.get("rng_state", "42"))
	selected.clear()
	for id in data.get("selected", []):
		var squad = get_squad(int(id))
		if squad and squad.alive and squad.team == 0: selected.append(int(id))
	tickets = [clampf(data.tickets[0], 0, 300), clampf(data.tickets[1], 0, 300)]
	kills = data.get("kills", [0, 0]).duplicate()
	elapsed = maxf(0.0, data.get("elapsed", 0.0))
	captures = int(data.get("captures", 0))
	next_id = int(data.get("next_id", 0))
	for id in ids: next_id = maxi(next_id, id + 1)
	enemy_credits = maxf(0, data.get("enemy_credits", 0))
	difficulty = clampi(int(data.get("difficulty", 1)), 0, 2)
	var clocks = data.get("clocks", [0, 0, 0])
	if clocks is Array and clocks.size() == 3:
		_market_clock = float(clocks[0])
		_ai_clock = float(clocks[1])
		_ticket_clock = float(clocks[2])
	finished = false
	winner = -1
	_reconnect()
	_update_visibility()
	changed.emit()
	return true

func _number(value: Variant) -> bool:
	return (value is float or value is int) and is_finite(float(value))

func _valid_position(value: Variant) -> bool:
	return value is Array and value.size() == 2 and _number(value[0]) and _number(value[1]) and value[0] >= 0 and value[0] <= WORLD.x and value[1] >= 0 and value[1] <= WORLD.y
