class_name BattlefieldView
extends Node2D

signal selection_changed
signal ability_consumed
var battle: BattleSimulation
var camera: Camera2D
var terrain: BattlefieldTerrain
var ability_mode: bool = false
var attack_mode: bool = false
var markers: Array[Dictionary] = []
var tracers: Array[Dictionary] = []
var blasts: Array[Dictionary] = []
var actor_positions: Dictionary = {}
var label_style: StyleBoxFlat
var time: float = 0.0
var font = preload("res://assets/fonts/FieldMono.ttf")
var bold = preload("res://assets/fonts/FieldSans-Semibold.ttf")
var _drag_start = Vector2.ZERO
var _drag_last = Vector2.ZERO
var _dragging: bool = false
var _drag_distance: float = 0.0
var _touches = {}
var _pinch_start: float = 0.0
var _pinched: bool = false
var _zoom_start: float = 0.65
var _press_msec: int = 0
const FRIEND = Color("8ed1c1")
const ENEMY = Color("e49678")
const GOLD = Color("e5c184")

func _ready() -> void:
	terrain = BattlefieldTerrain.new()
	terrain.battle = battle
	terrain.z_index = -10
	add_child(terrain)
	camera = Camera2D.new()
	camera.position = Vector2(1160, 970)
	camera.zoom = Vector2.ONE * 0.66
	add_child(camera)
	move_child(camera, 0)
	get_viewport().size_changed.connect(_clamp_camera)
	_clamp_camera()
	battle.shot.connect(func(a, b, team, heavy): tracers.append({"a": a, "b": b, "team": team, "time": 0.17, "heavy": heavy}))
	battle.explosion.connect(func(p, radius): blasts.append({"p": p, "radius": radius, "time": 0.65}))

func _process(delta: float) -> void:
	time += delta
	for squad in battle.squads:
		var previous: Vector2 = actor_positions.get(squad.id, squad.pos)
		actor_positions[squad.id] = previous.lerp(squad.pos, 1.0 - exp(-delta * 22.0)) if previous.distance_to(squad.pos) < 160.0 else squad.pos
	for array in [markers, tracers, blasts]:
		for i in range(array.size() - 1, -1, -1):
			array[i].time -= delta
			if array[i].time <= 0: array.remove_at(i)
	if not battle.paused:
		var direction = Vector2.ZERO
		if Input.is_physical_key_pressed(KEY_W) or Input.is_physical_key_pressed(KEY_UP): direction.y -= 1
		if Input.is_physical_key_pressed(KEY_S) or Input.is_physical_key_pressed(KEY_DOWN): direction.y += 1
		if Input.is_physical_key_pressed(KEY_A) or Input.is_physical_key_pressed(KEY_LEFT): direction.x -= 1
		if Input.is_physical_key_pressed(KEY_D) or Input.is_physical_key_pressed(KEY_RIGHT): direction.x += 1
		if direction != Vector2.ZERO: pan(direction * 700.0 * delta / camera.zoom.x)
	queue_redraw()

func pan(amount: Vector2) -> void:
	camera.position += amount
	_clamp_camera()

func focus(at: Vector2) -> void:
	camera.position = at
	_clamp_camera()

func zoom_by(amount: float, anchor: Vector2 = Vector2(-1, -1)) -> void:
	var before = screen_to_world(anchor) if anchor.x >= 0 else Vector2.ZERO
	camera.zoom = Vector2.ONE * clampf(camera.zoom.x * amount, _minimum_zoom(), 1.45)
	if anchor.x >= 0:
		camera.position += before - screen_to_world(anchor)
	_clamp_camera()

func _clamp_camera() -> void:
	if camera == null: return
	camera.zoom = Vector2.ONE * maxf(camera.zoom.x, _minimum_zoom())
	var half = get_viewport_rect().size / camera.zoom / 2.0
	camera.position.x = clampf(camera.position.x, half.x, BattleSimulation.WORLD.x - half.x)
	camera.position.y = clampf(camera.position.y, half.y, BattleSimulation.WORLD.y - half.y)

func _minimum_zoom() -> float:
	var viewport = get_viewport_rect().size
	return minf(1.45, maxf(0.48, maxf(viewport.x / BattleSimulation.WORLD.x, viewport.y / BattleSimulation.WORLD.y)))

func screen_to_world(p: Vector2) -> Vector2:
	return get_canvas_transform().affine_inverse() * p

func _unhandled_input(event: InputEvent) -> void:
	if battle.paused or battle.finished: return
	# Controls use Godot's touch-to-mouse bridge; the battlefield handles native
	# touch itself, so ignore the synthetic mouse copy to avoid duplicate orders.
	if event is InputEventMouse and event.device == InputEvent.DEVICE_ID_EMULATION: return
	if event is InputEventScreenTouch:
		if event.pressed:
			_touches[event.index] = event.position
			if _touches.size() == 1:
				_start_drag(event.position)
				_pinched = false
			elif _touches.size() == 2:
				_pinch_start = _touches.values()[0].distance_to(_touches.values()[1])
				_zoom_start = camera.zoom.x
				_pinched = true
		else:
			_touches.erase(event.index)
			if _touches.is_empty():
				if not _pinched: _end_drag(event.position)
				_dragging = false
		get_viewport().set_input_as_handled()
	elif event is InputEventScreenDrag:
		_touches[event.index] = event.position
		if _touches.size() == 2 and _pinch_start > 0:
			var distance = _touches.values()[0].distance_to(_touches.values()[1])
			camera.zoom = Vector2.ONE * clampf(_zoom_start * distance / _pinch_start, _minimum_zoom(), 1.45)
			_clamp_camera()
		elif not _pinched:
			_drag(event.position)
		get_viewport().set_input_as_handled()
	elif event is InputEventMouseButton:
		if event.button_index == MOUSE_BUTTON_WHEEL_UP and event.pressed: zoom_by(1.12, event.position)
		elif event.button_index == MOUSE_BUTTON_WHEEL_DOWN and event.pressed: zoom_by(1.0 / 1.12, event.position)
		elif event.button_index == MOUSE_BUTTON_LEFT or event.button_index == MOUSE_BUTTON_MIDDLE:
			if event.pressed: _start_drag(event.position)
			else: _end_drag(event.position, event.button_index == MOUSE_BUTTON_MIDDLE)
		elif event.button_index == MOUSE_BUTTON_RIGHT and event.pressed:
			_issue(screen_to_world(event.position))
	elif event is InputEventMouseMotion and _dragging:
		_drag(event.position)
	elif event is InputEventKey and event.pressed and not event.echo:
		var key = event.physical_keycode
		if key >= KEY_1 and key <= KEY_8:
			var units = battle.living(0)
			var index = key - KEY_1
			if index < units.size(): battle.select_squad(units[index].id, event.shift_pressed)
		elif key == KEY_F and not battle.selected.is_empty(): focus(battle.get_squad(battle.selected[0]).pos)
		elif key == KEY_HOME: focus(BattleSimulation.BASES[0])
		elif key == KEY_R: battle.retreat_selected()
		elif key == KEY_H: battle.hold_selected()
		elif key == KEY_G: ability_mode = not ability_mode

func _start_drag(at: Vector2) -> void:
	_press_msec = Time.get_ticks_msec()
	_drag_start = at
	_drag_last = at
	_drag_distance = 0.0
	_dragging = true

func _drag(at: Vector2) -> void:
	if not _dragging: return
	_drag_distance += at.distance_to(_drag_last)
	if _drag_distance > 12.0: pan((_drag_last - at) / camera.zoom.x)
	_drag_last = at

func _end_drag(at: Vector2, pan_only: bool = false) -> void:
	if _dragging and _drag_distance < 12.0 and not pan_only:
		var world_pos = screen_to_world(at)
		if ability_mode:
			if battle.ability(world_pos):
				ability_mode = false
				ability_consumed.emit()
		elif not battle.select_at(world_pos, Input.is_physical_key_pressed(KEY_SHIFT) or Time.get_ticks_msec() - _press_msec > 450):
			_issue(world_pos)
	_dragging = false

func _issue(at: Vector2) -> void:
	if battle.selected.is_empty():
		battle.notice.emit("Select a squad first. Tap a squad on the map or its card below.")
		return
	battle.command(at, attack_mode)
	markers.append({"p": battle.walkable(at), "time": 1.5})
	attack_mode = false

func _draw() -> void:
	if battle == null: return
	# Supply routes: disconnected lines remain as a cartographic reference.
	for link in BattleSimulation.LINKS:
		var a = battle.points[link[0]]
		var b = battle.points[link[1]]
		var c = Color(0.9, 0.87, 0.69, 0.14)
		if a.owner == 0 and b.owner == 0 and a.linked and b.linked: c = Color(FRIEND, 0.5)
		elif a.owner == 1 and b.owner == 1 and a.linked and b.linked: c = Color(ENEMY, 0.3)
		dashed(a.pos, b.pos, c, 3.0)
	for cover in battle.covers:
		var length = cover.a.distance_to(cover.b)
		var direction = (cover.b - cover.a).normalized()
		for i in range(int(length / 13.0) + 1):
			var p: Vector2 = cover.a + direction * i * 13.0
			draw_circle(p + Vector2(3, 5), 8, Color(0.12, 0.19, 0.12, 0.35))
			draw_circle(p, 8, Color("b5a276"))
			draw_arc(p + Vector2(-1, -2), 5, PI, TAU, 8, Color("d1c090"), 2, true)
	for squad in battle.squads:
		if squad.alive or squad.team == 0:
			if squad.team == 1 and not battle.visible_at(squad.pos): continue
			_draw_squad(squad)
	for convoy in battle.convoys:
		var p: Vector2 = convoy.pos
		draw_rect(Rect2(p + Vector2(-14, -24), Vector2(28, 48)), Color("293c33"))
		draw_rect(Rect2(p + Vector2(-11, -20), Vector2(22, 30)), Color("b2aa86"))
		draw_rect(Rect2(p + Vector2(-10, 13), Vector2(20, 9)), FRIEND)
		draw_string(font, p + Vector2(20, 0), "CONVOY", HORIZONTAL_ALIGNMENT_LEFT, -1, 14, FRIEND)
	# Ground intel is visible; fog hides moving enemy squads and darkens unexplored cells.
	if battle.fog:
		for y in range(12):
			for x in range(16):
				var center = Vector2(x * 160 + 80, y * 160 + 80)
				if not battle.visible_at(center):
					var alpha = 0.14 if battle.explored.has(Vector2i(x, y)) else 0.34
					draw_rect(Rect2(x * 160, y * 160, 160, 160), Color(0.07, 0.13, 0.12, alpha))
	for point in battle.points: _draw_point(point)
	for tracer in tracers:
		if not battle.visible_at(tracer.a) and not battle.visible_at(tracer.b): continue
		var color = Color("ffdd8e") if tracer.team == 0 else Color("ffb384")
		draw_line(tracer.a, tracer.b, Color(color, tracer.time / 0.17), 3.5 if tracer.heavy else 1.8, true)
		draw_circle(tracer.a, 6 if tracer.heavy else 3, color)
	for blast in blasts:
		var progress = 1.0 - blast.time / 0.65
		draw_circle(blast.p, blast.radius * progress, Color(0.94, 0.65, 0.3, (1.0 - progress) * 0.45))
		draw_arc(blast.p, maxf(1.0, blast.radius * progress), 0, TAU, 32, Color(0.98, 0.86, 0.59, 1.0 - progress), 4, true)
	for marker in markers:
		var radius = 12.0 + (1.5 - marker.time) * 18.0
		draw_arc(marker.p, radius, 0, TAU, 32, Color(GOLD, marker.time / 1.5), 2.5, true)
		draw_line(marker.p - Vector2(8, 0), marker.p + Vector2(8, 0), GOLD, 2)
		draw_line(marker.p - Vector2(0, 8), marker.p + Vector2(0, 8), GOLD, 2)
	if ability_mode and not battle.selected.is_empty():
		var squad = battle.get_squad(battle.selected[0])
		if squad:
			draw_arc(squad.pos, 180 if squad.kind == "engineer" else 310, 0, TAU, 80, Color(GOLD, 0.6), 2, true)

func _draw_point(point: Dictionary) -> void:
	var p: Vector2 = point.pos
	var color = FRIEND if point.owner == 0 else (ENEMY if point.owner == 1 else GOLD)
	draw_circle(p, 95, Color(color, 0.045))
	draw_arc(p, 95, 0, TAU, 64, Color(color, 0.28), 2, true)
	if point.contested:
		draw_arc(p, 98, time * 1.5, time * 1.5 + 4.5, 50, ENEMY, 4, true)
	elif absf(point.progress) > 0.01 and absf(point.progress) < 1.0:
		draw_arc(p, 98, -PI / 2, -PI / 2 + TAU * absf(point.progress), 50, FRIEND if point.progress < 0 else ENEMY, 4, true)
	draw_line(p + Vector2(3, 3), p + Vector2(3, -60), Color(0.13, 0.2, 0.17, 0.7), 5, true)
	draw_line(p, p + Vector2(0, -65), Color("d1ccb0"), 3, true)
	draw_colored_polygon(PackedVector2Array([p + Vector2(0, -65), p + Vector2(37, -58), p + Vector2(31, -38), p + Vector2(0, -44)]), color)
	draw_circle(p + Vector2(0, 1), 22, Color("1b3028"))
	draw_arc(p, 23, 0, TAU, 28, color, 2, true)
	draw_string(bold, p + Vector2(-7, 8), point.code, HORIZONTAL_ALIGNMENT_LEFT, -1, 21, color)
	var label_pos = p + Vector2(-100, 125)
	draw_style_box(_label_box(), Rect2(label_pos + Vector2(-4, -21), Vector2(208, 51)))
	draw_string(font, label_pos, point.name, HORIZONTAL_ALIGNMENT_CENTER, 200, 15, Color("e5dfc5"))
	var sub = WarEconomy.NAMES[point.good].to_upper() + (" / LINKED" if point.linked else " / CUT OFF") if point.owner >= 0 else WarEconomy.NAMES[point.good].to_upper() + " / NEUTRAL"
	draw_string(font, label_pos + Vector2(0, 20), sub, HORIZONTAL_ALIGNMENT_CENTER, 200, 11, color)

func _label_box() -> StyleBoxFlat:
	if label_style != null: return label_style
	var style = StyleBoxFlat.new()
	style.bg_color = Color(0.07, 0.12, 0.1, 0.85)
	style.corner_radius_top_left = 3
	style.corner_radius_top_right = 3
	style.corner_radius_bottom_left = 3
	style.corner_radius_bottom_right = 3
	label_style = style
	return style

func _draw_squad(squad: CombatSquad) -> void:
	var p: Vector2 = actor_positions.get(squad.id, squad.pos)
	if not squad.alive:
		draw_line(p - Vector2(9, 9), p + Vector2(9, 9), Color(0.15, 0.2, 0.14, 0.4), 4)
		draw_line(p + Vector2(-9, 9), p + Vector2(9, -9), Color(0.15, 0.2, 0.14, 0.4), 4)
		return
	var color = FRIEND if squad.team == 0 else ENEMY
	var is_selected = squad.id in battle.selected
	if is_selected:
		draw_circle(p, 43, Color(GOLD, 0.08))
		draw_arc(p, 43, 0, TAU, 40, GOLD, 2.4, true)
		for angle in [0.0, PI / 2, PI, PI * 1.5]:
			var off = Vector2.from_angle(angle)
			draw_line(p + off * 45, p + off * 52, GOLD, 3, true)
		if squad.route.size() > 1:
			var path = PackedVector2Array([p])
			path.append_array(squad.route)
			draw_polyline(path, Color(GOLD, 0.3), 2, true)
	if squad.kind == "armor":
		draw_set_transform(p + Vector2(6, 8), squad.facing)
		draw_style_box(_label_box(), Rect2(-28, -19, 56, 38))
		draw_set_transform(p, squad.facing)
		draw_rect(Rect2(-25, -20, 50, 8), Color("29382f"))
		draw_rect(Rect2(-25, 12, 50, 8), Color("29382f"))
		draw_rect(Rect2(-23, -14, 46, 28), Color("acaa80") if squad.team == 0 else Color("9c7b60"))
		draw_rect(Rect2(-7, -10, 23, 20), Color("6e8062"))
		draw_line(Vector2(8, 0), Vector2(43, 0), Color("d4cfac"), 5, true)
		draw_rect(Rect2(-15, -12, 6, 24), color)
		draw_set_transform(Vector2.ZERO)
	else:
		for i in range(squad.members()):
			var angle = TAU * float(i) / squad.data().men + squad.facing * 0.2
			var offset = Vector2.from_angle(angle) * (22 if i > 0 else 3)
			var walk = sin(time * 12.0 + i * 2) * 2.0 if squad.moving else 0.0
			var soldier_pos = p + offset + Vector2(walk, -walk)
			var direction = Vector2.from_angle(squad.facing)
			draw_circle(soldier_pos + Vector2(4, 5), 9, Color(0.07, 0.12, 0.08, 0.4))
			draw_line(soldier_pos - direction * 6 + direction.orthogonal() * 3, soldier_pos + direction * 3 + direction.orthogonal() * 3, Color("293c2e"), 5, true)
			draw_line(soldier_pos - direction * 6 - direction.orthogonal() * 3, soldier_pos + direction * 3 - direction.orthogonal() * 3, Color("293c2e"), 5, true)
			draw_circle(soldier_pos, 7, Color("c5ba8e") if squad.team == 0 else Color("b59b80"))
			draw_line(soldier_pos, soldier_pos + direction * 17, Color("26382d"), 3, true)
			draw_circle(soldier_pos - direction * 2, 5.5, Color("5e7456") if squad.team == 0 else Color("76634d"))
			draw_arc(soldier_pos - direction * 2, 5.0, PI, TAU, 8, Color("a4af88"), 1.5, true)
			if squad.shot_flash > 0.0 and i < 2:
				draw_circle(soldier_pos + direction * 21, 4, Color("ffe4a0"))
	# Readable unit badge and two status bars float above the formation.
	var badge = p + Vector2(0, -53)
	draw_rect(Rect2(badge - Vector2(23, 16), Vector2(46, 28)), Color("182b24"))
	draw_rect(Rect2(badge - Vector2(23, 16), Vector2(46, 28)), GOLD if is_selected else color, false, 1.8)
	var glyph = {"rifle": "I", "assault": ">>", "support": "MG", "engineer": "+", "armor": "<>"}[squad.kind]
	draw_string(font, badge + Vector2(-18, 5), glyph, HORIZONTAL_ALIGNMENT_CENTER, 36, 16, GOLD if is_selected else color)
	draw_rect(Rect2(p + Vector2(-27, -38), Vector2(54, 5)), Color("26362d"))
	draw_rect(Rect2(p + Vector2(-27, -38), Vector2(54 * squad.hp / squad.max_hp, 5)), color)
	if squad.suppression > 12:
		draw_rect(Rect2(p + Vector2(-27, -30), Vector2(54 * squad.suppression / 100.0, 3)), GOLD)
	if squad.cover > 0.0:
		draw_colored_polygon(PackedVector2Array([p + Vector2(33, -38), p + Vector2(44, -38), p + Vector2(44, -29), p + Vector2(38.5, -24), p + Vector2(33, -29)]), FRIEND)
	if squad.suppression > 72:
		draw_string(font, p + Vector2(-40, 60), "PINNED", HORIZONTAL_ALIGNMENT_CENTER, 80, 14, ENEMY)
	elif squad.order == "retreat":
		draw_string(font, p + Vector2(-48, 60), "RETREAT", HORIZONTAL_ALIGNMENT_CENTER, 96, 14, GOLD)
	elif is_selected:
		draw_string(font, p + Vector2(-45, 63), squad.title, HORIZONTAL_ALIGNMENT_CENTER, 90, 14, Color("e7dec1"))

func dashed(a: Vector2, b: Vector2, color: Color, width: float) -> void:
	var length = a.distance_to(b)
	var direction = a.direction_to(b)
	var d = 0.0
	while d < length:
		draw_line(a + direction * d, a + direction * minf(length, d + 12), color, width, true)
		d += 25.0
