class_name TheaterCampaign
extends RefCounted

signal changed
signal notice(text: String)
signal battle_requested(context: Dictionary)

const CAPITALS = [10, 4]
const REGION_NAMES = ["NORTHWATCH", "PINE REACH", "GREY RIDGE", "ASH FOUNDRY", "IRON CROWN", "WESTMERE", "GREEN VALE", "MERIDIAN", "RED QUARRY", "EASTGATE", "HAVEN", "SALT MARSH", "SUNFIELD", "CINDER PORT", "DUSK COAST"]
const BIOMES = ["forest", "forest", "ridge", "city", "city", "farmland", "farmland", "canal", "ridge", "city", "canal", "canal", "farmland", "city", "ridge"]
const GOODS = ["supplies", "supplies", "ammo", "ammo", "fuel", "supplies", "supplies", "fuel", "ammo", "fuel", "supplies", "fuel", "supplies", "fuel", "ammo"]
const TECHNOLOGIES = {
	"signals": {"name": "Signal corps", "turns": 2, "cost": {"credits": 280, "ammo": 25}, "description": "Unlock pathfinders and marksmen. Scouts reveal more terrain."},
	"ordnance": {"name": "Advanced ordnance", "turns": 3, "cost": {"credits": 400, "ammo": 40}, "description": "Unlock mortar batteries and anti-tank guns."},
	"mechanized": {"name": "Mechanized warfare", "turns": 3, "cost": {"credits": 520, "fuel": 45}, "description": "Unlock Vanguard tanks and flame pioneers."},
	"logistics": {"name": "Motorized logistics", "turns": 2, "cost": {"credits": 320, "fuel": 25}, "description": "Armies gain a third movement point and pay 20% less upkeep."},
	"medicine": {"name": "Field hospitals", "turns": 2, "cost": {"credits": 300, "supplies": 40}, "description": "Doubles passive recovery in connected friendly provinces."}
}
const BUILDINGS = {
	"industry": {"name": "Industry", "turns": 2, "cost": {"credits": 180, "supplies": 20}, "description": "+25% province income and +4 commodity output per level."},
	"fort": {"name": "Fortifications", "turns": 2, "cost": {"credits": 160, "supplies": 25}, "description": "+1 garrison section and +40 defensive command strength per level."},
	"depot": {"name": "Supply depot", "turns": 1, "cost": {"credits": 140, "fuel": 12}, "description": "+6 supplies per turn and faster army resupply in this province."}
}

var regions: Array[Dictionary] = []
var armies: Array[Dictionary] = []
var markets: Array[WarEconomy] = []
var economy = WarEconomy.new()
var turn: int = 1
var phase: String = "player"
var difficulty: int = 1
var selected_army: int = 0
var selected_region: int = 10
var technology: Array[String] = []
var research: Dictionary = {}
var pending: Dictionary = {}
var enemy_queue: Array[int] = []
var journal: Array[String] = []
var next_army: int = 0
var next_unit: int = 0
var battle_serial: int = 0
var last_resolved: int = -1
var enemy_credits: float = 650.0
var seed_value: int = 42
var rng = RandomNumberGenerator.new()
var victories: int = 0

func setup(level: int = 1, seed_number: int = 42) -> void:
	difficulty = clampi(level, 0, 2)
	seed_value = seed_number
	rng.seed = seed_number
	economy = WarEconomy.new(seed_number)
	economy.credits = 1900 if difficulty == 0 else (1500 if difficulty == 1 else 1250)
	enemy_credits = 420 if difficulty == 0 else (650 if difficulty == 1 else 850)
	economy.cargo = {"supplies": 150.0, "ammo": 140.0, "fuel": 90.0}
	regions.clear()
	armies.clear()
	markets.clear()
	for i in range(15):
		var owner = 0 if i in [5, 6, 10, 11] else (1 if i in [2, 3, 4, 8, 9, 13, 14] else -1)
		regions.append({"id": i, "name": REGION_NAMES[i], "biome": BIOMES[i], "good": GOODS[i], "owner": owner, "industry": 1 if i in CAPITALS else 0, "fort": 1 if i in CAPITALS else 0, "depot": 1 if i in CAPITALS else 0, "garrison": 2 if owner >= 0 else 1, "loyalty": 100.0 if owner >= 0 else 70.0, "job": {}, "connected": false, "battled": 0})
		var market = WarEconomy.new(seed_number + i * 17)
		for good in WarEconomy.GOODS:
			market.stock[good] = 240.0 if good == GOODS[i] else 65.0 + rng.randf_range(0, 55)
		market._reprice(false)
		for good in WarEconomy.GOODS:
			market.history[good].fill(market.prices[good])
		markets.append(market)
	_new_army(0, "1ST EXPEDITIONARY", 10, ["rifle", "rifle", "support", "engineer"])
	_new_army(0, "2ND RANGERS", 6, ["rifle", "assault", "medic"])
	_new_army(1, "IRON LEGION", 8, ["rifle", "support", "assault", "engineer"])
	_new_army(1, "CROWN GUARD", 4, ["rifle", "support", "armor"])
	_reconnect()
	_log("A new front opens. Select an army, then a neighbouring province to march or attack.")

static func position_of(id: int) -> Vector2:
	var row = id / 5
	var column = id % 5
	return Vector2(220 + column * 285 + (65 if row % 2 == 1 else 0), 220 + row * 315)

static func neighbours(id: int) -> Array[int]:
	var row = id / 5
	var column = id % 5
	var result: Array[int] = []
	for offset in [Vector2i(-1, 0), Vector2i(1, 0), Vector2i(0, -1), Vector2i(0, 1), Vector2i(1 if row % 2 == 1 else -1, -1), Vector2i(1 if row % 2 == 1 else -1, 1)]:
		var c = column + offset.x
		var r = row + offset.y
		if c >= 0 and c < 5 and r >= 0 and r < 3: result.append(r * 5 + c)
	return result

func army(id: int) -> Dictionary:
	for entry in armies:
		if entry.id == id: return entry
	return {}

func army_at(region_id: int, team: int = -1) -> Dictionary:
	for entry in armies:
		if entry.region == region_id and (team < 0 or entry.team == team): return entry
	return {}

func player_armies() -> Array[Dictionary]:
	var result: Array[Dictionary] = []
	for entry in armies:
		if entry.team == 0: result.append(entry)
	return result

func owned_count(team: int) -> int:
	var result = 0
	for region in regions:
		if region.owner == team: result += 1
	return result

func _new_unit(kind: String) -> Dictionary:
	var entry = {"uid": next_unit, "kind": kind, "hp": CombatSquad.TYPES[kind].hp, "veterancy": 0.0, "kills": 0}
	next_unit += 1
	return entry

func _new_army(team: int, title: String, region_id: int, kinds: Array) -> Dictionary:
	var roster = []
	for kind in kinds: roster.append(_new_unit(kind))
	var entry = {"id": next_army, "team": team, "name": title, "region": region_id, "roster": roster, "movement": 2, "supply": 100.0, "stance": "march"}
	next_army += 1
	armies.append(entry)
	return entry

func allowed_kinds() -> Array[String]:
	var result: Array[String] = []
	for kind in CombatSquad.TYPES:
		if CombatSquad.TYPES[kind].get("tech", "") in technology or not CombatSquad.TYPES[kind].has("tech"): result.append(kind)
	return result

func strength(roster: Array) -> float:
	var value = 0.0
	for unit in roster:
		var data: Dictionary = CombatSquad.TYPES[unit.kind]
		value += data.cost.credits * clampf(unit.hp / data.hp, 0.0, 1.0) * (1.0 + minf(3, unit.veterancy / 130.0) * 0.12)
	return value

func route(from: int, to: int, team: int = 0) -> Array[int]:
	var queue: Array[int] = [from]
	var previous = {from: -1}
	while not queue.is_empty():
		var here = queue.pop_front()
		if here == to: break
		for next in neighbours(here):
			if previous.has(next): continue
			if next != to and regions[next].owner != team: continue
			if next != to and not army_at(next, team).is_empty(): continue
			previous[next] = here
			queue.append(next)
	var result: Array[int] = []
	if not previous.has(to): return result
	var cursor = to
	while cursor >= 0:
		result.push_front(cursor)
		cursor = previous[cursor]
	return result

func can_march(id: int, destination: int) -> String:
	if phase != "player": return "Finish the current phase first."
	var entry = army(id)
	if entry.is_empty() or entry.team != 0: return "Select one of your armies."
	if destination < 0 or destination >= regions.size() or destination == entry.region: return "Choose a different province."
	var occupant = army_at(destination, 0)
	if not occupant.is_empty() and occupant.id != id: return "Another allied army holds that province. Move it first."
	var path = route(entry.region, destination)
	if path.is_empty() or path.size() - 1 > entry.movement: return "Not enough movement. Choose an adjacent province or end the turn."
	if economy.cargo.fuel < path.size() - 1: return "The march needs %d fuel." % (path.size() - 1)
	return ""

func march(id: int, destination: int) -> bool:
	var error = can_march(id, destination)
	if error != "": return _reject(error)
	var entry = army(id)
	var cost = route(entry.region, destination).size() - 1
	economy.cargo.fuel -= cost
	entry.movement -= cost
	selected_army = id
	selected_region = destination
	if regions[destination].owner != 0:
		if regions[destination].garrison > 0 or not army_at(destination, 1).is_empty():
			_request_battle(entry, destination)
		else:
			_occupy(destination, 0)
			entry.region = destination
			_log("%s secured %s without opposition." % [entry.name, regions[destination].name.capitalize()])
	else:
		entry.region = destination
		_log("%s marched to %s." % [entry.name, regions[destination].name.capitalize()])
	_reconnect()
	if phase == "player": _check_campaign_end()
	changed.emit()
	return true

func recruit(id: int, kind: String) -> bool:
	var entry = army(id)
	if phase != "player" or entry.is_empty() or entry.team != 0: return _reject("Select an allied army during your turn.")
	if kind not in allowed_kinds(): return _reject("Research this unit's technology first.")
	if entry.roster.size() >= 8: return _reject("An army can command at most eight sections.")
	if not regions[entry.region].connected: return _reject("Reconnect this army to Haven before recruiting.")
	if not economy.pay(CombatSquad.TYPES[kind].cost): return _reject("Insufficient resources. Trade, develop provinces, or end the turn.")
	entry.roster.append(_new_unit(kind))
	_log("%s joined %s." % [CombatSquad.TYPES[kind].name, entry.name])
	changed.emit()
	return true

func raise_army(region_id: int) -> bool:
	if phase != "player" or regions[region_id].owner != 0 or not regions[region_id].connected: return _reject("Raise armies in connected allied provinces.")
	if player_armies().size() >= 4 or not army_at(region_id, 0).is_empty(): return _reject("Four-army limit, or another army already occupies this province.")
	if not economy.pay({"credits": 300, "supplies": 25}): return _reject("Raising an army costs 300 credits and 25 supplies.")
	var entry = _new_army(0, "%dTH FIELD ARMY" % (next_army + 1), region_id, ["rifle"])
	selected_army = entry.id
	_log("A new field army is ready at %s." % regions[region_id].name.capitalize())
	changed.emit()
	return true

func reinforce(id: int) -> bool:
	var entry = army(id)
	if phase != "player" or entry.is_empty() or entry.team != 0 or not regions[entry.region].connected: return _reject("Reinforce an allied army in a connected province.")
	var price = {"credits": 0.0, "supplies": 0.0}
	for unit in entry.roster:
		var data: Dictionary = CombatSquad.TYPES[unit.kind]
		var missing = 1.0 - unit.hp / data.hp
		price.credits += ceil(data.cost.credits * 0.45 * missing)
		price.supplies += ceil(20 * missing)
	if price.credits <= 0: return _reject("This army is already at full strength.")
	if not economy.pay(price): return _reject("Replacements cost %d credits and %d supplies." % [price.credits, price.supplies])
	for unit in entry.roster: unit.hp = CombatSquad.TYPES[unit.kind].hp
	_log("%s reinforced. Veterans retained." % entry.name)
	changed.emit()
	return true

func set_stance(id: int, stance: String) -> bool:
	var entry = army(id)
	if phase != "player" or entry.is_empty() or entry.team != 0 or stance not in ["march", "entrench", "replenish"]: return false
	# Changing stance never refunds movement already spent this turn.
	entry.stance = stance
	entry.movement = mini(entry.movement, 0 if stance == "replenish" else (1 if stance == "entrench" else max_movement()))
	changed.emit()
	return true

func max_movement() -> int:
	return 3 if "logistics" in technology else 2

func construct(region_id: int, kind: String) -> bool:
	if phase != "player" or region_id < 0 or region_id >= regions.size() or not BUILDINGS.has(kind): return false
	var region = regions[region_id]
	if region.owner != 0 or not region.connected: return _reject("Build in a connected allied province.")
	if not region.job.is_empty() or region[kind] >= 3: return _reject("Construction already queued, or this building is at level three.")
	if not economy.pay(BUILDINGS[kind].cost): return _reject("Insufficient resources for construction.")
	region.job = {"kind": kind, "remaining": BUILDINGS[kind].turns}
	_log("%s commissioned at %s." % [BUILDINGS[kind].name, region.name.capitalize()])
	changed.emit()
	return true

func start_research(kind: String) -> bool:
	if phase != "player" or not TECHNOLOGIES.has(kind): return false
	if kind in technology or not research.is_empty(): return _reject("Research is complete, or another project is in progress.")
	if not economy.pay(TECHNOLOGIES[kind].cost): return _reject("Insufficient resources for this research.")
	research = {"kind": kind, "remaining": TECHNOLOGIES[kind].turns}
	_log("Research started: %s." % TECHNOLOGIES[kind].name)
	changed.emit()
	return true

func trade_access(region_id: int) -> bool:
	return phase == "player" and regions[region_id].owner == 0 and regions[region_id].connected and (region_id == CAPITALS[0] or not army_at(region_id, 0).is_empty())

func trade(region_id: int, good: String, buy: bool) -> bool:
	if not trade_access(region_id): return _reject("Markets need a supplied allied army or your capital. March an army here first.")
	if good not in WarEconomy.GOODS: return false
	var market = markets[region_id]
	var price = market.quote(good, buy)
	if buy:
		if economy.cargo[good] + 10 > 999: return _reject("Warehouse capacity reached (999 units).")
		if market.stock[good] < 10 or economy.credits < price: return _reject("Insufficient market stock or credits.")
		economy.credits -= price
		economy.cargo[good] += 10
		market.stock[good] -= 10
	else:
		if economy.cargo[good] < 10: return _reject("Not enough cargo to sell.")
		economy.credits += price
		economy.cargo[good] -= 10
		market.stock[good] += 10
	market._reprice(false)
	notice.emit(("Bought" if buy else "Sold") + " 10 %s for %d credits." % [WarEconomy.NAMES[good].to_lower(), price])
	changed.emit()
	return true

func projected_income() -> float:
	var result = 0.0
	for region in regions:
		if region.owner == 0 and region.connected: result += region_income(region)
	for entry in player_armies(): result -= upkeep(entry)
	return result

func region_income(region: Dictionary) -> float:
	return (65.0 + region.industry * 22.0) * (0.5 + region.loyalty / 200.0)

func upkeep(entry: Dictionary) -> float:
	return entry.roster.size() * 14.0 * (0.8 if "logistics" in technology and entry.team == 0 else 1.0)

func end_turn() -> bool:
	if phase != "player": return false
	phase = "enemy"
	turn += 1
	_reconnect()
	var income = projected_income()
	economy.credits = maxf(0.0, economy.credits + income)
	for region in regions:
		if region.owner == 0 and region.connected:
			economy.cargo[region.good] = minf(999.0, economy.cargo[region.good] + 10.0 + region.industry * 4.0)
			economy.cargo.supplies = minf(999, economy.cargo.supplies + region.depot * 6.0)
			region.loyalty = minf(100.0, region.loyalty + 7.0)
			if not region.job.is_empty():
				region.job.remaining -= 1
				if region.job.remaining <= 0:
					region[region.job.kind] += 1
					if region.job.kind == "fort": region.garrison = mini(5, region.garrison + 1)
					_log("Construction completed in %s." % region.name.capitalize())
					region.job = {}
		if region.owner == 1 and region.connected: enemy_credits += (40 if difficulty == 0 else (55 if difficulty == 1 else 70)) + region.industry * 12
		var market = markets[region.id]
		market.tick({}, 0, 5.0 if region.battled > 0 else 0.3, 0)
		market.stock[region.good] += 14.0 + region.industry * 6.0
		if region.owner >= 0 and not region.connected:
			for good in WarEconomy.GOODS: market.stock[good] = maxf(6, market.stock[good] - 9)
		market._reprice(false)
		region.battled = maxi(0, region.battled - 1)
	if not research.is_empty():
		research.remaining -= 1
		if research.remaining <= 0:
			technology.append(research.kind)
			_log("Research complete: %s." % TECHNOLOGIES[research.kind].name)
			research = {}
	for entry in armies:
		var supplied: bool = regions[entry.region].owner == entry.team and regions[entry.region].connected
		entry.supply = clampf(entry.supply + (25 if supplied else -22), 0, 100)
		for unit in entry.roster:
			var max_hp: float = CombatSquad.TYPES[unit.kind].hp
			if supplied and entry.stance == "replenish": unit.hp = minf(max_hp, unit.hp + max_hp * (0.24 if "medicine" in technology and entry.team == 0 else 0.12))
			elif entry.supply < 25: unit.hp = maxf(1, unit.hp - max_hp * 0.07)
		if entry.team == 0:
			entry.movement = (0 if entry.stance == "replenish" else (1 if entry.stance == "entrench" else max_movement())) if entry.supply >= 25 else 1
		else:
			entry.movement = 1
			enemy_credits = maxf(0, enemy_credits - upkeep(entry))
			if supplied and (difficulty != 0 or turn % 2 == 0): _enemy_recruit(entry)
	_log("Turn %d. Net income %+d credits. Opposition manoeuvres." % [turn, int(income)])
	enemy_queue.clear()
	for entry in armies:
		if entry.team == 1: enemy_queue.append(entry.id)
	advance_enemy_phase()
	changed.emit()
	return true

func _enemy_recruit(entry: Dictionary) -> void:
	if entry.roster.size() >= 7 or enemy_credits < 180: return
	var kinds = ["rifle", "assault", "support", "engineer", "medic"]
	if turn >= 3: kinds.append_array(["atgun", "mortar", "recon"])
	if turn >= 6: kinds.append("tank")
	var opposing_armor = false
	for other in player_armies():
		if other.region in neighbours(entry.region):
			for unit in other.roster:
				if CombatSquad.TYPES[unit.kind].get("vehicle", false): opposing_armor = true
	var kind: String = "atgun" if opposing_armor and turn >= 3 else kinds[rng.randi_range(0, kinds.size() - 1)]
	if enemy_credits >= CombatSquad.TYPES[kind].cost.credits:
		enemy_credits -= CombatSquad.TYPES[kind].cost.credits
		entry.roster.append(_new_unit(kind))

func advance_enemy_phase() -> void:
	if phase != "enemy": return
	while not enemy_queue.is_empty():
		var id = enemy_queue.pop_front()
		var entry = army(id)
		if entry.is_empty(): continue
		var best = -1
		var best_score = -INF
		for destination in neighbours(entry.region):
			if not army_at(destination, 1).is_empty(): continue
			var region = regions[destination]
			var defenders = army_at(destination, 0)
			var defending_strength = strength(defenders.roster) if not defenders.is_empty() else 0.0
			defending_strength += region.garrison * 130.0 + region.fort * 90.0
			var score = 0.0
			if region.owner == 0:
				score = 500.0 + region.industry * 50.0 - defending_strength * 0.36
				if strength(entry.roster) < defending_strength * (0.7 if difficulty == 2 else 0.85): score -= 650
				if destination == CAPITALS[0]: score += 500
			elif region.owner == -1: score = 250.0
			else:
				score = 40.0 + (position_of(entry.region).distance_to(position_of(CAPITALS[0])) - position_of(destination).distance_to(position_of(CAPITALS[0]))) * 0.12
			# Protect an exposed capital instead of blindly streaming into the front.
			if entry.region == CAPITALS[1] and turn < 3: score -= 350
			score += rng.randf_range(0, 15)
			if score > best_score:
				best_score = score
				best = destination
		if best < 0 or best_score < 0: continue
		entry.movement = 0
		if regions[best].owner == 0:
			if regions[best].garrison == 0 and army_at(best, 0).is_empty():
				_occupy(best, 1)
				entry.region = best
				_reconnect()
				_check_campaign_end()
				if phase == "defeat":
					enemy_queue.clear()
					changed.emit()
					return
				continue
			_request_battle(entry, best)
			changed.emit()
			return
		if regions[best].owner == -1: _occupy(best, 1)
		entry.region = best
	_reconnect()
	phase = "player"
	_check_campaign_end()
	changed.emit()

func _garrison_roster(region_id: int) -> Array:
	var roster = []
	for i in range(regions[region_id].garrison):
		var kind = "support" if i == 1 else "rifle"
		roster.append({"uid": -100 - region_id * 10 - i, "kind": kind, "hp": CombatSquad.TYPES[kind].hp, "veterancy": regions[region_id].fort * 60.0, "kills": 0})
	return roster

func _request_battle(attacker: Dictionary, destination: int) -> void:
	var defender = army_at(destination, 1 - attacker.team)
	var defending_roster: Array = defender.roster.duplicate(true) if not defender.is_empty() else []
	defending_roster.append_array(_garrison_roster(destination))
	if defending_roster.size() > 8: defending_roster.resize(8)
	var attacking_roster: Array = attacker.roster.duplicate(true)
	var continuation = phase
	pending = {"id": battle_serial, "region": destination, "origin": attacker.region, "attacker": attacker.id, "defender": defender.get("id", -1), "attack_team": attacker.team, "continuation": continuation, "player_roster": attacking_roster if attacker.team == 0 else defending_roster, "enemy_roster": defending_roster if attacker.team == 0 else attacking_roster, "biome": regions[destination].biome, "fort": regions[destination].fort, "name": regions[destination].name, "seed": seed_value + battle_serial * 31 + destination, "entrenched": not defender.is_empty() and defender.stance == "entrench"}
	battle_serial += 1
	phase = "battle"
	_log("%s at %s. Command your sections in real time." % ["Attack" if attacker.team == 0 else "Enemy offensive", regions[destination].name.capitalize()])
	battle_requested.emit(pending.duplicate(true))

func resolve_battle(context_id: int, result_winner: int, player_survivors: Array, enemy_survivors: Array) -> bool:
	if phase != "battle" or pending.is_empty() or pending.id != context_id or context_id <= last_resolved or result_winner not in [0, 1]: return false
	if not _valid_roster(player_survivors, true) or not _valid_roster(enemy_survivors, true): return false
	var context = pending.duplicate(true)
	var attacker = army(context.attacker)
	var defender = army(context.defender)
	if attacker.is_empty(): return false
	var attacker_survivors = player_survivors if context.attack_team == 0 else enemy_survivors
	var defender_survivors = enemy_survivors if context.attack_team == 0 else player_survivors
	_assign_survivors(attacker, attacker_survivors)
	if not defender.is_empty(): _assign_survivors(defender, defender_survivors)
	var attacker_won = result_winner == context.attack_team
	var region: Dictionary = regions[context.region]
	region.battled = 3
	if attacker_won:
		_occupy(context.region, context.attack_team)
		if not attacker.roster.is_empty(): attacker.region = context.region
		if not defender.is_empty() and not defender.roster.is_empty(): _retreat_army(defender, context.region)
	else:
		var surviving_garrison = 0
		for unit in defender_survivors:
			if unit.uid <= -100: surviving_garrison += 1
		region.garrison = surviving_garrison
	for i in range(armies.size() - 1, -1, -1):
		if armies[i].roster.is_empty(): armies.remove_at(i)
	if result_winner == 0:
		victories += 1
		economy.credits += 160
		_log("Victory at %s. +160 salvage credits. Survivors retain experience." % region.name.capitalize())
	else: _log("Defeat at %s. Army losses persist. Rebuild and reinforce the line." % region.name.capitalize())
	last_resolved = context_id
	pending = {}
	phase = context.continuation
	selected_region = context.region
	if army(selected_army).is_empty(): selected_army = player_armies()[0].id if not player_armies().is_empty() else -1
	_reconnect()
	_check_campaign_end()
	changed.emit()
	return true

func _assign_survivors(entry: Dictionary, survivors: Array) -> void:
	var roster = []
	for unit in survivors:
		if unit.uid <= -100: continue
		var survivor: Dictionary = unit.duplicate(true)
		if survivor.uid < 0:
			survivor.uid = next_unit
			next_unit += 1
		roster.append(survivor)
	entry.roster = roster

func auto_resolve() -> bool:
	if phase != "battle" or pending.is_empty(): return false
	var context = pending.duplicate(true)
	var powers = [strength(context.player_roster), strength(context.enemy_roster)]
	var defender: int = 1 - int(context.attack_team)
	powers[defender] *= 1.0 + context.fort * 0.12 + (0.12 if context.entrenched else 0.0)
	if economy.cargo.ammo < 15: powers[0] *= 0.7
	var ratio = powers[0] / maxf(1, powers[1])
	var result = 0 if ratio > 1.7 else (1 if ratio < 0.59 else (0 if rng.randf() < powers[0] / maxf(1, powers[0] + powers[1]) else 1))
	var friendly = _auto_survivors(context.player_roster, result == 0, powers[1] / maxf(1, powers[0]))
	var enemy = _auto_survivors(context.enemy_roster, result == 1, powers[0] / maxf(1, powers[1]))
	economy.cargo.ammo = maxf(0, economy.cargo.ammo - context.player_roster.size() * 5)
	economy.cargo.supplies = maxf(0, economy.cargo.supplies - context.player_roster.size() * 2)
	return resolve_battle(context.id, result, friendly, enemy)

func _auto_survivors(roster: Array, won: bool, pressure: float) -> Array:
	var result = []
	for original in roster:
		if rng.randf() < clampf((0.10 if won else 0.48) * pressure, 0.04, 0.8): continue
		var unit: Dictionary = original.duplicate(true)
		unit.hp = maxf(1, unit.hp * clampf(rng.randf_range(0.5, 0.85) - pressure * (0.07 if won else 0.12), 0.2, 0.9))
		unit.veterancy += 55 if won else 20
		result.append(unit)
	if won and result.is_empty() and not roster.is_empty():
		var unit: Dictionary = roster[0].duplicate(true)
		unit.hp = maxf(1, unit.hp * 0.25)
		unit.veterancy += 55
		result.append(unit)
	return result

func _retreat_army(entry: Dictionary, from: int) -> void:
	for destination in neighbours(from):
		if regions[destination].owner == entry.team and army_at(destination, entry.team).is_empty():
			entry.region = destination
			entry.movement = 0
			return
	entry.roster.clear()

func _occupy(id: int, team: int) -> void:
	regions[id].owner = team
	regions[id].loyalty = 45.0
	regions[id].garrison = 1
	regions[id].job = {}

func _reconnect() -> void:
	for region in regions: region.connected = false
	for team in [0, 1]:
		if regions[CAPITALS[team]].owner != team: continue
		var queue = [CAPITALS[team]]
		regions[CAPITALS[team]].connected = true
		while not queue.is_empty():
			var here = queue.pop_front()
			for next in neighbours(here):
				if regions[next].owner == team and not regions[next].connected:
					regions[next].connected = true
					queue.append(next)

func _check_campaign_end() -> void:
	if regions[CAPITALS[0]].owner != 0:
		phase = "defeat"
		_log("Haven has fallen. The expedition must withdraw.")
	elif regions[CAPITALS[1]].owner == 0 and owned_count(0) >= 9:
		phase = "victory"
		_log("Iron Crown is secured and nine provinces are held. Meridian is liberated.")

func _reject(text: String) -> bool:
	notice.emit(text)
	return false

func _log(text: String) -> void:
	journal.push_front(text)
	if journal.size() > 24: journal.resize(24)
	notice.emit(text)

func snapshot() -> Dictionary:
	var market_data = []
	for market in markets: market_data.append(_economy_data(market))
	return {"schema": 2, "regions": regions.duplicate(true), "armies": armies.duplicate(true), "markets": market_data, "economy": _economy_data(economy), "turn": turn, "phase": phase, "difficulty": difficulty, "selected_army": selected_army, "selected_region": selected_region, "technology": technology.duplicate(), "research": research.duplicate(), "pending": pending.duplicate(true), "enemy_queue": enemy_queue.duplicate(), "journal": journal.duplicate(), "next_army": next_army, "next_unit": next_unit, "battle_serial": battle_serial, "last_resolved": last_resolved, "enemy_credits": enemy_credits, "seed": seed_value, "rng": str(rng.state), "victories": victories}

static func _economy_data(market: WarEconomy) -> Dictionary:
	return {"credits": market.credits, "cargo": market.cargo.duplicate(), "stock": market.stock.duplicate(), "demand": market.demand.duplicate(), "prices": market.prices.duplicate(), "history": market.history.duplicate(true), "turn": market.turn, "income": market.income, "headline": market.headline, "rng": str(market.rng.state)}

static func _restore_economy(market: WarEconomy, data: Dictionary) -> void:
	for key in ["credits", "cargo", "stock", "demand", "prices", "history", "turn", "income", "headline"]:
		market.set(key, data[key])
	market.rng.state = int(data.rng)

func restore(data: Dictionary) -> bool:
	if not _valid_save(data): return false
	setup(int(data.difficulty), int(data.seed))
	for i in range(15):
		for key in ["owner", "industry", "fort", "depot", "garrison", "loyalty", "job", "battled"]: regions[i][key] = data.regions[i][key]
	armies.assign(data.armies.duplicate(true))
	for i in range(15): _restore_economy(markets[i], data.markets[i])
	_restore_economy(economy, data.economy)
	turn = int(data.turn)
	phase = data.phase
	selected_army = int(data.selected_army)
	selected_region = int(data.selected_region)
	technology.assign(data.technology)
	research = data.research.duplicate()
	pending = data.pending.duplicate(true)
	enemy_queue.assign(data.enemy_queue.map(func(id): return int(id)))
	journal.assign(data.journal)
	for key in ["next_army", "next_unit", "battle_serial", "last_resolved", "enemy_credits", "victories"]: set(key, data[key])
	rng.state = int(data.rng)
	_reconnect()
	changed.emit()
	return true

func _valid_save(data: Dictionary) -> bool:
	if data.get("schema") != 2: return false
	for key in ["regions", "armies", "markets", "technology", "enemy_queue", "journal"]:
		if not data.get(key) is Array: return false
	for key in ["economy", "research", "pending"]:
		if not data.get(key) is Dictionary: return false
	if data.regions.size() != 15 or data.markets.size() != 15 or data.armies.size() > 12 or data.journal.size() > 24: return false
	for key in ["turn", "difficulty", "selected_army", "selected_region", "next_army", "next_unit", "battle_serial", "last_resolved", "enemy_credits", "seed", "victories"]:
		if not _number(data.get(key)): return false
	if data.turn < 1 or data.selected_region < 0 or data.selected_region >= 15 or data.get("phase") not in ["player", "enemy", "battle", "victory", "defeat"]: return false
	if not data.get("rng") is String or not _valid_economy(data.economy): return false
	for market in data.markets:
		if not market is Dictionary or not _valid_economy(market): return false
	for kind in data.technology:
		if kind not in TECHNOLOGIES: return false
	if not data.research.is_empty() and (not TECHNOLOGIES.has(data.research.get("kind")) or not _number(data.research.get("remaining"))): return false
	for region in data.regions:
		if not region is Dictionary: return false
		for key in ["owner", "industry", "fort", "depot", "garrison", "loyalty", "battled"]:
			if not _number(region.get(key)): return false
		if int(region.owner) not in [-1, 0, 1] or region.garrison < 0 or region.garrison > 8: return false
		if region.owner != int(region.owner) or region.industry < 0 or region.industry > 3 or region.fort < 0 or region.fort > 3 or region.depot < 0 or region.depot > 3 or region.loyalty < 0 or region.loyalty > 100: return false
		if not region.get("job") is Dictionary: return false
		if not region.job.is_empty() and (not BUILDINGS.has(region.job.get("kind")) or not _number(region.job.get("remaining"))): return false
	var ids = {}
	var locations = {}
	var unit_ids = {}
	for entry in data.armies:
		if not entry is Dictionary or not entry.get("name") is String or not entry.get("roster") is Array: return false
		for key in ["id", "region", "team", "movement", "supply"]:
			if not _number(entry.get(key)): return false
		if entry.id < 0 or not _integer(entry.id) or not _integer(entry.region) or not _integer(entry.team) or entry.movement < 0 or entry.movement > 3 or entry.supply < 0 or entry.supply > 100 or entry.region < 0 or entry.region >= 15 or int(entry.team) not in [0, 1] or ids.has(entry.id) or locations.has(entry.region): return false
		if entry.get("stance") not in ["march", "entrench", "replenish"] or not _valid_roster(entry.roster): return false
		for unit in entry.roster:
			if unit_ids.has(unit.uid): return false
			unit_ids[unit.uid] = true
		ids[entry.id] = true
		locations[entry.region] = true
	for id in data.enemy_queue:
		if not _integer(id): return false
	for text in data.journal:
		if not text is String: return false
	if data.phase == "battle":
		var p: Dictionary = data.pending
		for key in ["id", "region", "origin", "attacker", "defender", "attack_team", "fort", "seed"]:
			if not _number(p.get(key)): return false
		if not _integer(p.id) or not _integer(p.attacker) or not _integer(p.defender) or not _integer(p.region) or not _integer(p.origin) or p.origin < 0 or p.origin >= 15 or (p.defender >= 0 and not ids.has(p.defender)) or not ids.has(p.attacker) or p.region < 0 or p.region >= 15 or int(p.attack_team) not in [0, 1] or p.get("continuation") not in ["player", "enemy"]: return false
		if not p.get("name") is String or p.get("biome") not in ["forest", "farmland", "canal", "ridge", "city"] or not p.get("entrenched") is bool: return false
		if not p.get("player_roster") is Array or not p.get("enemy_roster") is Array: return false
		if not _valid_roster(p.player_roster, true) or not _valid_roster(p.enemy_roster, true): return false
	return true

static func _valid_roster(roster: Array, garrisons: bool = false) -> bool:
	if roster.size() > 8: return false
	var ids = {}
	for unit in roster:
		if not unit is Dictionary or not CombatSquad.TYPES.has(unit.get("kind")): return false
		for key in ["uid", "hp", "veterancy", "kills"]:
			if not _number(unit.get(key)): return false
		if not _integer(unit.uid) or not _integer(unit.kills) or unit.kills < 0 or unit.hp <= 0 or unit.hp > CombatSquad.TYPES[unit.kind].hp or unit.veterancy < 0: return false
		if not garrisons and unit.uid < 0: return false
		if unit.uid >= 0 and ids.has(unit.uid): return false
		ids[unit.uid] = true
	return true

static func _valid_economy(data: Dictionary) -> bool:
	for key in ["credits", "income", "turn"]:
		if not _number(data.get(key)): return false
	if data.credits < 0 or not data.get("headline") is String or not data.get("rng") is String: return false
	for key in ["cargo", "stock", "prices", "demand", "history"]:
		if not data.get(key) is Dictionary: return false
		for good in WarEconomy.GOODS:
			if key == "history":
				if not data[key].get(good) is Array or data[key][good].size() > 24: return false
				for value in data[key][good]:
					if not _number(value): return false
			elif not _number(data[key].get(good)) or data[key][good] < 0: return false
			elif key in ["prices", "demand"] and data[key][good] <= 0: return false
	return true

static func _number(value: Variant) -> bool:
	return (value is int or value is float) and is_finite(float(value))

static func _integer(value: Variant) -> bool:
	return _number(value) and float(value) == float(int(value))
