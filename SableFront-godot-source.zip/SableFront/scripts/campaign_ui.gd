class_name CampaignInterface
extends CommandInterface

signal new_campaign_requested(level: int)
signal continue_campaign_requested
signal skirmish_requested
signal continue_skirmish_requested
signal home_requested
signal command_battle_requested
signal auto_battle_requested
signal preference_changed
signal exit_requested

var campaign: TheaterCampaign
var preferences: FieldPreferences
var home_mode: bool = false
var atlas: RegionAtlas
var sidebar: VBoxContainer
var army_tabs: HBoxContainer
var treasury_labels: Dictionary = {}
var turn_label: Label
var _market_region: int = 10
var _toast: Label
var _toast_background: PanelContainer
var _toast_left: float = 0.0

func _ready() -> void:
	root = Control.new()
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(root)
	FieldPreferences.apply_safe_area(root)
	root.theme = _theme()
	root.theme.default_font_size = 18
	if home_mode: _build_home()
	else: _build_campaign()
	_build_toast()
	campaign.changed.connect(refresh)
	campaign.notice.connect(toast)
	refresh()

func button(text: String, callback: Callable, minimum: Vector2 = Vector2(0, 64), accent: bool = false) -> Button:
	var result = super.button(text, callback, Vector2(minimum.x, maxf(minimum.y, 56)), accent)
	result.pressed.connect(func():
		if preferences: preferences.tap())
	return result

func _build_home() -> void:
	atlas = RegionAtlas.new()
	atlas.campaign = campaign
	atlas.decorative = true
	atlas.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.add_child(atlas)
	var shade = ColorRect.new()
	shade.color = Color(0.015, 0.045, 0.035, 0.56)
	shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	shade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(shade)
	var center = CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.add_child(center)
	var card = PanelContainer.new()
	card.custom_minimum_size = Vector2(1100, 684)
	card.add_theme_stylebox_override("panel", box(Color(0.055, 0.1, 0.075, 0.97), Color("6d7452"), 10, 34))
	center.add_child(card)
	var row = HBoxContainer.new()
	row.add_theme_constant_override("separation", 46)
	card.add_child(row)
	var title_col = VBoxContainer.new()
	title_col.custom_minimum_size.x = 575
	title_col.add_theme_constant_override("separation", 18)
	row.add_child(title_col)
	var badge_row = HBoxContainer.new()
	title_col.add_child(badge_row)
	badge_row.add_child(icon("emblem", Vector2(72, 72)))
	var subtitle = label("MERIDIAN THEATER\nCAMPAIGN EDITION / 0.2", 15, GOLD, true)
	badge_row.add_child(subtitle)
	spacer(title_col, true)
	var title = label("SABLE\nFRONT", 76)
	title.add_theme_font_override("font", BOLD)
	title_col.add_child(title)
	title_col.add_child(label("WIN THE GROUND.\nSUSTAIN THE WAR.", 24, GOLD))
	title_col.add_child(label("Command armies across fifteen provinces.\nFight for the frontline, trade for your future,\nand bring your veterans home.", 19, MUTED))
	spacer(title_col, true)
	title_col.add_child(label("OFFLINE / TOUCH FIRST / STRATEGY + TACTICS", 12, MUTED, true))
	var actions = VBoxContainer.new()
	actions.custom_minimum_size.x = 400
	actions.add_theme_constant_override("separation", 14)
	row.add_child(actions)
	spacer(actions, true)
	actions.add_child(label("YOUR NEXT OFFENSIVE", 14, GOLD, true))
	if FileAccess.file_exists("user://campaign.json"):
		actions.add_child(button("CONTINUE CAMPAIGN", func(): continue_campaign_requested.emit(), Vector2(0, 78), true))
	actions.add_child(button("NEW CAMPAIGN", _new_campaign_sheet, Vector2(0, 78), not FileAccess.file_exists("user://campaign.json")))
	actions.add_child(button("QUICK SKIRMISH", func(): skirmish_requested.emit(), Vector2(0, 64)))
	if FileAccess.file_exists("user://operation.json"):
		actions.add_child(button("CONTINUE SKIRMISH", func(): continue_skirmish_requested.emit(), Vector2(0, 56)))
	line(actions)
	actions.add_child(button("COMMANDER'S MANUAL", show_guide, Vector2(0, 60)))
	actions.add_child(button("MOBILE & AUDIO SETTINGS", show_settings, Vector2(0, 60)))
	spacer(actions, true)

func _build_campaign() -> void:
	var top = panel(root, Rect2(14, 14, 1252, 78), Color("14251c"), 12)
	top.set_anchors_preset(Control.PRESET_TOP_WIDE)
	top.offset_right = -14
	var header = HBoxContainer.new()
	top.add_child(header)
	header.add_child(icon("emblem", Vector2(45, 45)))
	var brand = VBoxContainer.new()
	brand.custom_minimum_size.x = 153
	brand.add_theme_constant_override("separation", 0)
	header.add_child(brand)
	brand.add_child(label("SABLE FRONT", 20))
	brand.add_child(label("CAMPAIGN COMMAND", 10, GOLD, true))
	for good in ["credits", "supplies", "ammo", "fuel"]:
		var column = VBoxContainer.new()
		column.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		column.add_theme_constant_override("separation", 0)
		header.add_child(column)
		column.add_child(label("CREDITS" if good == "credits" else WarEconomy.NAMES[good].to_upper(), 11, MUTED, true))
		var amount = label("0", 25, CREAM, true)
		column.add_child(amount)
		treasury_labels[good] = amount
	turn_label = label("TURN 01", 17, GOLD, true)
	header.add_child(turn_label)
	header.add_child(button("MENU", _campaign_menu, Vector2(90, 56)))
	var body = HBoxContainer.new()
	body.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	body.offset_left = 14
	body.offset_right = -14
	body.offset_top = 104
	body.offset_bottom = -128
	body.add_theme_constant_override("separation", 12)
	root.add_child(body)
	var map_frame = PanelContainer.new()
	map_frame.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	map_frame.add_theme_stylebox_override("panel", box(Color("152b27"), EDGE, 8, 0))
	body.add_child(map_frame)
	atlas = RegionAtlas.new()
	atlas.campaign = campaign
	atlas.province_tapped.connect(_select_region)
	map_frame.add_child(atlas)
	var detail = PanelContainer.new()
	detail.custom_minimum_size.x = 324
	detail.add_theme_stylebox_override("panel", box(Color("172a20"), EDGE, 8, 14))
	body.add_child(detail)
	var scroll = ScrollContainer.new()
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	detail.add_child(scroll)
	sidebar = VBoxContainer.new()
	sidebar.custom_minimum_size.x = 280
	sidebar.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	sidebar.add_theme_constant_override("separation", 12)
	scroll.add_child(sidebar)
	var bottom = panel(root, Rect2(14, 0, 1252, 102), Color("14251c"), 12)
	bottom.set_anchors_preset(Control.PRESET_BOTTOM_WIDE)
	bottom.offset_left = 14
	bottom.offset_right = -14
	bottom.offset_top = -116
	bottom.offset_bottom = -14
	var footer = HBoxContainer.new()
	bottom.add_child(footer)
	var roster_scroll = ScrollContainer.new()
	roster_scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	roster_scroll.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	footer.add_child(roster_scroll)
	army_tabs = HBoxContainer.new()
	roster_scroll.add_child(army_tabs)
	footer.add_child(button("RESEARCH", show_research, Vector2(120, 72)))
	footer.add_child(button("MARKET", show_market, Vector2(110, 72)))
	footer.add_child(button("END TURN", _end_turn_sheet, Vector2(170, 76), true))

func _build_toast() -> void:
	_toast_background = panel(root, Rect2(0, 0, 720, 54), Color(0.06, 0.12, 0.09, 0.97), 12)
	_toast_background.set_anchors_preset(Control.PRESET_CENTER_TOP)
	_toast_background.offset_left = -360
	_toast_background.offset_right = 360
	_toast_background.offset_top = 108
	_toast_background.offset_bottom = 162
	_toast_background.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_toast = label("", 15, CREAM)
	_toast.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_toast.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_toast_background.add_child(_toast)
	_toast_background.visible = false

func _process(delta: float) -> void:
	if _toast_left > 0:
		_toast_left -= delta
		if _toast_left <= 0: _toast_background.visible = false

func toast(text: String) -> void:
	if not is_instance_valid(_toast): return
	_toast.text = text
	_toast_background.visible = true
	_toast_left = 5
	root.move_child(_toast_background, root.get_child_count() - 1)

func _clear(node: Node) -> void:
	for child in node.get_children():
		if child is Control: child.hide()
		child.queue_free()

func paragraph(text: String, size_value: int = 16, color: Color = MUTED) -> Label:
	var result = label(text, size_value, color)
	result.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	return result

func refresh() -> void:
	if home_mode or not is_instance_valid(sidebar): return
	treasury_labels.credits.text = str(int(campaign.economy.credits))
	for good in WarEconomy.GOODS: treasury_labels[good].text = str(int(campaign.economy.cargo[good]))
	turn_label.text = "TURN %02d" % campaign.turn
	atlas.selected_region = campaign.selected_region
	atlas.selected_army = campaign.selected_army
	atlas.queue_redraw()
	_clear(sidebar)
	var region = campaign.regions[campaign.selected_region]
	sidebar.add_child(label("PROVINCE %02d / %s" % [region.id + 1, region.biome.to_upper()], 12, GOLD, true))
	sidebar.add_child(label(region.name, 25))
	var owner_text = "ALLIED" if region.owner == 0 else ("OPPOSITION" if region.owner == 1 else "INDEPENDENT")
	sidebar.add_child(label(owner_text + (" / SUPPLIED" if region.connected else " / ISOLATED"), 12, TEAL if region.owner == 0 else RED, true))
	line(sidebar)
	sidebar.add_child(paragraph("%s producer\nIncome %d cr/turn  /  Loyalty %d%%\nGarrison %d  /  Fort level %d" % [WarEconomy.NAMES[region.good], int(campaign.region_income(region)), int(region.loyalty), region.garrison, region.fort], 15))
	var entry = campaign.army(campaign.selected_army)
	if not entry.is_empty():
		line(sidebar)
		sidebar.add_child(label("SELECTED ARMY", 11, GOLD, true))
		sidebar.add_child(paragraph(entry.name, 18, CREAM))
		sidebar.add_child(paragraph("%s\n%d sections  /  %d movement\nSupply %d%%  /  %s stance" % [campaign.regions[entry.region].name.capitalize(), entry.roster.size(), entry.movement, int(entry.supply), entry.stance], 15))
		if entry.region != region.id:
			var reason = campaign.can_march(entry.id, region.id)
			var path = campaign.route(entry.region, region.id)
			var cost = path.size() - 1 if not path.is_empty() else 0
			var caption = "ATTACK PROVINCE" if region.owner != 0 else "MARCH HERE"
			var move = button(caption, func(): campaign.march(entry.id, region.id), Vector2(0, 74), true)
			move.disabled = reason != ""
			sidebar.add_child(move)
			sidebar.add_child(paragraph(reason if reason != "" else "Costs %d movement and %d fuel. Battle losses carry into the campaign." % [cost, cost], 13))
		else: sidebar.add_child(button("MANAGE ARMY", show_recruit, Vector2(0, 70), true))
	if region.owner == 0:
		sidebar.add_child(button("DEVELOP PROVINCE", show_development, Vector2(0, 60)))
		if campaign.army_at(region.id, 0).is_empty(): sidebar.add_child(button("RAISE NEW ARMY", func(): campaign.raise_army(region.id), Vector2(0, 58)))
	if not region.job.is_empty(): sidebar.add_child(paragraph("BUILDING: %s / %d turns" % [TheaterCampaign.BUILDINGS[region.job.kind].name, region.job.remaining], 13, GOLD))
	spacer(sidebar, true)
	sidebar.add_child(paragraph("Capture Iron Crown and hold 9 provinces. Protect Haven to stay in the war.", 13, GOLD))
	_clear(army_tabs)
	for item in campaign.player_armies():
		var b = button("%s\n%s / %d MP" % [item.name, campaign.regions[item.region].name.capitalize(), item.movement], func():
			campaign.selected_army = item.id
			campaign.selected_region = item.region
			refresh(), Vector2(218, 74))
		b.add_theme_font_size_override("font_size", 13)
		if item.id == campaign.selected_army: b.add_theme_stylebox_override("normal", box(Color("344733"), GOLD, 5, 10))
		army_tabs.add_child(b)
	if campaign.phase in ["victory", "defeat"] and _screen != "campaign_end": show_campaign_end.call_deferred()

func _select_region(id: int) -> void:
	campaign.selected_region = id
	var entry = campaign.army_at(id, 0)
	if not entry.is_empty(): campaign.selected_army = entry.id
	if preferences: preferences.tap()
	refresh()

func modal(title: String, subtitle: String, dimensions: Vector2 = Vector2(1060, 700)) -> VBoxContainer:
	close_popup()
	overlay = Control.new()
	overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	overlay.mouse_filter = Control.MOUSE_FILTER_STOP
	root.add_child(overlay)
	var shade = ColorRect.new()
	shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	shade.color = Color(0.015, 0.045, 0.03, 0.82)
	overlay.add_child(shade)
	var center = CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	center.mouse_filter = Control.MOUSE_FILTER_IGNORE
	overlay.add_child(center)
	popup = PanelContainer.new()
	popup.custom_minimum_size = dimensions
	popup.add_theme_stylebox_override("panel", box(Color("17291f"), Color("647254"), 10, 22))
	center.add_child(popup)
	var outer = VBoxContainer.new()
	outer.add_theme_constant_override("separation", 12)
	popup.add_child(outer)
	var heading = HBoxContainer.new()
	outer.add_child(heading)
	var column = VBoxContainer.new()
	heading.add_child(column)
	column.add_child(label(title, 27))
	column.add_child(label(subtitle, 12, GOLD, true))
	spacer(heading)
	heading.add_child(button("X", close_popup, Vector2(58, 58)))
	line(outer)
	var scroll = ScrollContainer.new()
	scroll.custom_minimum_size = Vector2(dimensions.x - 50, dimensions.y - 155)
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	outer.add_child(scroll)
	var body = VBoxContainer.new()
	body.custom_minimum_size.x = dimensions.x - 72
	body.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	body.add_theme_constant_override("separation", 16)
	scroll.add_child(body)
	return body

func close_popup() -> void:
	if overlay:
		overlay.hide()
		overlay.queue_free()
		overlay = null
		popup = null
	_screen = ""
	modal_value_labels.clear()
	market_buttons.clear()

func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo and event.physical_keycode in [KEY_ESCAPE, KEY_SPACE]:
		back()
		get_viewport().set_input_as_handled()

func back() -> void:
	if _screen == "battle_preview" or _screen == "campaign_end": return
	if overlay: close_popup()
	elif not home_mode: _campaign_menu()
	else:
		var body = modal("LEAVE SABLE FRONT?", "YOUR SAVED OPERATIONS WILL BE HERE WHEN YOU RETURN", Vector2(800, 450))
		_screen = "exit"
		body.add_child(paragraph("Campaign and battle progress are stored on this device. You can continue from the main menu next time.", 21))
		body.add_child(button("KEEP PLAYING", close_popup, Vector2(0, 72), true))
		body.add_child(button("EXIT GAME", func(): exit_requested.emit(), Vector2(0, 64)))

func _new_campaign_sheet() -> void:
	var body = modal("A NEW CAMPAIGN", "MERIDIAN / FIFTEEN PROVINCES / TURN-BASED COMMAND", Vector2(900, 650))
	_screen = "new_campaign"
	body.add_child(paragraph("Lead two expeditionary armies from Haven. March between provinces, develop industry, research new formations, and command battles in real time. Capturing Iron Crown and nine provinces wins the campaign.", 21, CREAM))
	body.add_child(paragraph("Armies need fuel to move and supplies to recover. The opposition recruits and manoeuvres when you end your turn. Battle casualties and veteran experience persist.", 18))
	if FileAccess.file_exists("user://campaign.json"): body.add_child(paragraph("Starting a new campaign replaces the existing campaign save.", 17, RED))
	var mode = OptionButton.new()
	mode.custom_minimum_size.y = 66
	for text in ["RELAXED / MORE FORGIVING", "STANDARD / BALANCED FRONT", "VETERAN / AGGRESSIVE OPPOSITION"]: mode.add_item(text)
	mode.select(1)
	body.add_child(mode)
	body.add_child(button("BEGIN CAMPAIGN", func(): new_campaign_requested.emit(mode.selected), Vector2(0, 80), true))

func _campaign_menu() -> void:
	var body = modal("COMMAND PAUSE", "CAMPAIGN ACTIONS SAVE AUTOMATICALLY", Vector2(760, 630))
	_screen = "campaign_menu"
	body.add_child(button("RETURN TO THE MAP", close_popup, Vector2(0, 74), true))
	body.add_child(button("CAMPAIGN JOURNAL", show_journal))
	body.add_child(button("COMMANDER'S MANUAL", show_guide))
	body.add_child(button("MOBILE & AUDIO SETTINGS", show_settings))
	body.add_child(button("SAVE & MAIN MENU", func(): home_requested.emit()))

func show_recruit() -> void:
	var entry = campaign.army(campaign.selected_army)
	if entry.is_empty():
		toast("Select an allied army first.")
		return
	var body = modal("ARMY COMMAND", "%s / %d OF 8 SECTIONS" % [entry.name, entry.roster.size()])
	_screen = "army"
	body.add_child(label("SUPPLY %d%% / %s" % [int(entry.supply), "CONNECTED TO HAVEN" if campaign.regions[entry.region].connected else "ISOLATED / RECONNECT TO RECRUIT"], 15, TEAL if campaign.regions[entry.region].connected else RED, true))
	var health_row = HBoxContainer.new()
	body.add_child(health_row)
	for unit in entry.roster:
		var unit_col = VBoxContainer.new()
		health_row.add_child(unit_col)
		unit_col.add_child(icon(unit.kind, Vector2(70, 60), TEAL))
		unit_col.add_child(label("%d%%" % int(unit.hp / CombatSquad.TYPES[unit.kind].hp * 100), 13, MUTED, true))
	body.add_child(button("REINFORCE ARMY / KEEP VETERANS", func():
		campaign.reinforce(entry.id)
		show_recruit(), Vector2(0, 62)))
	var stance_row = HBoxContainer.new()
	body.add_child(stance_row)
	for stance in ["march", "entrench", "replenish"]:
		var b = button(stance.to_upper(), func():
			campaign.set_stance(entry.id, stance)
			show_recruit(), Vector2(310, 58), entry.stance == stance)
		stance_row.add_child(b)
	body.add_child(paragraph("March: full movement. Entrench: one movement and +50 strength when defending. Replenish: no movement; recover health at turn end if supplied. Stance changes never refund movement.", 14))
	line(body)
	var grid = GridContainer.new()
	grid.columns = 3
	grid.add_theme_constant_override("h_separation", 12)
	grid.add_theme_constant_override("v_separation", 12)
	body.add_child(grid)
	for kind in CombatSquad.TYPES:
		var data = CombatSquad.TYPES[kind]
		var cell = PanelContainer.new()
		cell.custom_minimum_size = Vector2(316, 230)
		cell.add_theme_stylebox_override("panel", box(Color("22392a"), EDGE, 6, 14))
		grid.add_child(cell)
		var v = VBoxContainer.new()
		cell.add_child(v)
		var title = HBoxContainer.new()
		v.add_child(title)
		title.add_child(icon(kind, Vector2(45, 45), TEAL))
		title.add_child(label(data.short, 15, CREAM, true))
		v.add_child(paragraph(data.description, 14))
		spacer(v, true)
		var unlocked = kind in campaign.allowed_kinds()
		var b = button(cost_string(data.cost) if unlocked else "RESEARCH " + str(data.get("tech", "")).to_upper(), func():
			campaign.recruit(entry.id, kind)
			show_recruit(), Vector2(0, 62), unlocked)
		b.add_theme_font_size_override("font_size", 13)
		b.disabled = not unlocked or entry.roster.size() >= 8 or not campaign.economy.can_pay(data.cost) or campaign.phase != "player" or not campaign.regions[entry.region].connected
		v.add_child(b)

func show_development() -> void:
	var id = campaign.selected_region
	var region = campaign.regions[id]
	var body = modal("PROVINCE DEVELOPMENT", "%s / PROTECT YOUR SUPPLY NETWORK" % region.name)
	_screen = "development"
	body.add_child(paragraph("Provinces produce income and commodities only while connected to Haven through allied territory. Occupied provinces recover loyalty over time, improving their tax income.", 19))
	for kind in TheaterCampaign.BUILDINGS:
		var data = TheaterCampaign.BUILDINGS[kind]
		var cell = PanelContainer.new()
		cell.add_theme_stylebox_override("panel", box(Color("23392a"), EDGE, 6, 16))
		body.add_child(cell)
		var row = HBoxContainer.new()
		cell.add_child(row)
		var col = VBoxContainer.new()
		col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		row.add_child(col)
		col.add_child(label("%s / LEVEL %d" % [data.name.to_upper(), region[kind]], 19, GOLD))
		col.add_child(label(data.description, 15, MUTED))
		var b = button(cost_string(data.cost) + "\n%d TURN%s" % [data.turns, "S" if data.turns > 1 else ""], func():
			campaign.construct(id, kind)
			show_development(), Vector2(265, 76), true)
		b.add_theme_font_size_override("font_size", 14)
		b.disabled = not region.job.is_empty() or region[kind] >= 3 or not campaign.economy.can_pay(data.cost) or campaign.phase != "player"
		row.add_child(b)
	if not region.job.is_empty(): body.add_child(paragraph("In progress: %s, %d turns remaining." % [TheaterCampaign.BUILDINGS[region.job.kind].name, region.job.remaining], 18, TEAL))

func show_research() -> void:
	var body = modal("RESEARCH BUREAU", "TECHNOLOGY CHANGES WHAT YOU CAN FIELD")
	_screen = "research"
	if not campaign.research.is_empty(): body.add_child(label("IN PROGRESS / %s / %d TURNS" % [TheaterCampaign.TECHNOLOGIES[campaign.research.kind].name.to_upper(), campaign.research.remaining], 17, TEAL))
	for kind in TheaterCampaign.TECHNOLOGIES:
		var data = TheaterCampaign.TECHNOLOGIES[kind]
		var cell = PanelContainer.new()
		cell.add_theme_stylebox_override("panel", box(Color("23392a"), EDGE, 6, 16))
		body.add_child(cell)
		var row = HBoxContainer.new()
		cell.add_child(row)
		var v = VBoxContainer.new()
		v.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		row.add_child(v)
		v.add_child(label(data.name.to_upper(), 20, GOLD))
		v.add_child(label(data.description, 15, MUTED))
		var done = kind in campaign.technology
		var b = button("COMPLETE" if done else cost_string(data.cost) + "\n%d TURNS" % data.turns, func():
			campaign.start_research(kind)
			show_research(), Vector2(290, 76), not done)
		b.add_theme_font_size_override("font_size", 14)
		b.disabled = done or not campaign.research.is_empty() or not campaign.economy.can_pay(data.cost) or campaign.phase != "player"
		row.add_child(b)

func show_market() -> void:
	_market_region = campaign.selected_region
	var region = campaign.regions[_market_region]
	var body = modal("REGIONAL EXCHANGE", "%s / SUPPLY, DEMAND AND THE FRONTLINE" % region.name)
	_screen = "regional_market"
	var market = campaign.markets[_market_region]
	body.add_child(paragraph(market.headline, 18, GOLD))
	var access = campaign.trade_access(_market_region)
	if not access: body.add_child(paragraph("Trade requires an allied army here, a friendly supply connection, or access to Haven. March your army to reach a different market.", 17, RED))
	for good in WarEconomy.GOODS:
		var cell = PanelContainer.new()
		cell.add_theme_stylebox_override("panel", box(Color("23392a"), EDGE, 6, 14))
		body.add_child(cell)
		var row = HBoxContainer.new()
		cell.add_child(row)
		row.add_child(icon(good, Vector2(50, 62), TEAL))
		var info = VBoxContainer.new()
		info.custom_minimum_size.x = 240
		row.add_child(info)
		info.add_child(label(WarEconomy.NAMES[good].to_upper(), 18))
		info.add_child(label("%.1f cr / %d in stock\nYour cargo: %d" % [market.prices[good], market.stock[good], campaign.economy.cargo[good]], 15, MUTED))
		var chart = MarketSparkline.new()
		chart.values = market.history[good]
		chart.custom_minimum_size = Vector2(160, 72)
		row.add_child(chart)
		spacer(row)
		var sell = button("SELL 10\n%d cr" % market.quote(good, false), func():
			campaign.trade(_market_region, good, false)
			show_market(), Vector2(145, 76))
		sell.disabled = not access or campaign.economy.cargo[good] < 10
		row.add_child(sell)
		var buy = button("BUY 10\n%d cr" % market.quote(good, true), func():
			campaign.trade(_market_region, good, true)
			show_market(), Vector2(145, 76), true)
		buy.disabled = not access or market.stock[good] < 10 or campaign.economy.credits < market.quote(good, true) or campaign.economy.cargo[good] + 10 > 999
		row.add_child(buy)
	body.add_child(paragraph("Production, isolated supply lines, battles, deliveries and your trades change each province's stock and prices. Shipments and prices update at turn end. Prices differ between provinces.", 16))

func _end_turn_sheet() -> void:
	if campaign.phase != "player": return
	var body = modal("END YOUR TURN?", "THE OPPOSITION WILL MOVE AND RECRUIT", Vector2(820, 570))
	_screen = "end_turn"
	body.add_child(label("PROJECTED NET INCOME / %+d cr" % int(campaign.projected_income()), 23, GOLD))
	body.add_child(paragraph("Connected provinces produce cargo. Buildings and research advance. Armies consume upkeep and resupply. Enemy armies may invade and force a defensive battle.", 21))
	var remaining = 0
	for entry in campaign.player_armies(): remaining += entry.movement
	body.add_child(paragraph("Your armies still have %d movement points in total." % remaining, 18, MUTED))
	body.add_child(button("COMMIT TURN", func():
		close_popup()
		campaign.end_turn(), Vector2(0, 80), true))

func show_battle_preview() -> void:
	if campaign.pending.is_empty(): return
	var context = campaign.pending
	var body = modal("BATTLE FOR " + context.name, "ATTACK" if context.attack_team == 0 else "DEFEND THE PROVINCE", Vector2(1000, 690))
	_screen = "battle_preview"
	var close: Button = popup.get_child(0).get_child(0).get_child(popup.get_child(0).get_child(0).get_child_count() - 1)
	close.visible = false
	var row = HBoxContainer.new()
	body.add_child(row)
	for team in [0, 1]:
		var roster: Array = context.player_roster if team == 0 else context.enemy_roster
		var col = VBoxContainer.new()
		col.custom_minimum_size.x = 445
		row.add_child(col)
		col.add_child(label("EXPEDITION" if team == 0 else "OPPOSITION", 21, TEAL if team == 0 else RED))
		col.add_child(label("%d sections / %d strength" % [roster.size(), int(campaign.strength(roster))], 17))
		var icons = HBoxContainer.new()
		icons.add_theme_constant_override("separation", 4)
		col.add_child(icons)
		for unit in roster: icons.add_child(icon(unit.kind, Vector2(42, 54), TEAL if team == 0 else RED))
	body.add_child(paragraph("Terrain: %s. Defensive fort level: %d. Your casualties, recruited sections and veteran experience return to the campaign. Captured sectors generate supplies while fighting." % [context.biome.capitalize(), context.fort], 20))
	body.add_child(paragraph("Hold three sectors to wear down the opposing force. Use infantry to capture, support weapons to pin, and assault troops or armor to flank. Medics and engineers sustain the army.", 18))
	body.add_child(button("COMMAND BATTLE", func(): command_battle_requested.emit(), Vector2(0, 84), true))
	body.add_child(button("AUTO RESOLVE / CASUALTIES PERSIST", func(): auto_battle_requested.emit(), Vector2(0, 64)))

func show_campaign_end() -> void:
	var won = campaign.phase == "victory"
	var body = modal("MERIDIAN LIBERATED" if won else "HAVEN HAS FALLEN", "CAMPAIGN AFTER-ACTION REPORT", Vector2(900, 620))
	_screen = "campaign_end"
	popup.get_child(0).get_child(0).get_child(popup.get_child(0).get_child(0).get_child_count() - 1).visible = false
	body.add_child(label("The expedition has secured the theater." if won else "Regroup. A new campaign awaits.", 24, TEAL if won else RED))
	body.add_child(label("TURNS / %d\nPROVINCES HELD / %d\nBATTLES WON / %d\nSURVIVING ARMIES / %d" % [campaign.turn, campaign.owned_count(0), campaign.victories, campaign.player_armies().size()], 21, MUTED, true))
	body.add_child(button("RETURN TO MAIN MENU", func(): home_requested.emit(), Vector2(0, 80), true))

func show_journal() -> void:
	var body = modal("CAMPAIGN JOURNAL", "DISPATCHES FROM THE MERIDIAN FRONT")
	_screen = "journal"
	for i in range(campaign.journal.size()): body.add_child(paragraph("%02d / %s" % [i + 1, campaign.journal[i]], 19, CREAM if i == 0 else MUTED))

func show_guide() -> void:
	var body = modal("COMMANDER'S MANUAL", "STRATEGIC CAMPAIGN + REAL-TIME SQUAD TACTICS")
	_screen = "guide"
	for entry in [
		["1 / COMMAND THE REGION", "Tap an army card, then tap a destination province. Confirm MARCH or ATTACK in the right panel. Armies spend movement and fuel. Paths can cross friendly territory, but an enemy province must be the final destination. Drag and pinch the atlas to inspect the front."],
		["2 / BUILD A CAMPAIGN", "End Turn generates income and commodities from provinces connected to Haven. Army upkeep reduces profit. Isolated armies lose supply and eventually health. Develop industry, forts and depots. Research unlocks seven specialist units. Replenish stance restores wounded veterans; Entrench improves defensive strength."],
		["3 / FIGHT ON YOUR PHONE", "Tap a squad card, then tap the battlefield to move and engage. Drag empty ground to pan; pinch to zoom. MULTI toggles group selection. The minimap and sector letters focus the camera. ABILITY, then a target, uses the selected section's ability. RETREAT saves veterans; REINFORCE at HQ restores losses."],
		["4 / USE COMBINED ARMS", "Rifles capture. Assault and flame troops flank. MGs suppress. Mortars need time to deploy and cannot shoot at close range. Anti-tank guns counter vehicles. Scouts reveal terrain; marksmen hunt infantry. Medics heal infantry out of combat, and engineers repair nearby vehicles while consuming supplies."],
		["5 / WIN THE THEATER", "Battle losses and experience persist. Auto Resolve can save time but still causes casualties. Capture Iron Crown and hold nine provinces while protecting Haven. Your campaign and any ongoing tactical battle save automatically, including completed battle results."],
		["MOBILE NOTES", "Landscape is required. Larger controls are enabled by default. Settings offer 30/60 FPS, reduced effects, sound and haptics. Android Back pauses battles or closes menus. You can resume campaign battles after closing the app. The game works offline."]
	]:
		body.add_child(label(entry[0], 20, GOLD))
		body.add_child(paragraph(entry[1], 18))
		line(body)

func show_settings() -> void:
	var body = modal("MOBILE & AUDIO", "PREFERENCES SAVE ON THIS DEVICE", Vector2(880, 680))
	_screen = "settings"
	for field in ["sound", "haptics", "large_controls"]:
		var title = {"sound": "SOUND EFFECTS", "haptics": "TOUCH HAPTICS", "large_controls": "LARGE CONTROLS"}[field]
		body.add_child(button(title + " / " + ("ON" if preferences.get(field) else "OFF"), func():
			preferences.set(field, not preferences.get(field))
			preferences.save()
			preference_changed.emit()
			show_settings(), Vector2(0, 64)))
	body.add_child(button("FRAME RATE / %d FPS" % preferences.fps, func():
		preferences.fps = 60 if preferences.fps == 30 else 30
		preferences.save()
		preference_changed.emit()
		show_settings(), Vector2(0, 64)))
	body.add_child(button("EFFECTS / " + ("FULL" if preferences.quality == 1 else "REDUCED"), func():
		preferences.quality = 1 - preferences.quality
		preferences.save()
		preference_changed.emit()
		show_settings(), Vector2(0, 64)))
	body.add_child(paragraph("30 FPS and reduced effects favour battery life. Haptics depend on device support. Progress autosaves after campaign actions, every 20 seconds in battle, and when the app enters the background.", 17))
