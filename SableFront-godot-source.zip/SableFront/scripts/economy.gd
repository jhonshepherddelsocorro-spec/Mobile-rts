class_name WarEconomy
extends RefCounted

const GOODS = ["supplies", "ammo", "fuel"]
const BASE = {"supplies": 5.0, "ammo": 7.0, "fuel": 11.0}
const NAMES = {"supplies": "Supplies", "ammo": "Munitions", "fuel": "Fuel"}
var credits: float = 640.0
var cargo = {"supplies": 95.0, "ammo": 90.0, "fuel": 45.0}
var stock = {"supplies": 180.0, "ammo": 160.0, "fuel": 120.0}
var demand = {"supplies": 1.0, "ammo": 1.0, "fuel": 1.0}
var prices = {"supplies": 5.0, "ammo": 7.0, "fuel": 11.0}
var history = {"supplies": [], "ammo": [], "fuel": []}
var headline = "Trade lanes open. Regional prices are stable."
var event_time: float = 0.0
var turn: int = 0
var income: float = 0.0
var rng = RandomNumberGenerator.new()

func _init(seed_value: int = 17) -> void:
	rng.seed = seed_value
	for good in GOODS:
		for i in range(24):
			history[good].append(BASE[good])

func can_pay(cost: Dictionary) -> bool:
	for key in cost:
		if key == "credits":
			if credits + 0.0001 < cost[key]:
				return false
		elif cargo.get(key, 0.0) + 0.0001 < cost[key]:
			return false
	return true

func pay(cost: Dictionary) -> bool:
	if not can_pay(cost):
		return false
	for key in cost:
		if key == "credits":
			credits -= cost[key]
		else:
			cargo[key] -= cost[key]
	return true

func quote(good: String, buying: bool, quantity: int = 10) -> int:
	if not good in GOODS or quantity <= 0:
		return 0
	return int(ceil(prices[good] * quantity * (1.12 if buying else 0.84) - 0.00001))

func trade(good: String, buying: bool, quantity: int = 10) -> String:
	if not good in GOODS or quantity <= 0:
		return "Invalid trade."
	var cost = quote(good, buying, quantity)
	if buying:
		if cargo[good] + quantity > 999.0:
			return "Warehouse capacity reached (999 units)."
		if stock[good] < quantity:
			return "The regional market has insufficient stock."
		if credits < cost:
			return "Insufficient credits. Capture sectors or sell surplus cargo."
		credits -= cost
		cargo[good] += quantity
		stock[good] -= quantity
	else:
		if cargo[good] < quantity:
			return "Insufficient cargo to sell."
		credits += cost
		cargo[good] -= quantity
		stock[good] += quantity
	_reprice(false)
	return "Bought %d %s for %d cr." % [quantity, NAMES[good].to_lower(), cost] if buying else "Sold %d %s for %d cr." % [quantity, NAMES[good].to_lower(), cost]

func tick(production: Dictionary, squad_count: int, battle_heat: float, connected_count: int) -> void:
	turn += 1
	# A six-second market step: industry produces, regional armies consume.
	for good in GOODS:
		cargo[good] = minf(999.0, cargo[good] + production.get(good, 0.0))
		var burn = {"supplies": 4.5, "ammo": 3.0 + battle_heat * 1.5, "fuel": 2.8}[good]
		stock[good] = clampf(stock[good] + rng.randf_range(1.5, 6.0) - burn, 6.0, 420.0)
		demand[good] = lerpf(demand[good], 1.0 + battle_heat * (0.07 if good == "ammo" else 0.02), 0.18)
	income = 20.0 + connected_count * 12.0 - squad_count * 2.5
	credits = maxf(0.0, credits + income)
	if turn % 7 == 0:
		var good = GOODS[rng.randi_range(0, 2)]
		if rng.randf() < 0.55:
			stock[good] = maxf(6.0, stock[good] - rng.randf_range(25.0, 45.0))
			demand[good] = minf(2.0, demand[good] + 0.22)
			headline = "Supply disruption: %s shipments delayed. Prices rising." % NAMES[good].to_lower()
		else:
			stock[good] += 45.0
			demand[good] = maxf(0.75, demand[good] - 0.12)
			headline = "Merchant fleet arrives: fresh %s on the regional market." % NAMES[good].to_lower()
	_reprice(true)

func _reprice(record: bool) -> void:
	for good in GOODS:
		var baseline = {"supplies": 180.0, "ammo": 160.0, "fuel": 120.0}[good]
		var scarcity = clampf(pow(baseline / maxf(stock[good], 6.0), 0.42), 0.65, 2.5)
		prices[good] = clampf(BASE[good] * scarcity * demand[good], BASE[good] * 0.55, BASE[good] * 3.2)
		if record:
			history[good].append(prices[good])
			if history[good].size() > 24:
				history[good].pop_front()
