class_name BattlefieldFog
extends ColorRect

var battle: BattleSimulation
var _clock: float = 0
var explored_image = Image.create(16, 12, false, Image.FORMAT_RGBA8)
var explored_texture: ImageTexture

func _ready() -> void:
	size = BattleSimulation.WORLD
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	z_index = 5
	var fog_material = ShaderMaterial.new()
	fog_material.shader = preload("res://assets/fog.gdshader")
	material = fog_material
	explored_image.fill(Color.BLACK)
	explored_texture = ImageTexture.create_from_image(explored_image)
	material.set_shader_parameter("explored_map", explored_texture)
	_update_fog()

func _process(delta: float) -> void:
	_clock += delta
	visible = battle.fog
	if _clock >= 0.15:
		_clock = 0
		_update_fog()

func _update_fog() -> void:
	var positions = PackedVector2Array()
	var radii = PackedFloat32Array()
	positions.append(BattleSimulation.BASES[0])
	radii.append(330.0)
	for squad in battle.living(0):
		positions.append(squad.pos)
		radii.append(battle.sight_range(squad))
	for point in battle.points:
		if point.owner == 0:
			positions.append(point.pos)
			radii.append(210.0)
	for zone in battle.reveal_zones:
		positions.append(zone.pos)
		radii.append(zone.radius)
	var count = mini(32, positions.size())
	positions.resize(32)
	radii.resize(32)
	material.set_shader_parameter("sources", positions)
	material.set_shader_parameter("radii", radii)
	material.set_shader_parameter("source_count", count)
	for y in range(12):
		for x in range(16):
			explored_image.set_pixel(x, y, Color.WHITE if battle.explored.has(Vector2i(x, y)) else Color.BLACK)
	explored_texture.update(explored_image)
