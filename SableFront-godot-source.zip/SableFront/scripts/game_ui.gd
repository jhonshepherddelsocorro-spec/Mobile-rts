class_name CommandInterface
extends CanvasLayer

signal restart_requested
signal menu_requested
signal audio_changed(enabled: bool)
var battle: BattleSimulation
var field: BattlefieldView
var root: Control
var overlay: Control
var popup: PanelContainer
var _previous_pause: bool = false
var _screen: String = ""
var resource_labels = {}
var ticket_labels: Array[Label] = []
var point_buttons: Array[Button] = []
var roster: HBoxContainer
var status_label: Label
var selection_label: Label
var clock_label: Label
var objective_label: Label
var toast_label: Label
var toast_panel: PanelContainer
var toast_time: float = 0
var hint_label: Label
var hint_panel: PanelContainer
var pause_button: Button
var ability_button: Button
var _refresh_clock: float = 0
var _roster_signature: String = ""
var cards = {}
var sound_enabled: bool = true
var modal_value_labels = {}
var market_buttons = {}
var convoy_label: Label
var market_headline: Label
var resume_callback_saved: Callable
const BG = Color("121f1a")
const PANEL = Color("1b2b23")
const EDGE = Color("3e5140")
const CREAM = Color("ece6cd")
const MUTED = Color("96a58d")
const GOLD = Color("ddbd80")
const TEAL = Color("8ed1c1")
const RED = Color("e49678")
const FONT = preload("res://assets/fonts/FieldSans.ttf")
const BOLD = preload("res://assets/fonts/FieldSans-Semibold.ttf")
const MONO = preload("res://assets/fonts/FieldMono.ttf")

func _ready() -> void:
	root = Control.new()
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(root)
	FieldPreferences.apply_safe_area(root)
	root.theme = _theme()
	_build_hud()
	battle.changed.connect(refresh)
	battle.notice.connect(toast)
	battle.match_ended.connect(show_results)
	field.ability_consumed.connect(func(): refresh())
	refresh()

func _theme() -> Theme:
	var theme = Theme.new()
	theme.default_font = FONT
	theme.default_font_size = 16
	theme.set_color("font_color", "Label", CREAM)
	theme.set_color("font_color", "Button", CREAM)
	theme.set_color("font_hover_color", "Button", Color("fff2cd"))
	theme.set_color("font_disabled_color", "Button", Color("5f705e"))
	theme.set_stylebox("normal", "Button", box(Color("24382c"), EDGE, 5, 12))
	theme.set_stylebox("hover", "Button", box(Color("354c38"), GOLD, 5, 12))
	theme.set_stylebox("pressed", "Button", box(Color("4a573b"), GOLD, 5, 12))
	theme.set_stylebox("disabled", "Button", box(Color("1b2b22"), Color("2a3a2d"), 5, 12))
	theme.set_stylebox("focus", "Button", box(Color(0, 0, 0, 0), GOLD, 5, 0))
	theme.set_constant("separation", "HBoxContainer", 12)
	theme.set_constant("separation", "VBoxContainer", 8)
	return theme

func box(color: Color = PANEL, border: Color = EDGE, radius: int = 6, padding: int = 16) -> StyleBoxFlat:
	var style = StyleBoxFlat.new()
	style.bg_color = color
	style.border_color = border
	style.set_border_width_all(1)
	style.set_corner_radius_all(radius)
	style.content_margin_left = padding
	style.content_margin_right = padding
	style.content_margin_top = padding
	style.content_margin_bottom = padding
	return style

func label(text: String, size_value: int = 16, color: Color = CREAM, mono: bool = false) -> Label:
	var item = Label.new()
	item.text = text
	item.add_theme_font_size_override("font_size", size_value)
	item.add_theme_color_override("font_color", color)
	if mono: item.add_theme_font_override("font", MONO)
	item.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return item

func button(text: String, callback: Callable, minimum: Vector2 = Vector2(0, 48), accent: bool = false) -> Button:
	var item = Button.new()
	item.text = text
	item.custom_minimum_size = minimum
	item.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
	item.focus_mode = Control.FOCUS_ALL
	item.pressed.connect(callback)
	if accent:
		item.add_theme_stylebox_override("normal", box(GOLD, GOLD, 5, 12))
		item.add_theme_stylebox_override("hover", box(Color("efd39a"), CREAM, 5, 12))
		item.add_theme_stylebox_override("pressed", box(Color("b79b65"), GOLD, 5, 12))
		item.add_theme_color_override("font_color", BG)
		item.add_theme_color_override("font_hover_color", BG)
		item.add_theme_color_override("font_pressed_color", BG)
		item.add_theme_font_override("font", BOLD)
	return item

func panel(parent: Node, rect: Rect2, color: Color = PANEL, padding: int = 16) -> PanelContainer:
	var p = PanelContainer.new()
	p.position = rect.position
	p.custom_minimum_size = rect.size
	p.size = rect.size
	p.add_theme_stylebox_override("panel", box(color, EDGE, 6, padding))
	parent.add_child(p)
	return p

func spacer(parent: Node, vertical: bool = false) -> Control:
	var space = Control.new()
	if vertical: space.size_flags_vertical = Control.SIZE_EXPAND_FILL
	else: space.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	space.mouse_filter = Control.MOUSE_FILTER_IGNORE
	parent.add_child(space)
	return space

func icon(kind: String, minimum: Vector2 = Vector2(42, 42), color: Color = GOLD) -> TacticalIcon:
	var item = TacticalIcon.new()
	item.kind = kind
	item.color = color
	item.custom_minimum_size = minimum
	return item

func line(parent: Node) -> void:
	var separator = HSeparator.new()
	separator.add_theme_stylebox_override("separator", box(EDGE, EDGE, 0, 0))
	separator.custom_minimum_size.y = 1
	parent.add_child(separator)

func _build_hud() -> void:
	var top = panel(root, Rect2(20, 16, 1400, 82), Color("14241c"), 14)
	top.set_anchors_preset(Control.PRESET_TOP_WIDE)
	top.offset_right = -20
	var row = HBoxContainer.new()
	top.add_child(row)
	row.add_child(icon("emblem", Vector2(48, 48)))
	var brand = VBoxContainer.new()
	brand.custom_minimum_size.x = 208
	row.add_child(brand)
	var title = label("SABLE FRONT", 24)
	title.add_theme_font_override("font", BOLD)
	brand.add_child(title)
	brand.add_child(label("01 / OPERATION LOW TIDE", 10, MUTED, true))
	for good in ["credits", "supplies", "ammo", "fuel"]:
		var cell = HBoxContainer.new()
		cell.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		row.add_child(cell)
		if good == "credits": cell.add_child(label("¤", 32, GOLD))
		else: cell.add_child(icon(good, Vector2(30, 36), MUTED))
		var stack = VBoxContainer.new()
		stack.add_theme_constant_override("separation", 0)
		cell.add_child(stack)
		stack.add_child(label("CREDITS" if good == "credits" else WarEconomy.NAMES[good].to_upper(), 10, MUTED, true))
		var value = label("0", 23, CREAM, true)
		stack.add_child(value)
		resource_labels[good] = value
	var market = button("FIELD MARKET", show_market, Vector2(178, 48))
	market.tooltip_text = "Buy and sell resources at dynamic prices. [M]"
	row.add_child(market)
	pause_button = button("II", show_pause, Vector2(50, 48))
	pause_button.tooltip_text = "Tactical pause [Space / Esc]"
	row.add_child(pause_button)
	# Mission state, local to the upper-left corner.
	var mission = panel(root, Rect2(20, 114, 253, 217), Color(0.075, 0.13, 0.1, 0.94), 14)
	var v = VBoxContainer.new()
	mission.add_child(v)
	var heading = HBoxContainer.new()
	v.add_child(heading)
	heading.add_child(label("SECTOR CONTROL", 12, GOLD, true))
	spacer(heading)
	clock_label = label("00:00", 12, MUTED, true)
	heading.add_child(clock_label)
	var score = HBoxContainer.new()
	v.add_child(score)
	for team in [0, 1]:
		var column = VBoxContainer.new()
		column.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		score.add_child(column)
		column.add_child(label("ALLIED" if team == 0 else "OPPOSITION", 10, TEAL if team == 0 else RED, true))
		var value = label("300", 32, TEAL if team == 0 else RED, true)
		column.add_child(value)
		ticket_labels.append(value)
	var sectors = HBoxContainer.new()
	sectors.add_theme_constant_override("separation", 5)
	v.add_child(sectors)
	for index in range(5):
		var b = button(battle.points[index].code, func(): field.focus(battle.points[index].pos), Vector2(40, 40))
		b.tooltip_text = battle.points[index].name.capitalize() + " — tap to focus"
		sectors.add_child(b)
		point_buttons.append(b)
	objective_label = label("Hold 3 of 5 sectors to drain\nenemy command strength.", 12, MUTED)
	v.add_child(objective_label)
	# Right-edge command rail.
	var rail = VBoxContainer.new()
	rail.set_anchors_preset(Control.PRESET_TOP_RIGHT)
	rail.position = Vector2(-76, 118)
	rail.add_theme_constant_override("separation", 8)
	root.add_child(rail)
	rail.add_child(button("+", func(): field.zoom_by(1.2), Vector2(56, 52)))
	rail.add_child(button("-", func(): field.zoom_by(1.0 / 1.2), Vector2(56, 52)))
	rail.add_child(button("HQ", func(): field.focus(BattleSimulation.BASES[0]), Vector2(56, 52)))
	var recruit_button = button("+ RECRUIT", show_recruit, Vector2(154, 50), true)
	root.add_child(recruit_button)
	recruit_button.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
	recruit_button.offset_left = -174
	recruit_button.offset_right = -20
	recruit_button.offset_top = -258
	recruit_button.offset_bottom = -208
	recruit_button.tooltip_text = "Recruit infantry and a scout carrier at HQ. [B]"
	# Bottom command deck.
	var deck = panel(root, Rect2(20, -180, 1400, 160), Color("14241c"), 12)
	deck.set_anchors_preset(Control.PRESET_BOTTOM_WIDE)
	deck.offset_top = -194
	deck.offset_bottom = -20
	deck.offset_left = 20
	deck.offset_right = -20
	var deck_row = HBoxContainer.new()
	deck_row.add_theme_constant_override("separation", 16)
	deck.add_child(deck_row)
	var minimap_col = VBoxContainer.new()
	deck_row.add_child(minimap_col)
	minimap_col.add_child(label("TACTICAL OVERVIEW", 10, MUTED, true))
	var map = TacticalMinimap.new()
	map.battle = battle
	map.field = field
	map.custom_minimum_size = Vector2(184, 110)
	minimap_col.add_child(map)
	var units_col = VBoxContainer.new()
	units_col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	deck_row.add_child(units_col)
	var units_header = HBoxContainer.new()
	units_col.add_child(units_header)
	units_header.add_child(label("YOUR PLATOON", 10, MUTED, true))
	spacer(units_header)
	var select_all_button = button("SELECT ALL", func(): battle.select_all(), Vector2(94, 26))
	select_all_button.add_theme_font_size_override("font_size", 10)
	units_header.add_child(select_all_button)
	var scroll = ScrollContainer.new()
	scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	units_col.add_child(scroll)
	roster = HBoxContainer.new()
	roster.add_theme_constant_override("separation", 8)
	scroll.add_child(roster)
	var orders = VBoxContainer.new()
	orders.custom_minimum_size.x = 340
	deck_row.add_child(orders)
	selection_label = label("SELECT A SQUAD", 12, CREAM, true)
	orders.add_child(selection_label)
	status_label = label("Tap a squad, then tap the battlefield.", 11, MUTED)
	orders.add_child(status_label)
	var commands = HBoxContainer.new()
	commands.add_theme_constant_override("separation", 6)
	orders.add_child(commands)
	commands.add_child(button("RETREAT", func(): battle.retreat_selected(), Vector2(108, 46)))
	commands.add_child(button("HOLD", func(): battle.hold_selected(), Vector2(78, 46)))
	ability_button = button("GRENADE", _toggle_ability, Vector2(132, 46))
	commands.add_child(ability_button)
	var second = HBoxContainer.new()
	second.add_theme_constant_override("separation", 6)
	orders.add_child(second)
	second.add_child(button("REINFORCE AT HQ", func(): battle.reinforce(), Vector2(190, 35)))
	second.add_child(button("ATTACK MOVE", func():
		field.attack_mode = not field.attack_mode
		toast("Tap a destination. Squads will stop and engage on contact."), Vector2(134, 35)))
	for b in second.get_children(): b.add_theme_font_size_override("font_size", 11)
	hint_panel = panel(root, Rect2(20, -236, 700, 43), Color(0.07, 0.13, 0.1, 0.92), 10)
	hint_panel.set_anchors_preset(Control.PRESET_BOTTOM_LEFT)
	hint_panel.offset_left = 20
	hint_panel.offset_right = 720
	hint_panel.offset_top = -248
	hint_panel.offset_bottom = -205
	hint_label = label("TAP to select / order    ·    DRAG to pan    ·    PINCH to zoom", 11, MUTED, true)
	hint_panel.add_child(hint_label)
	toast_panel = panel(root, Rect2(350, 116, 730, 44), Color(0.08, 0.14, 0.11, 0.97), 12)
	toast_panel.set_anchors_preset(Control.PRESET_CENTER_TOP)
	toast_panel.offset_left = -365
	toast_panel.offset_right = 365
	toast_panel.offset_top = 116
	toast_panel.offset_bottom = 160
	toast_label = label("", 13)
	toast_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	toast_panel.add_child(toast_label)
	toast_panel.visible = false

func _toggle_ability() -> void:
	if battle.selected.is_empty():
		toast("Select a squad before using an ability.")
		return
	field.ability_mode = not field.ability_mode
	toast("Tap nearby ground to build sandbags (12 supplies)." if battle.get_squad(battle.selected[0]).kind == "engineer" else "Tap a target area for a grenade (12 munitions).")
	refresh()

func _process(delta: float) -> void:
	_refresh_clock += delta
	if _refresh_clock >= 0.2:
		_refresh_clock = 0
		refresh()
	if toast_time > 0:
		toast_time -= delta
		if toast_time <= 0: toast_panel.visible = false

func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo:
		match event.physical_keycode:
			KEY_ESCAPE, KEY_SPACE:
				if _screen == "briefing" or _screen == "results": return
				if overlay: close_popup()
				else: show_pause()
				get_viewport().set_input_as_handled()
			KEY_M:
				if not overlay: show_market()
			KEY_B:
				if not overlay: show_recruit()

func refresh() -> void:
	if not is_instance_valid(roster): return
	resource_labels.credits.text = "%d" % int(battle.economy.credits)
	for good in WarEconomy.GOODS: resource_labels[good].text = "%d" % int(battle.economy.cargo[good])
	for team in [0, 1]: ticket_labels[team].text = "%03d" % int(ceil(battle.tickets[team]))
	clock_label.text = "%02d:%02d" % [int(battle.elapsed) / 60, int(battle.elapsed) % 60]
	var counts = [0, 0]
	for i in range(5):
		var point = battle.points[i]
		var c = TEAL if point.owner == 0 else (RED if point.owner == 1 else GOLD)
		point_buttons[i].add_theme_color_override("font_color", c)
		point_buttons[i].add_theme_stylebox_override("normal", box(Color(c, 0.09), Color(c, 0.4), 4, 6))
		if point.owner >= 0: counts[point.owner] += 1
	objective_label.text = ("ADVANTAGE / Enemy strength draining." if counts[0] >= 3 else ("LOSING GROUND / Capture a third sector." if counts[1] >= 3 else "Hold 3 of 5 sectors to drain\nenemy command strength."))
	var signature = str(battle.living(0).map(func(s): return s.id))
	if signature != _roster_signature:
		_roster_signature = signature
		_rebuild_roster()
	for squad in battle.living(0):
		var card = cards.get(squad.id)
		if card == null: continue
		var active = squad.id in battle.selected
		card.button.add_theme_stylebox_override("normal", box(Color("354936") if active else Color("1e3025"), GOLD if active else EDGE, 4, 8))
		card.health.value = squad.hp / squad.max_hp * 100
		card.status.text = "%d/%d  %s" % [squad.members(), squad.data().men, "★".repeat(squad.rank())]
		card.status.add_theme_color_override("font_color", RED if squad.suppression > 72 else MUTED)
	if battle.selected.is_empty():
		selection_label.text = "NO SQUAD SELECTED"
		status_label.text = "Tap a unit or its card to issue orders."
		ability_button.disabled = true
	else:
		var squad = battle.get_squad(battle.selected[0])
		if squad:
			selection_label.text = "%s / %s" % [squad.title, squad.data().short] if battle.selected.size() == 1 else "%d SQUADS SELECTED" % battle.selected.size()
			status_label.text = "%s  ·  %d%% HEALTH  ·  %s" % [squad.status(), int(ceil(squad.hp / squad.max_hp * 100)), "COVER +55%" if squad.cover > 0.4 else ("LIGHT COVER" if squad.cover > 0 else "EXPOSED")]
			ability_button.disabled = squad.ability_cd > 0
			ability_button.text = ("SANDBAGS" if squad.kind == "engineer" else "GRENADE") if squad.ability_cd <= 0 else "%ds COOLDOWN" % int(ceil(squad.ability_cd))
			if field.ability_mode: ability_button.text = "CANCEL TARGET"
	if field.ability_mode: hint_label.text = "ABILITY TARGETING / Tap an area inside the gold range ring."
	elif field.attack_mode: hint_label.text = "ATTACK MOVE / Tap a destination. Squads engage enemies on contact."
	else: hint_label.text = "TAP to select / order    ·    DRAG to pan    ·    PINCH to zoom"
	if _screen == "market": _refresh_market()

func _rebuild_roster() -> void:
	for child in roster.get_children():
		roster.remove_child(child)
		child.queue_free()
	cards.clear()
	for squad in battle.living(0):
		var b = button("", func():
			battle.select_squad(squad.id)
			field.focus(squad.pos), Vector2(126, 103))
		b.tooltip_text = "%s / %s — tap to select and focus" % [squad.title, squad.data().name]
		roster.add_child(b)
		var content = VBoxContainer.new()
		content.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
		content.offset_left = 10
		content.offset_right = -10
		content.offset_top = 7
		content.offset_bottom = -7
		content.mouse_filter = Control.MOUSE_FILTER_IGNORE
		content.add_theme_constant_override("separation", 2)
		b.add_child(content)
		var first = HBoxContainer.new()
		first.mouse_filter = Control.MOUSE_FILTER_IGNORE
		content.add_child(first)
		first.add_child(icon(squad.kind, Vector2(30, 33), TEAL))
		var title = label(squad.title, 11, CREAM, true)
		first.add_child(title)
		content.add_child(label(squad.data().short, 9, MUTED, true))
		var bar = ProgressBar.new()
		bar.custom_minimum_size.y = 4
		bar.show_percentage = false
		bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
		bar.add_theme_stylebox_override("background", box(Color("101e16"), Color("101e16"), 0, 0))
		bar.add_theme_stylebox_override("fill", box(TEAL, TEAL, 0, 0))
		content.add_child(bar)
		var state = label("5/5", 10, MUTED, true)
		content.add_child(state)
		cards[squad.id] = {"button": b, "health": bar, "status": state}

func toast(message: String) -> void:
	toast_label.text = message
	toast_panel.visible = true
	toast_time = 5.5

func modal(title: String, subtitle: String, dimensions: Vector2 = Vector2(1040, 666)) -> VBoxContainer:
	if overlay: close_popup()
	_previous_pause = battle.paused
	battle.paused = true
	overlay = Control.new()
	overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	overlay.mouse_filter = Control.MOUSE_FILTER_STOP
	root.add_child(overlay)
	var shade = ColorRect.new()
	shade.color = Color(0.025, 0.055, 0.04, 0.78)
	shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	shade.mouse_filter = Control.MOUSE_FILTER_STOP
	overlay.add_child(shade)
	var center = CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	center.mouse_filter = Control.MOUSE_FILTER_IGNORE
	overlay.add_child(center)
	popup = PanelContainer.new()
	popup.custom_minimum_size = dimensions
	popup.add_theme_stylebox_override("panel", box(Color("17271f"), Color("637052"), 8, 28))
	center.add_child(popup)
	var content = VBoxContainer.new()
	content.add_theme_constant_override("separation", 16)
	popup.add_child(content)
	var heading = HBoxContainer.new()
	content.add_child(heading)
	var col = VBoxContainer.new()
	heading.add_child(col)
	var text = label(title, 28)
	text.add_theme_font_override("font", BOLD)
	col.add_child(text)
	col.add_child(label(subtitle, 11, GOLD, true))
	spacer(heading)
	heading.add_child(button("X", close_popup, Vector2(48, 48)))
	line(content)
	return content

func close_popup() -> void:
	if _screen == "results": return
	if overlay:
		overlay.queue_free()
		overlay = null
		popup = null
		battle.paused = _previous_pause
		_screen = ""
		modal_value_labels.clear()
		market_buttons.clear()

func show_market() -> void:
	if battle.finished: return
	var content = modal("THE FIELD EXCHANGE", "REGIONAL COMMODITY MARKET / TACTICAL PAUSE", Vector2(1080, 650))
	_screen = "market"
	market_headline = label(battle.economy.headline, 14, GOLD)
	content.add_child(market_headline)
	var columns = HBoxContainer.new()
	columns.add_theme_constant_override("separation", 24)
	content.add_child(columns)
	var goods = VBoxContainer.new()
	goods.custom_minimum_size.x = 674
	columns.add_child(goods)
	var intro = HBoxContainer.new()
	goods.add_child(intro)
	intro.add_child(label("COMMODITY / REGIONAL PRICE", 11, MUTED, true))
	spacer(intro)
	intro.add_child(label("TRADE LOT / 10 UNITS", 11, MUTED, true))
	for good in WarEconomy.GOODS:
		var cell = PanelContainer.new()
		cell.add_theme_stylebox_override("panel", box(Color("1f3227"), EDGE, 5, 14))
		goods.add_child(cell)
		var v = VBoxContainer.new()
		cell.add_child(v)
		var row = HBoxContainer.new()
		v.add_child(row)
		row.add_child(icon(good, Vector2(40, 40), TEAL))
		var name_col = VBoxContainer.new()
		name_col.custom_minimum_size.x = 152
		row.add_child(name_col)
		name_col.add_child(label(WarEconomy.NAMES[good].to_upper(), 14, CREAM, true))
		var stock = label("", 10, MUTED, true)
		name_col.add_child(stock)
		var chart = MarketSparkline.new()
		chart.values = battle.economy.history[good]
		chart.custom_minimum_size = Vector2(130, 40)
		row.add_child(chart)
		spacer(row)
		var price = label("", 22, GOLD, true)
		row.add_child(price)
		var trade = HBoxContainer.new()
		v.add_child(trade)
		var owned = label("", 12, MUTED)
		owned.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		trade.add_child(owned)
		var sell = button("", func():
			toast(battle.economy.trade(good, false))
			refresh(), Vector2(140, 44))
		trade.add_child(sell)
		var buy = button("", func():
			toast(battle.economy.trade(good, true))
			refresh(), Vector2(140, 44), true)
		trade.add_child(buy)
		modal_value_labels[good] = {"price": price, "stock": stock, "owned": owned, "chart": chart}
		market_buttons[good] = {"sell": sell, "buy": buy}
	var logistics = VBoxContainer.new()
	logistics.custom_minimum_size.x = 294
	columns.add_child(logistics)
	logistics.add_child(label("SUPPLY LOGISTICS", 12, GOLD, true))
	var copy = label("Connected sectors produce cargo\nand credits every 6 seconds.\n\nCut off a route and production\nstops. Keep your frontline linked\nback to the Orchard and HQ.", 14, MUTED)
	logistics.add_child(copy)
	line(logistics)
	logistics.add_child(label("REQUEST A CONVOY", 15))
	logistics.add_child(label("45 supplies · 35 munitions · 15 fuel\n24-second delivery. Can be intercepted.", 12, MUTED))
	logistics.add_child(button("DISPATCH  /  140 cr + 8 fuel", func():
		battle.dispatch_convoy()
		refresh(), Vector2(0, 52)))
	convoy_label = label("", 12, TEAL)
	logistics.add_child(convoy_label)
	spacer(logistics, true)
	logistics.add_child(label("THE WAR MOVES THE MARKET", 11, GOLD, true))
	logistics.add_child(label("Battles drive munitions demand.\nShortages lift prices; arrivals lower\nthem. Sell surplus to fund your army.", 12, MUTED))
	spacer(content, true)
	var footer = HBoxContainer.new()
	content.add_child(footer)
	footer.add_child(label("Buy/sell spread prevents instant resale profit. Stock and prices update with each trade.", 11, MUTED))
	spacer(footer)
	footer.add_child(button("BACK TO THE FRONT", close_popup, Vector2(214, 48)))
	_refresh_market()

func _refresh_market() -> void:
	for good in WarEconomy.GOODS:
		if not modal_value_labels.has(good): continue
		var labels = modal_value_labels[good]
		labels.price.text = "%.1f cr" % battle.economy.prices[good]
		labels.stock.text = "%d AVAILABLE" % int(battle.economy.stock[good])
		labels.owned.text = "YOUR CARGO  /  %d" % int(battle.economy.cargo[good])
		labels.chart.queue_redraw()
		market_buttons[good].buy.text = "BUY  /  %d cr" % battle.economy.quote(good, true)
		market_buttons[good].sell.text = "SELL  /  %d cr" % battle.economy.quote(good, false)
		market_buttons[good].buy.disabled = battle.economy.credits < battle.economy.quote(good, true) or battle.economy.stock[good] < 10 or battle.economy.cargo[good] + 10 > 999
		market_buttons[good].sell.disabled = battle.economy.cargo[good] < 10
	if is_instance_valid(convoy_label):
		convoy_label.text = "No delivery in transit." if battle.convoys.is_empty() else "INBOUND / %ds remaining" % int(ceil(battle.convoys[0].time))

func show_recruit() -> void:
	if battle.finished: return
	var content = modal("BUILD YOUR PLATOON", "FORWARD HQ / %d OF 8 SQUAD SLOTS / TACTICAL PAUSE" % battle.living(0).size(), Vector2(1080, 654))
	_screen = "recruit"
	var grid = GridContainer.new()
	grid.columns = 3
	grid.add_theme_constant_override("h_separation", 14)
	grid.add_theme_constant_override("v_separation", 14)
	content.add_child(grid)
	for kind in CombatSquad.TYPES:
		var data = CombatSquad.TYPES[kind]
		var cell = PanelContainer.new()
		cell.custom_minimum_size = Vector2(328, 204)
		cell.add_theme_stylebox_override("panel", box(Color("21362a"), EDGE, 5, 16))
		grid.add_child(cell)
		var v = VBoxContainer.new()
		cell.add_child(v)
		var heading = HBoxContainer.new()
		v.add_child(heading)
		heading.add_child(icon(kind, Vector2(44, 44), TEAL))
		heading.add_child(label(data.name.to_upper(), 14))
		var copy = label(data.description, 12, MUTED)
		copy.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		v.add_child(copy)
		spacer(v, true)
		var cost = cost_string(data.cost)
		var b = button(cost, func():
			if battle.recruit(kind): close_popup(), Vector2(0, 46), true)
		b.add_theme_font_size_override("font_size", 12)
		b.disabled = not battle.economy.can_pay(data.cost) or battle.living(0).size() >= 8
		v.add_child(b)
	var tip = PanelContainer.new()
	tip.custom_minimum_size = Vector2(328, 204)
	tip.add_theme_stylebox_override("panel", box(Color("18291f"), EDGE, 5, 18))
	grid.add_child(tip)
	var tips = VBoxContainer.new()
	tip.add_child(tips)
	tips.add_child(label("A SMALL ARMY.\nA SMARTER PLAN.", 20, GOLD))
	tips.add_child(label("MGs pin. Assault sections flank.\nEngineers capture faster and\nbuild cover. Carriers need fuel.\n\nRetreat to preserve your veterans.", 13, MUTED))
	spacer(content, true)
	content.add_child(button("RETURN TO BATTLE", close_popup, Vector2(0, 48)))

func cost_string(cost: Dictionary) -> String:
	var pieces: Array[String] = []
	for key in cost:
		pieces.append("%d %s" % [cost[key], {"credits": "cr", "supplies": "sup", "ammo": "ammo", "fuel": "fuel"}[key]])
	return "  /  ".join(pieces)

func show_pause() -> void:
	if battle.finished: return
	var content = modal("TACTICAL PAUSE", "TAKE A BREATH. PLAN YOUR NEXT MOVE.", Vector2(640, 550))
	_screen = "pause"
	content.add_child(button("RESUME OPERATION", close_popup, Vector2(0, 56), true))
	content.add_child(button("FIELD GUIDE / CONTROLS", show_guide, Vector2(0, 50)))
	var sound = button("SOUND / " + ("ON" if sound_enabled else "OFF"), func():
		sound_enabled = not sound_enabled
		audio_changed.emit(sound_enabled)
		show_pause(), Vector2(0, 48))
	content.add_child(sound)
	content.add_child(button("SAVE & RETURN TO BRIEFING", func(): menu_requested.emit(), Vector2(0, 48)))
	content.add_child(label("Progress autosaves locally every 30 seconds.\nAndroid Back / Esc opens this menu. No network required.", 12, MUTED))

func show_guide() -> void:
	# Keep the simulation paused when navigating between modal pages.
	var was_paused = _previous_pause
	var from_briefing = _screen == "briefing"
	var content = modal("FIELD MANUAL", "SQUAD TACTICS / LOGISTICS / CONTROLS", Vector2(1050, 640))
	_previous_pause = was_paused
	_screen = "guide"
	var return_action = func():
		if from_briefing: show_briefing(FileAccess.file_exists("user://operation.json"), resume_callback_saved)
		else: close_popup()
	var guide_close: Button = content.get_child(0).get_child(content.get_child(0).get_child_count() - 1)
	guide_close.pressed.disconnect(close_popup)
	guide_close.pressed.connect(return_action)
	var columns = HBoxContainer.new()
	columns.add_theme_constant_override("separation", 28)
	content.add_child(columns)
	for entry in [
		["01 / COMMAND", "Tap a squad or its card to select.\nTap terrain to move; tap a visible\nenemy to attack. Select All moves\nyour platoon in formation.\n\nDrag empty terrain to pan. Pinch\nto zoom. Tap the minimap to focus.\n\nPC: right-click to order, WASD to\npan, wheel to zoom, 1–8 to select.\nShift-tap adds squads. F focuses.\nSpace pauses; M trades; B recruits."],
		["02 / FIGHT", "Squads fire automatically in range.\nMG sections suppress: pinned\ninfantry moves and fires slowly.\n\nSandbags absorb frontal fire.\nFlank the cover to break through.\nEngineers can build more cover.\n\nUse Attack Move to stop and fire.\nGrenades break packed defenses.\nRetreat [R] to escape, then use\nReinforce at HQ to replace losses.\nVeterans gain damage with combat."],
		["03 / SUSTAIN", "Infantry captures a sector by\nstanding inside its ring. Engineers\ncapture faster. Contested sectors\nfreeze until the enemy withdraws.\n\nHold 3 of 5 sectors to drain enemy\nstrength. First army to zero loses.\n\nConnect sectors back through A\nto earn resources every 6 seconds.\nTrade at the market to fill shortages.\nConvoys bring cheaper bulk cargo,\nbut enemies can intercept them."]
	]:
		var col = VBoxContainer.new()
		col.custom_minimum_size.x = 312
		columns.add_child(col)
		col.add_child(label(entry[0], 14, GOLD, true))
		col.add_child(label(entry[1], 14, MUTED))
	spacer(content, true)
	content.add_child(button("RETURN TO BRIEFING" if from_briefing else "RETURN TO BATTLE", return_action, Vector2(0, 50), true))

func show_briefing(can_resume: bool = false, resume_callback: Callable = Callable()) -> void:
	resume_callback_saved = resume_callback
	var content = modal("SABLE FRONT", "SQUAD TACTICS / A LIVING WAR ECONOMY", Vector2(1060, 675))
	_screen = "briefing"
	_previous_pause = false
	# The briefing is a deployment screen; closing it deploys the prepared match.
	var close_button = content.get_child(0).get_child(content.get_child(0).get_child_count() - 1)
	close_button.visible = false
	var body = HBoxContainer.new()
	body.add_theme_constant_override("separation", 32)
	content.add_child(body)
	var poster = PanelContainer.new()
	poster.custom_minimum_size = Vector2(336, 390)
	poster.add_theme_stylebox_override("panel", box(Color("263d2b"), Color("5a6b47"), 4, 26))
	body.add_child(poster)
	var pv = VBoxContainer.new()
	poster.add_child(pv)
	pv.add_child(label("MERIDIAN THEATER", 11, GOLD, true))
	pv.add_child(icon("emblem", Vector2(180, 180), GOLD))
	spacer(pv, true)
	pv.add_child(label("EVERY SQUAD\nHAS A COST.\nEVERY ROUTE\nHAS A PRICE.", 29, CREAM))
	var v = VBoxContainer.new()
	v.custom_minimum_size.x = 600
	v.add_theme_constant_override("separation", 14)
	body.add_child(v)
	v.add_child(label("OPERATION 01", 12, GOLD, true))
	var title = label("LOW TIDE", 46)
	title.add_theme_font_override("font", BOLD)
	v.add_child(title)
	v.add_child(label("The canal is the frontline. The supply road is the lifeline.", 16, MUTED))
	line(v)
	v.add_child(label("Lead a small platoon through the Meridian farmlands. Seize\nthree of five sectors, keep your routes connected, and wear\ndown the opposition before your command strength runs out.", 16))
	v.add_child(label("SQUAD WARFARE", 11, GOLD, true))
	v.add_child(label("Cover. Suppression. Flanking. Preserve your veterans.", 14, MUTED))
	v.add_child(label("A LIVING ECONOMY", 11, GOLD, true))
	v.add_child(label("Scarcity changes prices. Trade surplus. Protect your convoys.", 14, MUTED))
	spacer(v, true)
	v.add_child(label("OFFLINE SKIRMISH  ·  LANDSCAPE  ·  TOUCH + MOUSE", 11, MUTED, true))
	spacer(content, true)
	var actions = HBoxContainer.new()
	content.add_child(actions)
	actions.add_child(button("FIELD MANUAL", func():
		show_guide()
		_previous_pause = false, Vector2(178, 54)))
	var mode = OptionButton.new()
	mode.custom_minimum_size = Vector2(192, 54)
	for name_value in ["RELAXED", "STANDARD", "VETERAN"]: mode.add_item(name_value)
	mode.select(battle.difficulty)
	mode.item_selected.connect(func(index): battle.difficulty = index)
	actions.add_child(mode)
	spacer(actions)
	if can_resume:
		actions.add_child(button("CONTINUE OPERATION", func():
			close_popup()
			if resume_callback.is_valid(): resume_callback.call(), Vector2(244, 54)))
	actions.add_child(button("DEPLOY PLATOON  >", func():
		close_popup()
		restart_requested.emit(), Vector2(236, 54), true))

func show_results(result_winner: int) -> void:
	# Ended matches cannot resume through Escape or the close button.
	var content = modal("SECTOR SECURED" if result_winner == 0 else "OPERATION LOST", "AFTER-ACTION REPORT / MERIDIAN THEATER", Vector2(740, 570))
	_screen = "results"
	content.get_child(0).get_child(content.get_child(0).get_child_count() - 1).visible = false
	content.add_child(label("The supply line held. The front is yours." if result_winner == 0 else "The line broke. Regroup and rethink your supply routes.", 18, TEAL if result_winner == 0 else RED))
	var duration = "%02d:%02d" % [int(battle.elapsed) / 60, int(battle.elapsed) % 60]
	for text in ["OPERATION TIME  /  " + duration, "ENEMY SECTIONS ELIMINATED  /  %d" % battle.kills[0], "SECTORS CAPTURED  /  %d" % battle.captures, "SURVIVING SQUADS  /  %d" % battle.living(0).size()]:
		content.add_child(label(text, 17, MUTED, true))
	spacer(content, true)
	content.add_child(button("DEPLOY AGAIN", func():
		_screen = ""
		close_popup()
		restart_requested.emit(), Vector2(0, 56), true))
