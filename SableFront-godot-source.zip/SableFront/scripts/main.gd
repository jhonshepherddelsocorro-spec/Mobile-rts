extends Node

const SAVE_PATH = "user://operation.json"
var battle: BattleSimulation
var field: BattlefieldView
var ui: CommandInterface
var audio: BattlefieldAudio
var autosave_clock: float = 0
var screenshot_path: String = ""
var screenshot_at: float = 3.0
var _real_time: float = 0
var _has_captured: bool = false
var _autoplay: bool = false
var _smoke_seconds: float = 0.0
var _shutting_down: bool = false

func _ready() -> void:
	get_tree().auto_accept_quit = false
	for arg in OS.get_cmdline_user_args():
		if arg == "--demo": _autoplay = true
		elif arg.begins_with("--screenshot="): screenshot_path = arg.trim_prefix("--screenshot=")
		elif arg.begins_with("--capture-at="): screenshot_at = float(arg.trim_prefix("--capture-at="))
		elif arg.begins_with("--smoke-seconds="): _smoke_seconds = float(arg.trim_prefix("--smoke-seconds="))
	_create_match(1)
	if _autoplay:
		_demo_orders()
	else:
		battle.paused = true
		ui.show_briefing(FileAccess.file_exists(SAVE_PATH), _resume)

func _create_match(difficulty: int) -> void:
	battle = BattleSimulation.new()
	battle.setup(difficulty)
	add_child(battle)
	field = BattlefieldView.new()
	field.battle = battle
	add_child(field)
	ui = CommandInterface.new()
	ui.battle = battle
	ui.field = field
	add_child(ui)
	ui.restart_requested.connect(func(): _restart.call_deferred())
	ui.menu_requested.connect(func(): _return_to_menu.call_deferred())
	ui.audio_changed.connect(func(enabled): audio.enabled = enabled)
	ui.battle.match_ended.connect(func(_winner):
		if FileAccess.file_exists(SAVE_PATH): DirAccess.remove_absolute(SAVE_PATH))
	audio = BattlefieldAudio.new()
	audio.battle = battle
	add_child(audio)
	autosave_clock = 0

func _destroy_match() -> void:
	for child in [audio, ui, field, battle]:
		remove_child(child)
		child.queue_free()

func _restart() -> void:
	var level = battle.difficulty
	var sound = audio.enabled
	_destroy_match()
	_create_match(level)
	audio.enabled = sound
	ui.sound_enabled = sound
	ui.toast("Secure three sectors. Your Orchard supply route is already linked. Good hunting, commander.")
	_save()

func _return_to_menu() -> void:
	_save()
	ui.close_popup()
	battle.paused = true
	ui.show_briefing(true, _resume)

func _resume() -> void:
	var file = FileAccess.open(SAVE_PATH, FileAccess.READ)
	if file == null:
		ui.toast("No saved operation found. Deploy a new platoon.")
		return
	var data = JSON.parse_string(file.get_as_text())
	if not data is Dictionary or not battle.restore(data):
		ui.toast("The saved operation is unreadable. A fresh platoon is ready to deploy.")
		return
	battle.paused = false
	field.focus(battle.get_squad(battle.selected[0]).pos if not battle.selected.is_empty() else BattleSimulation.BASES[0])
	ui.refresh()
	ui.toast("Operation restored. Welcome back, commander.")

func _save() -> bool:
	if battle.finished: return false
	# Atomic replacement preserves the previous save if a write is interrupted.
	var file = FileAccess.open(SAVE_PATH + ".tmp", FileAccess.WRITE)
	if file == null: return false
	file.store_string(JSON.stringify(battle.snapshot()))
	file.close()
	return DirAccess.rename_absolute(SAVE_PATH + ".tmp", SAVE_PATH) == OK

func _process(delta: float) -> void:
	_real_time += delta
	if _smoke_seconds > 0 and _real_time >= _smoke_seconds and not _shutting_down:
		_shutdown()
	if not battle.paused and not battle.finished:
		autosave_clock += delta
		if autosave_clock >= 30:
			autosave_clock = 0
			_save()
	if screenshot_path != "" and not _has_captured and _real_time >= screenshot_at:
		_has_captured = true
		_capture.call_deferred()

func _capture() -> void:
	await RenderingServer.frame_post_draw
	var image = get_viewport().get_texture().get_image()
	var error = image.save_png(screenshot_path)
	print("SCREENSHOT: ", screenshot_path, " result=", error)

func _notification(what: int) -> void:
	if not is_instance_valid(battle) or not is_instance_valid(ui): return
	if what == NOTIFICATION_WM_CLOSE_REQUEST:
		_shutdown.call_deferred()
	elif what == NOTIFICATION_APPLICATION_PAUSED or what == NOTIFICATION_WM_GO_BACK_REQUEST:
		_save()
		if not battle.paused and not battle.finished: ui.show_pause()

func _shutdown() -> void:
	if _shutting_down: return
	_shutting_down = true
	_save()
	battle.paused = true
	audio.stop_all()
	# Allow the audio mixing thread to release queued playbacks before exit.
	await get_tree().create_timer(0.15).timeout
	get_tree().quit()

func _demo_orders() -> void:
	# Reproducible visual smoke-test setup using the same public order API.
	battle.selected = [0]
	battle.command(Vector2(600, 1030))
	battle.selected = [1]
	battle.command(Vector2(990, 560), true)
	battle.selected = [2]
	battle.command(Vector2(960, 1030))
	battle.selected = [0]
	ui.refresh()
