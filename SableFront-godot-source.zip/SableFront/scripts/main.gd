extends Node

const SAVE_PATH = "user://operation.json"
const CAMPAIGN_PATH = "user://campaign.json"
var battle: BattleSimulation
var field: BattlefieldView
var ui: CommandInterface
var audio: BattlefieldAudio
var campaign: TheaterCampaign
var world_ui: CampaignInterface
var preferences: FieldPreferences
var mode: String = "home"
var testing_skirmish: bool = false
var autosave_clock: float = 0
var screenshot_path: String = ""
var screenshot_at: float = 3.0
var _real_time: float = 0
var _has_captured: bool = false
var _autoplay: bool = false
var _campaign_demo: bool = false
var _smoke_seconds: float = 0.0
var _shutting_down: bool = false

func _ready() -> void:
	get_tree().auto_accept_quit = false
	preferences = FieldPreferences.new()
	for arg in OS.get_cmdline_user_args():
		if arg == "--demo": _autoplay = true
		elif arg == "--campaign-demo": _campaign_demo = true
		elif arg.begins_with("--screenshot="): screenshot_path = arg.trim_prefix("--screenshot=")
		elif arg.begins_with("--capture-at="): screenshot_at = float(arg.trim_prefix("--capture-at="))
		elif arg.begins_with("--smoke-seconds="): _smoke_seconds = float(arg.trim_prefix("--smoke-seconds="))
	if testing_skirmish: preferences.large_controls = false
	preferences.apply(get_window())
	if _autoplay or testing_skirmish:
		_create_match(1)
		if _autoplay: _demo_orders()
		else:
			battle.paused = true
			ui.show_briefing(FileAccess.file_exists(SAVE_PATH), _resume)
	elif _campaign_demo: _new_campaign(1)
	else: _show_home(false)

func _clear_views() -> void:
	for child in [audio, ui, field, battle, world_ui]:
		if is_instance_valid(child):
			if child == battle: battle.set_process(false)
			if child == audio: audio.stop_all()
			remove_child(child)
			child.queue_free()
	audio = null
	ui = null
	field = null
	battle = null
	world_ui = null

func _show_home(save_first: bool = true) -> void:
	if save_first: _save()
	_clear_views()
	mode = "home"
	campaign = null
	var preview = TheaterCampaign.new()
	preview.setup()
	_create_world(preview, true)

func _create_world(model: TheaterCampaign, home: bool) -> void:
	world_ui = CampaignInterface.new()
	world_ui.campaign = model
	world_ui.preferences = preferences
	world_ui.home_mode = home
	add_child(world_ui)
	world_ui.new_campaign_requested.connect(func(level): _new_campaign.call_deferred(level))
	world_ui.continue_campaign_requested.connect(func(): _resume_campaign.call_deferred())
	world_ui.skirmish_requested.connect(func(): _start_skirmish.call_deferred(false))
	world_ui.continue_skirmish_requested.connect(func(): _start_skirmish.call_deferred(true))
	world_ui.home_requested.connect(func(): _show_home.call_deferred())
	world_ui.command_battle_requested.connect(func(): _start_campaign_battle.call_deferred())
	world_ui.auto_battle_requested.connect(func(): _auto_battle.call_deferred())
	world_ui.preference_changed.connect(_apply_preferences)
	world_ui.exit_requested.connect(func(): _shutdown.call_deferred())

func _connect_campaign() -> void:
	campaign.changed.connect(_save_campaign)
	campaign.battle_requested.connect(func(_context): _pending_battle.call_deferred())

func _new_campaign(level: int) -> void:
	_clear_views()
	campaign = TheaterCampaign.new()
	campaign.setup(level)
	campaign.selected_region = 12
	_connect_campaign()
	_show_campaign()
	_save_campaign()
	world_ui.toast("Select an army and a province, then confirm your march. Defend Haven and capture Iron Crown.")

func _show_campaign() -> void:
	_clear_views()
	mode = "campaign"
	if campaign.phase == "enemy": campaign.advance_enemy_phase()
	_create_world(campaign, false)
	if campaign.phase == "battle": world_ui.show_battle_preview()
	elif campaign.phase in ["victory", "defeat"]: world_ui.show_campaign_end()
	_save_campaign()

func _pending_battle() -> void:
	if campaign == null or campaign.phase != "battle" or mode == "battle": return
	if not is_instance_valid(world_ui): _show_campaign()
	elif world_ui._screen != "battle_preview": world_ui.show_battle_preview()
	_save_campaign()

func _start_campaign_battle() -> void:
	if campaign == null or campaign.phase != "battle" or campaign.pending.is_empty(): return
	if is_instance_valid(battle): return
	_clear_views()
	_create_match(campaign.difficulty, campaign.pending)
	_save_campaign()
	ui.toast("%s / Veterans and casualties persist. Capture three sectors and preserve your army." % campaign.pending.name.capitalize())

func _auto_battle() -> void:
	if campaign != null and campaign.auto_resolve(): _show_campaign()

func _complete_campaign_battle() -> void:
	if not is_instance_valid(battle) or not battle.finished or campaign == null: return
	var context_id = int(battle.campaign_context.get("id", -1))
	if not campaign.resolve_battle(context_id, battle.winner, battle.campaign_survivors(0), battle.campaign_survivors(1)):
		ui.toast("Could not commit this battle result. The saved operation has been preserved.")
		return
	_show_campaign()

func _create_match(level: int, context: Dictionary = {}) -> void:
	var next = BattleSimulation.new()
	if context.is_empty(): next.setup(level)
	else:
		next.setup(level, int(context.seed), context.biome)
		next.configure_campaign(context, campaign.economy, campaign.allowed_kinds())
	_attach_match(next)

func _attach_match(next: BattleSimulation) -> void:
	mode = "battle"
	battle = next
	battle.quality = preferences.quality
	add_child(battle)
	field = BattlefieldView.new()
	field.battle = battle
	add_child(field)
	ui = CommandInterface.new() if testing_skirmish else MobileCommandInterface.new()
	ui.battle = battle
	ui.field = field
	if ui is MobileCommandInterface:
		ui.preferences = preferences
		ui.campaign_mode = not battle.campaign_context.is_empty()
		ui.campaign_return_requested.connect(func(): _complete_campaign_battle.call_deferred())
		ui.preference_changed.connect(_apply_preferences)
	add_child(ui)
	ui.restart_requested.connect(func(): _restart.call_deferred())
	ui.menu_requested.connect(func(): _return_to_menu.call_deferred())
	ui.audio_changed.connect(func(enabled):
		preferences.sound = enabled
		preferences.save()
		_apply_preferences())
	battle.match_ended.connect(_on_battle_ended)
	audio = BattlefieldAudio.new()
	audio.battle = battle
	add_child(audio)
	audio.enabled = preferences.sound
	ui.sound_enabled = preferences.sound
	autosave_clock = 0
	if battle.finished: ui.show_results(battle.winner)

func _on_battle_ended(_winner: int) -> void:
	if campaign != null and not battle.campaign_context.is_empty(): _save_campaign()
	elif FileAccess.file_exists(SAVE_PATH): DirAccess.remove_absolute(SAVE_PATH)

func _start_skirmish(resume_saved: bool = false) -> void:
	_save()
	_clear_views()
	campaign = null
	_create_match(1)
	if resume_saved: _resume()
	else:
		battle.paused = true
		ui.show_briefing(FileAccess.file_exists(SAVE_PATH), _resume)

func _restart() -> void:
	if campaign != null and not battle.campaign_context.is_empty(): return
	var level = battle.difficulty
	_clear_views()
	_create_match(level)
	ui.toast("Secure three sectors. The Orchard supply route is already linked. Good hunting, commander.")
	_save()

func _return_to_menu() -> void:
	if testing_skirmish:
		_save()
		ui.close_popup()
		battle.paused = true
		ui.show_briefing(true, _resume)
	else: _show_home()

func _atomic_write(path: String, data: Dictionary) -> bool:
	var file = FileAccess.open(path + ".tmp", FileAccess.WRITE)
	if file == null: return false
	file.store_string(JSON.stringify(data))
	file.close()
	return DirAccess.rename_absolute(path + ".tmp", path) == OK

func _save_campaign() -> bool:
	if campaign == null or mode == "home": return false
	var active: Variant = null
	if campaign.phase == "battle" and is_instance_valid(battle): active = battle.snapshot()
	return _atomic_write(CAMPAIGN_PATH, {"format": 2, "campaign": campaign.snapshot(), "battle": active})

func _save() -> bool:
	if campaign != null: return _save_campaign()
	if not is_instance_valid(battle) or battle.finished: return false
	return _atomic_write(SAVE_PATH, battle.snapshot())

func _read_json(path: String) -> Variant:
	var file = FileAccess.open(path, FileAccess.READ)
	if file == null: return null
	return JSON.parse_string(file.get_as_text())

func _resume() -> void:
	var data = _read_json(SAVE_PATH)
	if not data is Dictionary or not battle.restore(data):
		ui.toast("The saved skirmish is unreadable. A fresh platoon is ready to deploy.")
		return
	battle.paused = false
	field.focus(battle.get_squad(battle.selected[0]).pos if not battle.selected.is_empty() else BattleSimulation.BASES[0])
	ui.refresh()
	ui.toast("Operation restored. Welcome back, commander.")

func _resume_campaign() -> void:
	var data = _read_json(CAMPAIGN_PATH)
	if not data is Dictionary or data.get("format") != 2 or not data.get("campaign") is Dictionary:
		world_ui.toast("This campaign save cannot be read. Your file has not been replaced.")
		return
	var restored = TheaterCampaign.new()
	if not restored.restore(data.campaign):
		world_ui.toast("Campaign save validation failed. Your file has not been replaced.")
		return
	var active: BattleSimulation = null
	if data.get("battle") is Dictionary and restored.phase == "battle":
		active = BattleSimulation.new()
		active.setup(restored.difficulty, int(restored.pending.seed), restored.pending.biome)
		if not active.restore(data.battle) or active.campaign_context.get("id") != restored.pending.id:
			active.free()
			world_ui.toast("Saved battle validation failed. Your campaign file has not been replaced.")
			return
		active.economy = restored.economy
	_clear_views()
	campaign = restored
	_connect_campaign()
	if active != null:
		_attach_match(active)
		ui.toast("Campaign battle restored. Every section is where you left it.")
	else: _show_campaign()

func _apply_preferences() -> void:
	preferences.apply(get_window())
	if is_instance_valid(ui): FieldPreferences.apply_safe_area(ui.root)
	if is_instance_valid(world_ui): FieldPreferences.apply_safe_area(world_ui.root)
	if is_instance_valid(audio): audio.enabled = preferences.sound
	if is_instance_valid(battle):
		battle.quality = preferences.quality
		field.terrain.queue_redraw()

func _process(delta: float) -> void:
	_real_time += delta
	if _smoke_seconds > 0 and _real_time >= _smoke_seconds and not _shutting_down: _shutdown()
	if is_instance_valid(battle) and not battle.paused and not battle.finished:
		autosave_clock += delta
		if autosave_clock >= 20:
			autosave_clock = 0
			_save()
	if screenshot_path != "" and not _has_captured and _real_time >= screenshot_at:
		_has_captured = true
		_capture.call_deferred()

func _capture() -> void:
	await RenderingServer.frame_post_draw
	var image = get_viewport().get_texture().get_image()
	print("SCREENSHOT: ", screenshot_path, " result=", image.save_png(screenshot_path))

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_CLOSE_REQUEST:
		_shutdown.call_deferred()
	elif what == NOTIFICATION_APPLICATION_PAUSED:
		_save()
		if is_instance_valid(battle) and not battle.paused and not battle.finished: ui.show_pause()
	elif what == NOTIFICATION_WM_GO_BACK_REQUEST:
		if is_instance_valid(world_ui): world_ui.back()
		elif is_instance_valid(ui):
			if ui is MobileCommandInterface: ui.back()
			elif not battle.finished:
				if ui.overlay: ui.close_popup()
				else: ui.show_pause()
		_save()

func _shutdown() -> void:
	if _shutting_down: return
	_shutting_down = true
	_save()
	if is_instance_valid(battle): battle.paused = true
	if is_instance_valid(audio): audio.stop_all()
	await get_tree().create_timer(0.15).timeout
	get_tree().quit()

func _demo_orders() -> void:
	battle.selected = [0]
	battle.command(Vector2(600, 1030))
	battle.selected = [1]
	battle.command(Vector2(990, 560), true)
	battle.selected = [2]
	battle.command(Vector2(960, 1030))
	battle.selected = [0]
	ui.refresh()
