class_name TacticalMinimap
extends Control

var battle: BattleSimulation
var field: BattlefieldView

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_STOP
	clip_contents = true
	queue_redraw()

func _process(_delta: float) -> void:
	queue_redraw()

func _gui_input(event: InputEvent) -> void:
	if (event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT) or (event is InputEventScreenTouch and event.pressed) or event is InputEventScreenDrag:
		field.focus(event.position / size * BattleSimulation.WORLD)
		accept_event()

func _draw() -> void:
	if battle == null or field.camera == null: return
	draw_rect(Rect2(Vector2.ZERO, size), Color("485b45"))
	var scale_factor = size / BattleSimulation.WORLD
	var river = PackedVector2Array()
	for y in range(0, 1800, 40): river.append(Vector2(BattleSimulation.river_x(y), y) * scale_factor)
	if battle.map_style == "canal": draw_polyline(river, Color("2b4546"), 14, true)
	for rect in battle.buildings:
		draw_rect(Rect2(rect.position * scale_factor, rect.size * scale_factor), Color("7b7a5e"))
	for link in BattleSimulation.LINKS:
		draw_line(battle.points[link[0]].pos * scale_factor, battle.points[link[1]].pos * scale_factor, Color(0.8, 0.79, 0.63, 0.2), 1)
	for point in battle.points:
		var color = BattlefieldView.FRIEND if point.owner == 0 else (BattlefieldView.ENEMY if point.owner == 1 else BattlefieldView.GOLD)
		draw_circle(point.pos * scale_factor, 4, color)
	for squad in battle.squads:
		if squad.alive and (squad.team == 0 or battle.visible_at(squad.pos)):
			draw_circle(squad.pos * scale_factor, 2.6, BattlefieldView.FRIEND if squad.team == 0 else BattlefieldView.ENEMY)
	for team in [0, 1]:
		draw_rect(Rect2(BattleSimulation.BASES[team] * scale_factor - Vector2(4, 4), Vector2(8, 8)), BattlefieldView.FRIEND if team == 0 else BattlefieldView.ENEMY, false, 2)
	var visible_size = get_viewport_rect().size / field.camera.zoom
	var rect = Rect2((field.camera.position - visible_size / 2) * scale_factor, visible_size * scale_factor)
	draw_rect(rect, Color(0.95, 0.9, 0.7, 0.7), false, 1.5)
	draw_rect(Rect2(Vector2.ZERO, size), Color("647263"), false, 1)
