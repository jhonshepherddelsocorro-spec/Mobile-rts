class_name MobileCommandInterface
extends CommandInterface

signal campaign_return_requested
signal preference_changed
var preferences: FieldPreferences
var campaign_mode: bool = false
var overview: PanelContainer
var _multi_button: Button
var _smart_button: Button

func button(text: String, callback: Callable, minimum: Vector2 = Vector2(0, 60), accent: bool = false) -> Button:
	var result = super.button(text, callback, Vector2(minimum.x, maxf(50, minimum.y)), accent)
	result.pressed.connect(func():
		if preferences: preferences.tap())
	return result

func _build_hud() -> void:
	field.auto_engage = true
	var top = panel(root, Rect2(14, 14, 1252, 78), Color("14241c"), 12)
	top.set_anchors_preset(Control.PRESET_TOP_WIDE)
	top.offset_right = -14
	var row = HBoxContainer.new()
	top.add_child(row)
	row.add_child(icon("emblem", Vector2(42, 42)))
	var brand = VBoxContainer.new()
	brand.custom_minimum_size.x = 165
	row.add_child(brand)
	brand.add_child(label("SABLE FRONT", 20))
	brand.add_child(label(battle.campaign_context.get("name", "QUICK OPERATION"), 11, GOLD, true))
	for good in ["credits", "supplies", "ammo", "fuel"]:
		var col = VBoxContainer.new()
		col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		col.add_theme_constant_override("separation", 0)
		row.add_child(col)
		col.add_child(label("CREDITS" if good == "credits" else WarEconomy.NAMES[good].to_upper(), 11, MUTED, true))
		var amount = label("0", 25, CREAM, true)
		col.add_child(amount)
		resource_labels[good] = amount
	row.add_child(button("MARKET", show_market, Vector2(115, 56)))
	pause_button = button("PAUSE", show_pause, Vector2(90, 56))
	row.add_child(pause_button)
	var mission = panel(root, Rect2(14, 104, 225, 124), Color(0.06, 0.12, 0.085, 0.94), 12)
	var v = VBoxContainer.new()
	mission.add_child(v)
	var heading = HBoxContainer.new()
	v.add_child(heading)
	heading.add_child(label("COMMAND STRENGTH", 10, GOLD, true))
	spacer(heading)
	clock_label = label("00:00", 11, MUTED, true)
	heading.add_child(clock_label)
	var strength = HBoxContainer.new()
	v.add_child(strength)
	for team in [0, 1]:
		var score = label("300", 30, TEAL if team == 0 else RED, true)
		score.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		strength.add_child(score)
		ticket_labels.append(score)
	objective_label = label("Hold 3 sectors to win.", 12, MUTED)
	v.add_child(objective_label)
	var sectors = HBoxContainer.new()
	root.add_child(sectors)
	sectors.set_anchors_preset(Control.PRESET_CENTER_TOP)
	sectors.offset_left = -165
	sectors.offset_right = 165
	sectors.offset_top = 106
	sectors.offset_bottom = 162
	sectors.add_theme_constant_override("separation", 6)
	for i in range(5):
		var b = button(battle.points[i].code, func(): field.focus(battle.points[i].pos), Vector2(58, 54))
		sectors.add_child(b)
		point_buttons.append(b)
	var recruit = button("+ RECRUIT", show_recruit, Vector2(175, 64), true)
	root.add_child(recruit)
	recruit.set_anchors_preset(Control.PRESET_BOTTOM_LEFT)
	recruit.offset_left = 14
	recruit.offset_right = 189
	recruit.offset_top = -286
	recruit.offset_bottom = -222
	var navigation = HBoxContainer.new()
	root.add_child(navigation)
	navigation.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
	navigation.offset_left = -286
	navigation.offset_right = -14
	navigation.offset_top = -282
	navigation.offset_bottom = -222
	navigation.add_theme_constant_override("separation", 6)
	navigation.add_child(button("+", func(): field.zoom_by(1.2), Vector2(56, 58)))
	navigation.add_child(button("-", func(): field.zoom_by(1.0 / 1.2), Vector2(56, 58)))
	navigation.add_child(button("HQ", func(): field.focus(BattleSimulation.BASES[0]), Vector2(65, 58)))
	navigation.add_child(button("MAP", func(): overview.visible = not overview.visible, Vector2(65, 58)))
	overview = panel(root, Rect2(14, 0, 315, 224), Color("182c20"), 12)
	overview.set_anchors_preset(Control.PRESET_BOTTOM_LEFT)
	overview.offset_left = 14
	overview.offset_right = 329
	overview.offset_top = -525
	overview.offset_bottom = -301
	var map_col = VBoxContainer.new()
	overview.add_child(map_col)
	map_col.add_child(label("TAP TO FOCUS / TACTICAL MAP", 12, GOLD, true))
	var map = TacticalMinimap.new()
	map.battle = battle
	map.field = field
	map.custom_minimum_size = Vector2(290, 175)
	map_col.add_child(map)
	overview.visible = false
	var deck = panel(root, Rect2(14, 0, 1252, 198), Color("14241c"), 10)
	deck.set_anchors_preset(Control.PRESET_BOTTOM_WIDE)
	deck.offset_left = 14
	deck.offset_right = -14
	deck.offset_top = -212
	deck.offset_bottom = -14
	var deck_row = HBoxContainer.new()
	deck_row.add_theme_constant_override("separation", 16)
	deck.add_child(deck_row)
	var roster_col = VBoxContainer.new()
	roster_col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	deck_row.add_child(roster_col)
	var header = HBoxContainer.new()
	roster_col.add_child(header)
	header.add_child(label("YOUR SECTIONS", 12, MUTED, true))
	spacer(header)
	_multi_button = button("MULTI / OFF", func():
		battle.multi_select = not battle.multi_select
		refresh(), Vector2(135, 52))
	header.add_child(_multi_button)
	header.add_child(button("SELECT ALL", func(): battle.select_all(), Vector2(128, 52)))
	var scroll = ScrollContainer.new()
	scroll.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	roster_col.add_child(scroll)
	roster = HBoxContainer.new()
	roster.add_theme_constant_override("separation", 8)
	scroll.add_child(roster)
	var orders = VBoxContainer.new()
	orders.custom_minimum_size.x = 356
	orders.add_theme_constant_override("separation", 8)
	deck_row.add_child(orders)
	selection_label = label("SELECT A SECTION", 14, CREAM, true)
	orders.add_child(selection_label)
	status_label = label("Tap a card. Then tap the front.", 12, MUTED)
	orders.add_child(status_label)
	var primary = HBoxContainer.new()
	primary.add_theme_constant_override("separation", 6)
	orders.add_child(primary)
	primary.add_child(button("RETREAT", func(): battle.retreat_selected(), Vector2(110, 64)))
	primary.add_child(button("HOLD", func(): battle.hold_selected(), Vector2(80, 64)))
	ability_button = button("ABILITY", _toggle_ability, Vector2(150, 64), true)
	ability_button.add_theme_font_size_override("font_size", 13)
	primary.add_child(ability_button)
	var secondary = HBoxContainer.new()
	secondary.add_theme_constant_override("separation", 6)
	orders.add_child(secondary)
	secondary.add_child(button("REINFORCE AT HQ", func(): battle.reinforce(), Vector2(174, 54)))
	_smart_button = button("SMART MOVE / ON", func():
		field.auto_engage = not field.auto_engage
		refresh(), Vector2(174, 54))
	secondary.add_child(_smart_button)
	for item in secondary.get_children(): item.add_theme_font_size_override("font_size", 12)
	hint_panel = panel(root, Rect2(0, 0, 600, 42), Color(0.07, 0.13, 0.1, 0.88), 9)
	hint_panel.set_anchors_preset(Control.PRESET_BOTTOM_LEFT)
	hint_panel.offset_left = 205
	hint_panel.offset_right = 805
	hint_panel.offset_top = -271
	hint_panel.offset_bottom = -229
	hint_label = label("Tap to command / Drag to pan / Pinch to zoom", 12, MUTED)
	hint_panel.add_child(hint_label)
	toast_panel = panel(root, Rect2(0, 0, 820, 54), Color(0.06, 0.12, 0.085, 0.98), 12)
	toast_panel.set_anchors_preset(Control.PRESET_CENTER_TOP)
	toast_panel.offset_left = -410
	toast_panel.offset_right = 410
	toast_panel.offset_top = 174
	toast_panel.offset_bottom = 228
	toast_label = label("", 15)
	toast_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	toast_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	toast_panel.add_child(toast_label)
	toast_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	toast_panel.visible = false

func refresh() -> void:
	super.refresh()
	if not is_instance_valid(roster): return
	if is_instance_valid(_multi_button): _multi_button.text = "MULTI / " + ("ON" if battle.multi_select else "OFF")
	if is_instance_valid(_smart_button): _smart_button.text = "SMART MOVE / " + ("ON" if field.auto_engage else "OFF")
	objective_label.text = "Hold three sectors."
	if not battle.selected.is_empty():
		var squad = battle.get_squad(battle.selected[0])
		if squad:
			ability_button.text = CombatSquad.ABILITIES[squad.kind] if squad.ability_cd <= 0 else "%ds / COOLDOWN" % int(ceil(squad.ability_cd))
			if field.ability_mode: ability_button.text = "CANCEL"
			status_label.text = "%s / HP %d%% / %s" % [squad.status(), int(squad.hp / squad.max_hp * 100), "COVER" if squad.cover > 0 else "OPEN"]

func _rebuild_roster() -> void:
	for child in roster.get_children():
		roster.remove_child(child)
		child.queue_free()
	cards.clear()
	for squad in battle.living(0):
		var b = button("", func():
			battle.select_squad(squad.id, battle.multi_select)
			if not battle.multi_select: field.focus(squad.pos), Vector2(144, 112))
		roster.add_child(b)
		var content = VBoxContainer.new()
		content.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
		content.offset_left = 10
		content.offset_right = -10
		content.offset_top = 8
		content.offset_bottom = -8
		content.mouse_filter = Control.MOUSE_FILTER_IGNORE
		content.add_theme_constant_override("separation", 3)
		b.add_child(content)
		var heading = HBoxContainer.new()
		heading.mouse_filter = Control.MOUSE_FILTER_IGNORE
		content.add_child(heading)
		heading.add_child(icon(squad.kind, Vector2(34, 34), TEAL))
		heading.add_child(label(squad.title, 13, CREAM, true))
		content.add_child(label(squad.data().short, 11, MUTED, true))
		var health = ProgressBar.new()
		health.custom_minimum_size.y = 7
		health.show_percentage = false
		health.mouse_filter = Control.MOUSE_FILTER_IGNORE
		health.add_theme_stylebox_override("background", box(Color("0f2016"), Color("0f2016"), 2, 0))
		health.add_theme_stylebox_override("fill", box(TEAL, TEAL, 2, 0))
		content.add_child(health)
		var state = label("", 12, MUTED, true)
		content.add_child(state)
		cards[squad.id] = {"button": b, "health": health, "status": state}

func _toggle_ability() -> void:
	if battle.selected.is_empty():
		toast("Select a section first.")
		return
	field.ability_mode = not field.ability_mode
	var squad = battle.get_squad(battle.selected[0])
	toast("%s / Tap a target inside the gold ring." % CombatSquad.ABILITIES[squad.kind])
	refresh()

func show_recruit() -> void:
	if battle.finished: return
	var content = modal("CALL REINFORCEMENTS", "HQ / %d OF 8 SECTIONS / TACTICAL PAUSE" % battle.living(0).size(), Vector2(1080, 700))
	_screen = "recruit"
	var scroll = ScrollContainer.new()
	scroll.custom_minimum_size = Vector2(1020, 470)
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	content.add_child(scroll)
	var grid = GridContainer.new()
	grid.columns = 3
	grid.add_theme_constant_override("h_separation", 12)
	grid.add_theme_constant_override("v_separation", 12)
	scroll.add_child(grid)
	for kind in CombatSquad.TYPES:
		var data = CombatSquad.TYPES[kind]
		var cell = PanelContainer.new()
		cell.custom_minimum_size = Vector2(326, 210)
		cell.add_theme_stylebox_override("panel", box(Color("22392a"), EDGE, 6, 14))
		grid.add_child(cell)
		var v = VBoxContainer.new()
		cell.add_child(v)
		var heading = HBoxContainer.new()
		v.add_child(heading)
		heading.add_child(icon(kind, Vector2(42, 42), TEAL))
		heading.add_child(label(data.short, 15, CREAM, true))
		var copy = label(data.description, 14, MUTED)
		copy.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		v.add_child(copy)
		spacer(v, true)
		var unlocked = battle.allowed_recruits.is_empty() or kind in battle.allowed_recruits
		var b = button(cost_string(data.cost) if unlocked else "RESEARCH ON CAMPAIGN MAP", func():
			if battle.recruit(kind): close_popup(), Vector2(0, 58), true)
		b.add_theme_font_size_override("font_size", 12)
		b.disabled = not unlocked or not battle.economy.can_pay(data.cost) or battle.living(0).size() >= 8 or not battle.recruitment_enabled
		v.add_child(b)
	content.add_child(button("RETURN TO BATTLE", close_popup, Vector2(0, 60)))

func show_pause() -> void:
	if battle.finished: return
	var body = modal("TACTICAL PAUSE", "THE FRONT WAITS FOR YOUR COMMAND", Vector2(760, 660))
	_screen = "pause"
	body.add_child(button("RESUME OPERATION", close_popup, Vector2(0, 74), true))
	body.add_child(button("FIELD MANUAL", show_guide, Vector2(0, 60)))
	body.add_child(button("BATTERY & DISPLAY", show_battery_settings, Vector2(0, 60)))
	body.add_child(button("SOUND / " + ("ON" if sound_enabled else "OFF"), func():
		sound_enabled = not sound_enabled
		audio_changed.emit(sound_enabled)
		show_pause(), Vector2(0, 60)))
	if campaign_mode: body.add_child(button("WITHDRAW FROM BATTLE", _withdraw_confirmation, Vector2(0, 60)))
	body.add_child(button("SAVE & MAIN MENU", func(): menu_requested.emit(), Vector2(0, 60)))
	body.add_child(label("Campaign actions save immediately. Battle progress saves\nevery 20 seconds and when the app enters the background.", 15, MUTED))

func show_battery_settings() -> void:
	var body = modal("BATTERY & DISPLAY", "CHANGES APPLY IMMEDIATELY", Vector2(800, 600))
	_screen = "battery"
	body.add_child(button("FRAME RATE / %d FPS" % preferences.fps, func():
		preferences.fps = 30 if preferences.fps == 60 else 60
		preferences.save()
		preference_changed.emit()
		show_battery_settings(), Vector2(0, 72)))
	body.add_child(button("EFFECTS / " + ("FULL" if preferences.quality == 1 else "REDUCED"), func():
		preferences.quality = 1 - preferences.quality
		preferences.save()
		preference_changed.emit()
		show_battery_settings(), Vector2(0, 72)))
	body.add_child(button("HAPTICS / " + ("ON" if preferences.haptics else "OFF"), func():
		preferences.haptics = not preferences.haptics
		preferences.save()
		show_battery_settings(), Vector2(0, 72)))
	body.add_child(label("30 FPS and reduced effects favour battery life.\nReduced effects trim vegetation, tracers and water animation.", 18, MUTED))
	body.add_child(button("RETURN TO BATTLE", close_popup, Vector2(0, 64), true))

func _withdraw_confirmation() -> void:
	var previous = _previous_pause
	var body = modal("WITHDRAW THE ARMY?", "THE OPPOSITION WILL WIN THIS BATTLE", Vector2(800, 470))
	_previous_pause = previous
	_screen = "withdraw"
	body.add_child(label("Surviving sections keep their health and experience.\nAn attacking army returns to its origin. A defending army\nretreats to an empty allied neighbour, if one is available.", 19, MUTED))
	body.add_child(button("CONFIRM WITHDRAWAL", func():
		_screen = ""
		close_popup()
		battle.force_finish(1), Vector2(0, 76)))
	body.add_child(button("KEEP FIGHTING", close_popup, Vector2(0, 60), true))

func show_results(result_winner: int) -> void:
	if not campaign_mode:
		super.show_results(result_winner)
		return
	var body = modal("PROVINCE SECURED" if result_winner == 0 else "THE LINE BROKE", "CAMPAIGN BATTLE / " + battle.campaign_context.get("name", "MERIDIAN"), Vector2(860, 620))
	_screen = "results"
	body.get_child(0).get_child(body.get_child(0).get_child_count() - 1).visible = false
	body.add_child(label("Your surviving veterans will return to the strategic map.", 22, TEAL if result_winner == 0 else RED))
	body.add_child(label("SECTIONS SURVIVING / %d\nENEMY SECTIONS LOST / %d\nSECTORS CAPTURED / %d\nBATTLE TIME / %02d:%02d" % [battle.living(0).size(), battle.kills[0], battle.captures, int(battle.elapsed) / 60, int(battle.elapsed) % 60], 21, MUTED, true))
	spacer(body, true)
	body.add_child(button("RETURN TO CAMPAIGN", func(): campaign_return_requested.emit(), Vector2(0, 82), true))

func back() -> void:
	if _screen == "results" or _screen == "briefing": return
	if overlay: close_popup()
	else: show_pause()
