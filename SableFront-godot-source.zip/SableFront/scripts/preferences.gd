class_name FieldPreferences
extends RefCounted

var sound: bool = true
var haptics: bool = true
var quality: int = 1
var fps: int = 60
var large_controls: bool = true

func _init() -> void:
	fps = 30 if OS.has_feature("mobile") else 60
	var config = ConfigFile.new()
	if config.load("user://preferences.cfg") == OK:
		sound = bool(config.get_value("game", "sound", true))
		haptics = bool(config.get_value("game", "haptics", true))
		quality = clampi(int(config.get_value("game", "quality", 1)), 0, 1)
		fps = 30 if int(config.get_value("game", "fps", fps)) == 30 else 60
		large_controls = bool(config.get_value("game", "large_controls", true))

func apply(window: Window) -> void:
	Engine.max_fps = fps
	window.content_scale_size = Vector2i(1280, 800) if large_controls else Vector2i(1440, 900)
	AudioServer.set_bus_mute(0, not sound)

func save() -> void:
	var config = ConfigFile.new()
	for key in ["sound", "haptics", "quality", "fps", "large_controls"]: config.set_value("game", key, get(key))
	config.save("user://preferences.cfg")

func tap() -> void:
	if haptics and OS.has_feature("mobile"): Input.vibrate_handheld(18)

static func apply_safe_area(control: Control) -> void:
	if not OS.has_feature("mobile"): return
	var window = control.get_window()
	var safe = DisplayServer.get_display_safe_area()
	if safe.size.x <= 0 or safe.size.y <= 0 or window.size.x <= 0 or window.size.y <= 0: return
	var logical = control.get_viewport().get_visible_rect().size
	var scale = logical / Vector2(window.size)
	var safe_position = Vector2(safe.position - window.position) * scale
	var safe_end = Vector2(safe.end - window.position) * scale
	control.offset_left = maxf(0, safe_position.x)
	control.offset_top = maxf(0, safe_position.y)
	control.offset_right = minf(0, safe_end.x - logical.x)
	control.offset_bottom = minf(0, safe_end.y - logical.y)
