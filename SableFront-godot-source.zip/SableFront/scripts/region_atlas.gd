class_name RegionAtlas
extends Control

signal province_tapped(id: int)
var campaign: TheaterCampaign
var polygons: Array[PackedVector2Array] = []
var decorative: bool = false
var selected_region: int = 10
var selected_army: int = 0
var clock: float = 0
var zoom: float = 1.0
var pan = Vector2.ZERO
var _start = Vector2.ZERO
var _last = Vector2.ZERO
var _distance: float = 0
var _pressed: bool = false
var _touches: Dictionary = {}
var _pinch: float = 0
var _pinch_zoom: float = 1
var _pinched: bool = false
var font = preload("res://assets/fonts/FieldSans-Semibold.ttf")
var mono = preload("res://assets/fonts/FieldMono.ttf")
const MAP_SIZE = Vector2(1700, 1100)
const ALLIED = Color("7ac8b8")
const HOSTILE = Color("dc8c73")
const GOLD = Color("e6c185")

func _ready() -> void:
	clip_contents = true
	mouse_filter = Control.MOUSE_FILTER_IGNORE if decorative else Control.MOUSE_FILTER_STOP
	_generate_regions()
	resized.connect(queue_redraw)
	queue_redraw()

func _process(delta: float) -> void:
	clock += delta
	if fmod(clock, 0.1) < delta: queue_redraw()

func scale_value() -> float:
	return minf(size.x / MAP_SIZE.x, size.y / MAP_SIZE.y) * zoom

func origin() -> Vector2:
	return (size - MAP_SIZE * scale_value()) / 2.0 + pan

func map_to_screen(at: Vector2) -> Vector2:
	return origin() + at * scale_value()

func screen_to_map(at: Vector2) -> Vector2:
	return (at - origin()) / maxf(0.01, scale_value())

func _generate_regions() -> void:
	polygons.clear()
	for i in range(15):
		var poly = PackedVector2Array([Vector2(90, 95), Vector2(1460, 80), Vector2(1620, 275), Vector2(1560, 930), Vector2(1330, 1030), Vector2(280, 1000), Vector2(110, 850), Vector2(75, 410)])
		var site = TheaterCampaign.position_of(i)
		for j in range(15):
			if i == j: continue
			var other = TheaterCampaign.position_of(j)
			poly = _clip_halfplane(poly, (site + other) * 0.5, other - site)
		polygons.append(poly)

func _clip_halfplane(poly: PackedVector2Array, center: Vector2, normal: Vector2) -> PackedVector2Array:
	var result = PackedVector2Array()
	if poly.is_empty(): return result
	for i in range(poly.size()):
		var a = poly[i]
		var b = poly[(i + 1) % poly.size()]
		var da = (a - center).dot(normal)
		var db = (b - center).dot(normal)
		if da <= 0: result.append(a)
		if (da <= 0) != (db <= 0): result.append(a.lerp(b, da / (da - db)))
	return result

func _draw() -> void:
	if campaign == null: return
	draw_rect(Rect2(Vector2.ZERO, size), Color("152b2b"))
	var scalar = scale_value()
	draw_set_transform(origin(), 0, Vector2.ONE * scalar)
	var rng = RandomNumberGenerator.new()
	rng.seed = 818
	# Fine ocean chart, coastline shadows and province topography.
	for y in range(0, 1100, 80): draw_line(Vector2(0, y), Vector2(1700, y), Color(0.55, 0.72, 0.63, 0.055), 1)
	for x in range(0, 1700, 80): draw_line(Vector2(x, 0), Vector2(x, 1100), Color(0.55, 0.72, 0.63, 0.055), 1)
	for i in range(polygons.size()):
		var region = campaign.regions[i]
		var color = {"forest": Color("445a42"), "farmland": Color("7b8060"), "canal": Color("6e7a61"), "ridge": Color("827a65"), "city": Color("737464")}[region.biome]
		var tint = ALLIED if region.owner == 0 else (HOSTILE if region.owner == 1 else GOLD)
		color = color.lerp(tint, 0.1)
		var polygon = polygons[i]
		var shadow = PackedVector2Array()
		for point in polygon: shadow.append(point + Vector2(9, 12))
		draw_colored_polygon(shadow, Color(0.015, 0.05, 0.04, 0.8))
		draw_colored_polygon(polygon, color)
		for n in range(18):
			var site = TheaterCampaign.position_of(i)
			var p = site + Vector2(rng.randf_range(-170, 170), rng.randf_range(-145, 145))
			if not Geometry2D.is_point_in_polygon(p, polygon): continue
			if region.biome == "forest":
				draw_circle(p + Vector2(3, 5), 15, Color(0.08, 0.18, 0.1, 0.27))
				draw_circle(p, 13, Color("38533b"))
				draw_circle(p - Vector2(2, 3), 8, Color("59734b"))
			elif region.biome == "ridge":
				draw_colored_polygon(PackedVector2Array([p + Vector2(-22, 13), p + Vector2(0, -23), p + Vector2(26, 13)]), Color("696d5a"))
				draw_colored_polygon(PackedVector2Array([p + Vector2(0, -23), p + Vector2(26, 13), p + Vector2(4, 6)]), Color("96917b"))
			elif region.biome == "farmland":
				for row in range(4): draw_line(p + Vector2(-17, row * 4), p + Vector2(18, row * 4), Color(0.76, 0.72, 0.45, 0.24), 2)
			elif region.biome == "city":
				draw_rect(Rect2(p + Vector2(3, 4), Vector2(17, 12)), Color(0.1, 0.16, 0.12, 0.4))
				draw_rect(Rect2(p, Vector2(17, 12)), Color("a09c80"))
		var border = polygon.duplicate()
		border.append(polygon[0])
		draw_polyline(border, Color(tint, 0.4), 2.5, true)
		if region.owner == 0 and not region.connected:
			draw_polyline(border, Color("dfaa69"), 4, true)
	# A canal links the industrial north and the southern docks.
	var canal = PackedVector2Array([Vector2(1050, 80), Vector2(980, 260), Vector2(970, 430), Vector2(865, 550), Vector2(810, 730), Vector2(670, 850), Vector2(600, 1010)])
	draw_polyline(canal, Color("a6a28a"), 25, true)
	draw_polyline(canal, Color("3b6268"), 17, true)
	draw_polyline(canal, Color(0.58, 0.72, 0.7, 0.3), 4, true)
	for i in range(15):
		for j in TheaterCampaign.neighbours(i):
			if j <= i: continue
			var color = Color(0.85, 0.79, 0.57, 0.2)
			if campaign.regions[i].owner == 0 and campaign.regions[j].owner == 0: color = Color(ALLIED, 0.4)
			_dashed(TheaterCampaign.position_of(i), TheaterCampaign.position_of(j), color, 3)
	var active = campaign.army(selected_army)
	if not active.is_empty() and active.region != selected_region:
		var path = campaign.route(active.region, selected_region)
		for i in range(path.size() - 1): _dashed(TheaterCampaign.position_of(path[i]), TheaterCampaign.position_of(path[i + 1]), GOLD, 5)
	for i in range(15):
		var region = campaign.regions[i]
		var p = TheaterCampaign.position_of(i)
		var tint = ALLIED if region.owner == 0 else (HOSTILE if region.owner == 1 else GOLD)
		if i == selected_region:
			draw_circle(p, 49 + sin(clock * 2.5) * 2, Color(GOLD, 0.12))
			draw_arc(p, 50, 0, TAU, 48, GOLD, 3, true)
		draw_rect(Rect2(p + Vector2(-24, -24), Vector2(48, 48)), Color("233b2f"))
		draw_rect(Rect2(p + Vector2(-24, -24), Vector2(48, 48)), tint, false, 2)
		if i in TheaterCampaign.CAPITALS:
			_star(p, 16, tint)
		else:
			draw_rect(Rect2(p + Vector2(-10, -10), Vector2(20, 20)), tint)
			if region.fort > 0: draw_rect(Rect2(p + Vector2(-16, -16), Vector2(32, 32)), tint, false, 2)
		var width = font.get_string_size(region.name, HORIZONTAL_ALIGNMENT_LEFT, -1, 22).x
		draw_rect(Rect2(p + Vector2(-width / 2 - 9, 36), Vector2(width + 18, 34)), Color(0.065, 0.12, 0.095, 0.88))
		draw_string(font, p + Vector2(-width / 2, 61), region.name, HORIZONTAL_ALIGNMENT_LEFT, -1, 22, Color("e4dfc3"))
		for marker in range(region.garrison): draw_circle(p + Vector2((marker - (region.garrison - 1) / 2.0) * 11, 83), 3.5, Color(tint, 0.7))
	for entry in campaign.armies:
		var p = TheaterCampaign.position_of(entry.region) + Vector2(47, -62)
		var tint = ALLIED if entry.team == 0 else HOSTILE
		draw_line(p + Vector2(-15, 0), p + Vector2(-15, 65), Color("2a352b"), 5, true)
		draw_colored_polygon(PackedVector2Array([p + Vector2(-15, -12), p + Vector2(47, -12), p + Vector2(47, 20), p + Vector2(-15, 34)]), Color("21352b"))
		draw_colored_polygon(PackedVector2Array([p + Vector2(-15, -12), p + Vector2(47, -12), p + Vector2(47, -3), p + Vector2(-15, 11)]), tint)
		draw_string(mono, p + Vector2(-4, 22), "%02d" % entry.roster.size(), HORIZONTAL_ALIGNMENT_LEFT, -1, 24, tint)
		if entry.id == selected_army:
			draw_arc(p + Vector2(14, 8), 45, 0, TAU, 40, GOLD, 2.5, true)
	draw_string(mono, Vector2(210, 1064), "MERIDIAN THEATER / STRATEGIC ATLAS", HORIZONTAL_ALIGNMENT_LEFT, -1, 18, Color("80968b"))
	draw_string(mono, Vector2(1350, 35), "N", HORIZONTAL_ALIGNMENT_CENTER, 60, 25, GOLD)
	draw_line(Vector2(1380, 45), Vector2(1380, 90), GOLD, 2)
	draw_set_transform(Vector2.ZERO)

func _dashed(a: Vector2, b: Vector2, color: Color, width: float) -> void:
	var length = a.distance_to(b)
	var direction = a.direction_to(b)
	for d in range(0, int(length), 20): draw_line(a + direction * d, a + direction * minf(d + 10, length), color, width, true)

func _star(at: Vector2, radius: float, tint: Color) -> void:
	var points = PackedVector2Array()
	for i in range(10): points.append(at + Vector2.from_angle(-PI / 2 + i * PI / 5) * (radius if i % 2 == 0 else radius * 0.45))
	draw_colored_polygon(points, tint)

func _gui_input(event: InputEvent) -> void:
	if decorative: return
	if event is InputEventMouse and event.device == InputEvent.DEVICE_ID_EMULATION: return
	if event is InputEventScreenTouch:
		if event.pressed:
			_touches[event.index] = event.position
			if _touches.size() == 1: _begin(event.position)
			else:
				_pinched = true
				_pinch = _touches.values()[0].distance_to(_touches.values()[1])
				_pinch_zoom = zoom
		else:
			_touches.erase(event.index)
			if _touches.is_empty(): _end(event.position)
		accept_event()
	elif event is InputEventScreenDrag:
		_touches[event.index] = event.position
		if _touches.size() >= 2 and _pinch > 0:
			zoom = clampf(_pinch_zoom * _touches.values()[0].distance_to(_touches.values()[1]) / _pinch, 1, 2.2)
			_bound_pan()
		elif not _pinched: _drag(event.position)
		accept_event()
	elif event is InputEventMouseButton:
		if event.button_index == MOUSE_BUTTON_LEFT:
			if event.pressed: _begin(event.position)
			else: _end(event.position)
		elif event.pressed and event.button_index in [MOUSE_BUTTON_WHEEL_UP, MOUSE_BUTTON_WHEEL_DOWN]:
			zoom = clampf(zoom * (1.12 if event.button_index == MOUSE_BUTTON_WHEEL_UP else 0.89), 1, 2.2)
			_bound_pan()
		accept_event()
	elif event is InputEventMouseMotion and _pressed: _drag(event.position)

func _begin(at: Vector2) -> void:
	_start = at
	_last = at
	_distance = 0
	_pressed = true
	_pinched = false

func _drag(at: Vector2) -> void:
	_distance = maxf(_distance, at.distance_to(_start))
	if _distance > 12:
		pan += at - _last
		_bound_pan()
	_last = at

func _bound_pan() -> void:
	var extents = (MAP_SIZE * scale_value() - size).max(Vector2.ZERO) / 2.0
	pan = pan.clamp(-extents, extents)
	queue_redraw()

func _end(at: Vector2) -> void:
	if _pressed and _distance < 12 and not _pinched:
		var point = screen_to_map(at)
		for i in range(polygons.size()):
			if Geometry2D.is_point_in_polygon(point, polygons[i]):
				province_tapped.emit(i)
				break
	_pressed = false
