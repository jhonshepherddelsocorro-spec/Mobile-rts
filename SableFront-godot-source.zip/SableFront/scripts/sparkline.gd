class_name MarketSparkline
extends Control

var values: Array = []
var tint = Color("91c8ad")

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE

func _draw() -> void:
	if values.size() < 2: return
	var low = float(values.min()) * 0.8
	var high = float(values.max()) * 1.1
	var points = PackedVector2Array()
	for i in range(values.size()):
		points.append(Vector2(float(i) / (values.size() - 1) * size.x, size.y - 5 - (values[i] - low) / maxf(1, high - low) * (size.y - 10)))
	for y in [0.25, 0.5, 0.75]:
		draw_line(Vector2(0, size.y * y), Vector2(size.x, size.y * y), Color(1, 1, 1, 0.04), 1)
	var polygon = points.duplicate()
	polygon.append(Vector2(size.x, size.y))
	polygon.append(Vector2(0, size.y))
	draw_colored_polygon(polygon, Color(tint, 0.08))
	draw_polyline(points, tint, 2, true)
	draw_circle(points[points.size() - 1], 3, tint)
