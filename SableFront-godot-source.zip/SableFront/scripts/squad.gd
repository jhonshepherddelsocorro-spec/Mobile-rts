class_name CombatSquad
extends RefCounted

const TYPES = {
	"rifle": {"name": "Rifle section", "short": "RIFLES", "icon": "rifle", "men": 5, "hp": 260.0, "speed": 76.0, "range": 260.0, "damage": 12.0, "rate": 1.1, "cost": {"credits": 180, "supplies": 25}, "description": "Versatile infantry. Captures ground and holds the line."},
	"assault": {"name": "Assault section", "short": "ASSAULT", "icon": "bolt", "men": 4, "hp": 280.0, "speed": 88.0, "range": 165.0, "damage": 21.0, "rate": 0.8, "cost": {"credits": 240, "supplies": 30, "ammo": 15}, "description": "Fast close-range specialists. Flank a pinned enemy."},
	"support": {"name": "MG section", "short": "SUPPORT", "icon": "mg", "men": 3, "hp": 230.0, "speed": 58.0, "range": 340.0, "damage": 9.0, "rate": 0.5, "cost": {"credits": 260, "supplies": 25, "ammo": 25}, "description": "Long-range machine gun. Suppresses infantry quickly."},
	"engineer": {"name": "Engineer section", "short": "ENGINEERS", "icon": "wrench", "men": 4, "hp": 240.0, "speed": 76.0, "range": 210.0, "damage": 10.0, "rate": 1.2, "cost": {"credits": 200, "supplies": 20, "fuel": 10}, "description": "Builds sandbag cover and captures sectors faster."},
	"armor": {"name": "Scout carrier", "short": "CARRIER", "icon": "armor", "men": 1, "hp": 520.0, "speed": 100.0, "range": 300.0, "damage": 28.0, "rate": 1.8, "cost": {"credits": 380, "supplies": 25, "fuel": 35}, "description": "Mobile armored fire support. Consumes fuel while moving."}
}

var id: int
var team: int
var kind: String
var title: String
var pos: Vector2
var destination: Vector2
var hp: float
var max_hp: float
var suppression: float = 0.0
var cooldown: float = 0.0
var veterancy: float = 0.0
var facing: float = -0.4
var order: String = "hold"
var target_id: int = -1
var cover: float = 0.0
var moving: bool = false
var alive: bool = true
var shot_flash: float = 0.0
var ability_cd: float = 0.0
var deployed: bool = false
var route: Array[Vector2] = []
var kills: int = 0

func _init(unit_id: int = 0, unit_team: int = 0, unit_kind: String = "rifle", position: Vector2 = Vector2.ZERO) -> void:
	id = unit_id
	team = unit_team
	kind = unit_kind
	pos = position
	destination = position
	max_hp = TYPES[kind].hp
	hp = max_hp
	title = ["ALPHA", "BRAVO", "CHARLIE", "DELTA", "ECHO", "FOXTROT", "GOLF", "HOTEL", "INDIA", "JULIET", "KILO", "LIMA"][id % 12]
	cooldown = float(id % 5) * 0.17

func data() -> Dictionary:
	return TYPES[kind]

func members() -> int:
	return maxi(1, int(ceil(hp / max_hp * data().men))) if alive else 0

func rank() -> int:
	return mini(3, int(veterancy / 130.0))

func status() -> String:
	if order == "retreat": return "RETREATING"
	if suppression > 72: return "PINNED"
	if moving: return "ADVANCING"
	if target_id >= 0: return "ENGAGING"
	if cover > 0.0: return "IN COVER"
	return "READY"
