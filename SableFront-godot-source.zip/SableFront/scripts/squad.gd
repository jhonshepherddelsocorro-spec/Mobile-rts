class_name CombatSquad
extends RefCounted

const TYPES = {
	"rifle": {"name": "Rifle section", "short": "RIFLES", "icon": "rifle", "men": 5, "hp": 260.0, "speed": 76.0, "range": 260.0, "damage": 12.0, "rate": 1.1, "cost": {"credits": 180, "supplies": 25}, "description": "Versatile infantry. Captures ground and holds the line."},
	"assault": {"name": "Assault section", "short": "ASSAULT", "icon": "bolt", "men": 4, "hp": 280.0, "speed": 88.0, "range": 165.0, "damage": 21.0, "rate": 0.8, "cost": {"credits": 240, "supplies": 30, "ammo": 15}, "description": "Fast close-range specialists. Flank a pinned enemy."},
	"support": {"name": "MG section", "short": "SUPPORT", "icon": "mg", "men": 3, "hp": 230.0, "speed": 58.0, "range": 340.0, "damage": 9.0, "rate": 0.5, "cost": {"credits": 260, "supplies": 25, "ammo": 25}, "description": "Long-range machine gun. Suppresses infantry quickly."},
	"engineer": {"name": "Engineer section", "short": "ENGINEERS", "icon": "wrench", "men": 4, "hp": 240.0, "speed": 76.0, "range": 210.0, "damage": 10.0, "rate": 1.2, "cost": {"credits": 200, "supplies": 20, "fuel": 10}, "description": "Builds sandbag cover and captures sectors faster."},
	"armor": {"name": "Scout carrier", "short": "CARRIER", "icon": "armor", "men": 1, "hp": 520.0, "speed": 100.0, "range": 300.0, "damage": 28.0, "rate": 1.8, "vehicle": true, "armor": 0.25, "cost": {"credits": 380, "supplies": 25, "fuel": 35}, "description": "Fast armored fire support. Consumes fuel; cannot capture."},
	"medic": {"name": "Field medics", "short": "MEDICS", "icon": "medic", "men": 3, "hp": 210.0, "speed": 81.0, "range": 165.0, "damage": 6.0, "rate": 1.3, "cost": {"credits": 210, "supplies": 35}, "description": "Heals nearby infantry out of combat. Ability: emergency aid."},
	"recon": {"name": "Pathfinders", "short": "RECON", "icon": "recon", "men": 3, "hp": 195.0, "speed": 105.0, "range": 280.0, "damage": 10.0, "rate": 1.0, "vision": 640.0, "capture": 1.25, "tech": "signals", "cost": {"credits": 220, "supplies": 20, "ammo": 10}, "description": "Extended vision and fast capture. Ability: reconnaissance flare."},
	"sniper": {"name": "Marksman team", "short": "SNIPER", "icon": "sniper", "men": 2, "hp": 155.0, "speed": 72.0, "range": 460.0, "damage": 42.0, "rate": 3.3, "vision": 530.0, "tech": "signals", "cost": {"credits": 320, "supplies": 20, "ammo": 30}, "description": "Long-range infantry hunter. Ability: a powerful aimed shot."},
	"mortar": {"name": "Mortar battery", "short": "MORTAR", "icon": "mortar", "men": 3, "hp": 200.0, "speed": 48.0, "range": 620.0, "min_range": 130.0, "damage": 27.0, "rate": 4.5, "splash": 85.0, "setup": 2.0, "indirect": true, "tech": "ordnance", "cost": {"credits": 340, "supplies": 25, "ammo": 40}, "description": "Indirect area fire; deploys before firing. Ability: heavy barrage."},
	"atgun": {"name": "Anti-tank gun", "short": "AT GUN", "icon": "atgun", "men": 3, "hp": 270.0, "speed": 42.0, "range": 440.0, "damage": 22.0, "rate": 2.8, "anti_armor": 4.0, "setup": 1.4, "tech": "ordnance", "cost": {"credits": 330, "supplies": 30, "ammo": 30}, "description": "Armor-piercing support gun. Ability: overcharged AP round."},
	"tank": {"name": "Vanguard tank", "short": "TANK", "icon": "tank", "men": 1, "hp": 850.0, "speed": 63.0, "range": 360.0, "damage": 44.0, "rate": 2.8, "vehicle": true, "armor": 0.5, "anti_armor": 1.8, "splash": 38.0, "tech": "mechanized", "cost": {"credits": 620, "supplies": 45, "fuel": 65}, "description": "Heavy frontal armor and cannon splash. Flanks remain vulnerable."},
	"flame": {"name": "Flame pioneers", "short": "FLAME", "icon": "flame", "men": 4, "hp": 300.0, "speed": 73.0, "range": 125.0, "damage": 22.0, "rate": 0.9, "splash": 43.0, "ignore_cover": true, "tech": "mechanized", "cost": {"credits": 300, "supplies": 30, "fuel": 20}, "description": "Close-range assault specialists. Flame ignores cover."}
}

const ABILITIES = {"rifle": "GRENADE", "assault": "GRENADE", "support": "GRENADE", "engineer": "SANDBAGS", "armor": "SMOKE", "medic": "FIELD AID", "recon": "FLARE", "sniper": "AIMED SHOT", "mortar": "BARRAGE", "atgun": "AP ROUND", "tank": "SMOKE", "flame": "FIRE BOMB"}

var id: int
var team: int
var kind: String
var title: String
var pos: Vector2
var destination: Vector2
var hp: float
var max_hp: float
var suppression: float = 0.0
var cooldown: float = 0.0
var veterancy: float = 0.0
var facing: float = -0.4
var order: String = "hold"
var target_id: int = -1
var cover: float = 0.0
var moving: bool = false
var alive: bool = true
var shot_flash: float = 0.0
var ability_cd: float = 0.0
var deployed: bool = false
var route: Array[Vector2] = []
var kills: int = 0
var campaign_id: int = -1
var stationary: float = 0.0
var last_hit: float = -100.0
var smoke_time: float = 0.0
var ai_role: String = "advance"

func _init(unit_id: int = 0, unit_team: int = 0, unit_kind: String = "rifle", position: Vector2 = Vector2.ZERO) -> void:
	id = unit_id
	team = unit_team
	kind = unit_kind
	pos = position
	destination = position
	max_hp = TYPES[kind].hp
	hp = max_hp
	title = ["ALPHA", "BRAVO", "CHARLIE", "DELTA", "ECHO", "FOXTROT", "GOLF", "HOTEL", "INDIA", "JULIET", "KILO", "LIMA"][id % 12]
	cooldown = float(id % 5) * 0.17

func data() -> Dictionary:
	return TYPES[kind]

func members() -> int:
	return maxi(1, int(ceil(hp / max_hp * data().men))) if alive else 0

func rank() -> int:
	return mini(3, int(veterancy / 130.0))

func vehicle() -> bool:
	return data().get("vehicle", false)

func can_capture() -> bool:
	return not vehicle() and kind not in ["mortar", "atgun"]

func status() -> String:
	if order == "retreat": return "RETREATING"
	if suppression > 72: return "PINNED"
	if moving: return "ADVANCING"
	if target_id >= 0: return "ENGAGING"
	if cover > 0.0: return "IN COVER"
	return "READY"
