class_name TacticalIcon
extends Control

var kind: String = "rifle"
var color = Color("e2c18b")

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE

func _draw() -> void:
	var s = minf(size.x, size.y) / 64.0
	draw_set_transform(size / 2, 0, Vector2.ONE * s)
	match kind:
		"emblem":
			draw_colored_polygon(PackedVector2Array([Vector2(0, -29), Vector2(27, -14), Vector2(27, 12), Vector2(0, 31), Vector2(-27, 12), Vector2(-27, -14)]), color)
			draw_colored_polygon(PackedVector2Array([Vector2(0, -15), Vector2(17, -6), Vector2(0, 5), Vector2(-17, -6)]), Color("1b2a23"))
			draw_polyline(PackedVector2Array([Vector2(-17, 5), Vector2(0, 16), Vector2(17, 5)]), Color("1b2a23"), 5, true)
		"rifle":
			draw_line(Vector2(-22, 23), Vector2(19, -20), color, 5, true)
			draw_line(Vector2(-16, 20), Vector2(-5, 21), color, 8, true)
			draw_line(Vector2(-5, 0), Vector2(1, 6), color, 4, true)
			draw_line(Vector2(10, -17), Vector2(16, -11), color, 3, true)
		"bolt", "assault":
			draw_colored_polygon(PackedVector2Array([Vector2(3, -28), Vector2(-19, 4), Vector2(-3, 4), Vector2(-8, 28), Vector2(21, -8), Vector2(5, -8)]), color)
		"mg", "support":
			draw_line(Vector2(-23, -8), Vector2(26, -8), color, 6, true)
			draw_rect(Rect2(-17, -15, 27, 13), color)
			draw_line(Vector2(-1, -2), Vector2(-14, 25), color, 4, true)
			draw_line(Vector2(-1, -2), Vector2(12, 25), color, 4, true)
			draw_rect(Rect2(-24, -9, 9, 14), color)
		"wrench", "engineer":
			draw_line(Vector2(-19, 22), Vector2(12, -9), color, 9, true)
			draw_arc(Vector2(13, -10), 13, -0.2, PI * 1.7, 20, color, 7, true)
			draw_circle(Vector2(-19, 22), 7, color)
			draw_circle(Vector2(-19, 22), 2.5, Color("1b2a23"))
		"armor", "tank":
			draw_rect(Rect2(-25, -7, 50, 25), color, false, 4)
			draw_rect(Rect2(-12, -17, 25, 13), color)
			draw_line(Vector2(0, -12), Vector2(25, -27), color, 5, true)
			for x in [-16, 0, 16]: draw_circle(Vector2(x, 17), 5, color)
		"medic":
			draw_rect(Rect2(-7, -25, 14, 50), color)
			draw_rect(Rect2(-25, -7, 50, 14), color)
		"recon":
			draw_arc(Vector2.ZERO, 23, 0, TAU, 40, color, 3, true)
			draw_circle(Vector2.ZERO, 8, color)
			draw_line(Vector2(-31, 0), Vector2(-21, 0), color, 3)
			draw_line(Vector2(21, 0), Vector2(31, 0), color, 3)
		"sniper":
			draw_arc(Vector2.ZERO, 17, 0, TAU, 32, color, 3, true)
			for offset in [Vector2(1, 0), Vector2(-1, 0), Vector2(0, 1), Vector2(0, -1)]: draw_line(offset * 11, offset * 29, color, 3, true)
		"mortar":
			draw_arc(Vector2(0, 16), 22, PI, TAU, 24, color, 3, true)
			draw_line(Vector2(-10, 15), Vector2(14, -24), color, 9, true)
			draw_line(Vector2(-11, 16), Vector2(-24, 25), color, 4)
			draw_line(Vector2(-11, 16), Vector2(13, 25), color, 4)
		"atgun":
			draw_line(Vector2(-15, -5), Vector2(29, -5), color, 7, true)
			draw_rect(Rect2(-15, -16, 17, 23), color)
			draw_circle(Vector2(-13, 13), 8, color)
			draw_line(Vector2(-13, 5), Vector2(-27, 25), color, 4)
		"flame":
			draw_colored_polygon(PackedVector2Array([Vector2(-5, -29), Vector2(7, -10), Vector2(20, -17), Vector2(23, 10), Vector2(9, 27), Vector2(-10, 27), Vector2(-24, 11), Vector2(-17, -8), Vector2(-13, 7), Vector2(-6, 2)]), color)
		"supplies":
			draw_rect(Rect2(-21, -18, 42, 38), color, false, 3)
			draw_line(Vector2(0, -18), Vector2(0, 20), color, 3)
			draw_line(Vector2(-21, -7), Vector2(21, -7), color, 3)
		"ammo":
			for x in [-15, 0, 15]:
				draw_rect(Rect2(x - 4, -9, 8, 29), color)
				draw_colored_polygon(PackedVector2Array([Vector2(x - 4, -9), Vector2(x, -22), Vector2(x + 4, -9)]), color)
		"fuel":
			draw_rect(Rect2(-17, -17, 34, 40), color, false, 3)
			draw_line(Vector2(-10, -17), Vector2(-10, -25), color, 3)
			draw_line(Vector2(-10, -25), Vector2(8, -25), color, 3)
			draw_line(Vector2(8, -25), Vector2(8, -17), color, 3)
			draw_line(Vector2(-11, -8), Vector2(11, 14), color, 2)
			draw_line(Vector2(11, -8), Vector2(-11, 14), color, 2)
	draw_set_transform(Vector2.ZERO)
