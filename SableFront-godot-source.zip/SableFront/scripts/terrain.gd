class_name BattlefieldTerrain
extends Node2D

var battle: BattleSimulation
var water_flow: ColorRect
var rng = RandomNumberGenerator.new()
var grain = preload("res://assets/terrain_grain.png")
var font = preload("res://assets/fonts/FieldMono.ttf")
const INK = Color("34463b")
const GRASS = Color("75806a")
const WATER = Color("496b70")

func _ready() -> void:
	if battle != null:
		var water = ColorRect.new()
		water_flow = water
		water.size = BattleSimulation.WORLD
		water.mouse_filter = Control.MOUSE_FILTER_IGNORE
		water.z_index = 1
		var material_value = ShaderMaterial.new()
		material_value.shader = preload("res://assets/water.gdshader")
		water.material = material_value
		add_child(water)
	queue_redraw()

func _process(_delta: float) -> void:
	if water_flow: water_flow.visible = battle.map_style == "canal" and battle.quality == 1

func _draw() -> void:
	if battle == null: return
	rng.seed = battle.map_seed + 8205
	draw_rect(Rect2(Vector2.ZERO, BattleSimulation.WORLD), {"forest": Color("657856"), "ridge": Color("8c8567"), "city": Color("777d68"), "farmland": Color("868869")}.get(battle.map_style, GRASS))
	# Flat hand-illustrated terrain; deterministic and drawn only when rebuilt.
	for i in range(1100 if battle.quality == 1 else 500):
		var p = Vector2(rng.randf_range(0, 2560), rng.randf_range(0, 1792))
		var c = [Color("7d866c"), Color("6f7e64"), Color("81866c"), Color("6e7b63"), Color("858970")][i % 5]
		draw_circle(p, rng.randf_range(8, 54), Color(c, 0.36))
	for y in range(0, 1792, 160):
		for x in range(0, 2560, 160):
			draw_line(Vector2(x, y), Vector2(x + 160, y), Color(0.88, 0.9, 0.72, 0.045))
			draw_line(Vector2(x, y), Vector2(x, y + 160), Color(0.88, 0.9, 0.72, 0.045))
	# Farmland and abandoned orchard.
	field(Rect2(160, 670, 250, 260), Color("918e64"))
	field(Rect2(270, 350, 380, 170), Color("888863"))
	field(Rect2(1980, 1440, 390, 190), Color("94886a"))
	field(Rect2(770, 1420, 260, 220), Color("838765"))
	# Roads lead directly to the three navigable canal bridges.
	road([Vector2(-70, 1580), Vector2(300, 1420), Vector2(600, 1040), Vector2(970, 1020), Vector2(1510, 1030), Vector2(1940, 1330), Vector2(2600, 1510)], 64)
	road([Vector2(600, 1040), Vector2(700, 780), Vector2(1030, 540), Vector2(1500, 540), Vector2(1960, 600), Vector2(2270, 310), Vector2(2630, 200)], 48)
	road([Vector2(600, 1040), Vector2(960, 1470), Vector2(1530, 1470), Vector2(1940, 1330)], 38)
	road([Vector2(1510, 1030), Vector2(1610, 780), Vector2(1960, 600)], 42)
	# Railway embankment.
	var rail = PackedVector2Array([Vector2(810, -60), Vector2(920, 340), Vector2(1030, 540), Vector2(1100, 760), Vector2(1080, 1000), Vector2(1030, 1250), Vector2(1040, 1840)])
	draw_polyline(rail, Color("555f4f"), 27, true)
	for i in range(rail.size() - 1):
		var a = rail[i]
		var b = rail[i + 1]
		var norm = (b - a).normalized().orthogonal()
		for j in range(int(a.distance_to(b) / 15.0)):
			var p = a.lerp(b, j / maxf(1.0, a.distance_to(b) / 15.0))
			draw_line(p - norm * 15, p + norm * 15, Color("474a3d"), 4, true)
		draw_line(a - norm * 7, b - norm * 7, Color("979d89"), 2, true)
		draw_line(a + norm * 7, b + norm * 7, Color("979d89"), 2, true)
	if battle.map_style == "canal":
		# Canal banks and moving water illustrated with fine current lines.
		var left = PackedVector2Array()
		var right = PackedVector2Array()
		var center = PackedVector2Array()
		for y in range(-100, 1900, 20):
			var cx = BattleSimulation.river_x(y)
			left.append(Vector2(cx - 90, y))
			right.append(Vector2(cx + 90, y))
			center.append(Vector2(cx, y))
		var water = left.duplicate()
		var reverse = right.duplicate()
		reverse.reverse()
		water.append_array(reverse)
		draw_colored_polygon(water, WATER)
		draw_polyline(left, Color("a49b7d"), 12, true)
		draw_polyline(right, Color("a49b7d"), 12, true)
		draw_polyline(center, Color(0.38, 0.51, 0.51, 0.45), 95, true)
		for i in range(180):
			var y = rng.randf_range(0, 1800)
			var p = Vector2(BattleSimulation.river_x(y) + rng.randf_range(-65, 65), y)
			draw_line(p, p + Vector2(rng.randf_range(-4, 4), rng.randf_range(8, 28)), Color(0.76, 0.84, 0.75, 0.14), 1.2, true)
		for y in [540, 1030, 1470]:
			var x = BattleSimulation.river_x(y)
			draw_rect(Rect2(x - 112, y - 54, 234, 126), Color(0.1, 0.16, 0.14, 0.28))
			draw_rect(Rect2(x - 115, y - 47, 230, 94), Color("a59c7d"))
			for xx in range(-108, 115, 16): draw_line(Vector2(x + xx, y - 45), Vector2(x + xx, y + 45), Color("827e65"), 2)
			draw_line(Vector2(x - 118, y - 49), Vector2(x + 118, y - 49), Color("4c574b"), 7, true)
			draw_line(Vector2(x - 118, y + 49), Vector2(x + 118, y + 49), Color("4c574b"), 7, true)
			for xx in [-110, -55, 0, 55, 110]:
				draw_circle(Vector2(x + xx, y - 49), 5, Color("c2b998"))
				draw_circle(Vector2(x + xx, y + 49), 5, Color("c2b998"))
	# Farm buildings and the railway settlement.
	for i in range(battle.buildings.size()): building(battle.buildings[i], i)
	# Fuel yard tanks and rusted pipework.
	for p in [Vector2(2080, 1290), Vector2(2160, 1290), Vector2(2080, 1370)]:
		draw_circle(p + Vector2(12, 15), 35, Color(0.16, 0.2, 0.15, 0.32))
		draw_circle(p, 33, Color("555e57"))
		draw_circle(p - Vector2(2, 7), 28, Color("a09b80"))
		draw_arc(p - Vector2(2, 7), 21, 0, TAU, 28, Color("c2bda0"), 2, true)
		draw_line(p + Vector2(-28, -2), p + Vector2(28, -2), Color("7b7d68"), 3)
	draw_polyline(PackedVector2Array([Vector2(2080, 1370), Vector2(2200, 1370), Vector2(2200, 1290), Vector2(2160, 1290)]), Color("5c6453"), 9, true)
	# Sparse clusters keep troop silhouettes readable.
	for i in range((320 if battle.map_style == "forest" else 170) if battle.quality == 1 else 80):
		var p = Vector2(rng.randf_range(70, 2490), rng.randf_range(70, 1720))
		var skip = battle.water_at(p)
		for point in battle.points:
			if p.distance_to(point.pos) < 145: skip = true
		for base in BattleSimulation.BASES:
			if p.distance_to(base) < 180: skip = true
		for rect in battle.buildings:
			if rect.grow(40).has_point(p): skip = true
		if not skip and (p.x < 400 or p.y < 250 or p.x > 2300 or i % 3 == 0): tree(p, rng.randf_range(0.8, 1.35))
	for i in range(800 if battle.quality == 1 else 250):
		var p = Vector2(rng.randf_range(15, 2540), rng.randf_range(15, 1780))
		if not battle.water_at(p):
			draw_line(p, p + Vector2(2, -4), Color(0.26, 0.34, 0.23, 0.25), 1, true)
	for feature in battle.terrain_features:
		draw_circle(feature.pos, feature.radius, Color(0.24, 0.34, 0.21, 0.12))
		for i in range(32 if battle.quality == 1 else 14):
			var p: Vector2 = feature.pos + Vector2.from_angle(rng.randf() * TAU) * rng.randf_range(30, feature.radius)
			var blocked = battle.water_at(p)
			for rect in battle.buildings:
				if rect.grow(30).has_point(p): blocked = true
			if blocked: continue
			if feature.kind == "forest": tree(p, rng.randf_range(1, 1.4))
			else:
				draw_colored_polygon(PackedVector2Array([p + Vector2(-24, 14), p + Vector2(0, -18), p + Vector2(29, 14)]), Color("777a66"))
				draw_colored_polygon(PackedVector2Array([p + Vector2(0, -18), p + Vector2(29, 14), p + Vector2(2, 8)]), Color("a2a082"))
	for i in range(35):
		var p = Vector2(rng.randf_range(600, 2200), rng.randf_range(350, 1500))
		if not battle.water_at(p):
			draw_circle(p, rng.randf_range(8, 19), Color(0.22, 0.26, 0.2, 0.33))
			draw_arc(p + Vector2(-2, -3), 13, 0.2, 2.7, 12, Color(0.8, 0.77, 0.62, 0.25), 3, true)
	draw_texture_rect(grain, Rect2(Vector2.ZERO, BattleSimulation.WORLD), true, Color(0.76, 0.8, 0.66, 0.15))
	base_camp(BattleSimulation.BASES[0], Color("72bdb0"))
	base_camp(BattleSimulation.BASES[1], Color("c27c64"))
	# Subtle cartographic annotations.
	draw_string(font, Vector2(135, 220), battle.map_style.to_upper() + " / MERIDIAN DISTRICT", HORIZONTAL_ALIGNMENT_LEFT, -1, 18, Color("c0c2a3"))
	draw_string(font, Vector2(1630, 1700), "MERIDIAN / " + battle.map_style.to_upper(), HORIZONTAL_ALIGNMENT_LEFT, -1, 17, Color("a7b4a2"))
	for y in range(200, 1700, 300):
		draw_string(font, Vector2(18, y), "%02d" % (y / 100), HORIZONTAL_ALIGNMENT_LEFT, -1, 14, Color(0.82, 0.85, 0.7, 0.4))

func road(points: Array, width: float) -> void:
	var packed = PackedVector2Array(points)
	draw_polyline(packed, Color("626e59"), width + 12, true)
	draw_polyline(packed, Color("a29a7b"), width, true)
	draw_polyline(packed, Color("b2a889"), width - 12, true)
	for i in range(packed.size() - 1):
		var normal = (packed[i + 1] - packed[i]).normalized().orthogonal()
		draw_line(packed[i] + normal * 9, packed[i + 1] + normal * 9, Color(0.4, 0.39, 0.28, 0.13), 3, true)
		draw_line(packed[i] - normal * 9, packed[i + 1] - normal * 9, Color(0.4, 0.39, 0.28, 0.13), 3, true)

func field(rect: Rect2, c: Color) -> void:
	draw_rect(rect, c)
	for y in range(int(rect.position.y + 7), int(rect.end.y), 12):
		draw_line(Vector2(rect.position.x + 4, y), Vector2(rect.end.x - 4, y), Color(0.31, 0.36, 0.23, 0.22), 3)
	draw_rect(rect, Color("606c50"), false, 4)

func building(rect: Rect2, index: int) -> void:
	draw_rect(Rect2(rect.position + Vector2(14, 22), rect.size), Color(0.14, 0.19, 0.15, 0.35))
	draw_rect(Rect2(rect.position + Vector2(-4, -4), rect.size + Vector2(8, 22)), Color("555b4c"))
	draw_rect(Rect2(rect.position + Vector2(0, 10), rect.size), Color("c3b797"))
	var roof = Color("875e49") if index % 3 == 0 else Color("626e69")
	draw_rect(rect, roof)
	draw_rect(Rect2(rect.position, Vector2(rect.size.x, rect.size.y * 0.48)), roof.lightened(0.18))
	draw_line(rect.position + Vector2(0, rect.size.y * 0.48), rect.position + Vector2(rect.size.x, rect.size.y * 0.48), roof.darkened(0.3), 4)
	for x in range(int(rect.position.x + 12), int(rect.end.x - 5), 22):
		draw_line(Vector2(x, rect.position.y + 3), Vector2(x, rect.end.y - 3), Color(0.15, 0.2, 0.15, 0.16), 1)
	for x in range(int(rect.position.x + 12), int(rect.end.x - 5), 34):
		draw_rect(Rect2(x, rect.end.y + 3, 15, 9), Color("37473d"))
	draw_rect(Rect2(rect.position + Vector2(18, 10), Vector2(14, 20)), Color("414a40"))
	draw_rect(Rect2(rect.position + Vector2(18, 7), Vector2(14, 12)), Color("aaa28b"))

func tree(p: Vector2, scale_value: float) -> void:
	draw_set_transform(p, 0, Vector2.ONE * scale_value)
	draw_circle(Vector2(12, 17), 24, Color(0.12, 0.2, 0.14, 0.27))
	draw_line(Vector2(0, 4), Vector2(0, 20), Color("59523a"), 6)
	for i in range(5):
		var off = Vector2.from_angle(i * TAU / 5.0) * 13
		draw_circle(off, 17, Color("445c42"))
		draw_circle(off + Vector2(-3, -4), 12, Color("59704c"))
	draw_circle(Vector2(-4, -5), 16, Color("6a7b53"))
	draw_set_transform(Vector2.ZERO)

func base_camp(p: Vector2, c: Color) -> void:
	draw_circle(p, 140, Color(0.63, 0.61, 0.44, 0.35))
	draw_arc(p, 145, 0, TAU, 64, Color(c, 0.4), 3, true)
	for off in [Vector2(-62, -30), Vector2(45, 25)]:
		draw_rect(Rect2(p + off + Vector2(8, 14), Vector2(65, 48)), Color(0.1, 0.17, 0.12, 0.4))
		draw_rect(Rect2(p + off, Vector2(65, 48)), Color("64715b"))
		draw_colored_polygon(PackedVector2Array([p + off, p + off + Vector2(32, -20), p + off + Vector2(65, 0), p + off + Vector2(65, 30), p + off + Vector2(32, 10), p + off + Vector2(0, 30)]), Color("a3a07d"))
	draw_line(p + Vector2(20, -40), p + Vector2(20, -110), Color("d0c8a3"), 3, true)
	draw_colored_polygon(PackedVector2Array([p + Vector2(20, -110), p + Vector2(60, -101), p + Vector2(20, -88)]), c)
	draw_string(font, p + Vector2(-55, 107), "FORWARD HQ", HORIZONTAL_ALIGNMENT_LEFT, -1, 16, Color("ddd7b5"))
