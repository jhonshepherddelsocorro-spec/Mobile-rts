class_name UnitArt
extends RefCounted

const ATLAS = preload("res://assets/unit_atlas.png")
const ORDER = ["rifle", "assault", "support", "engineer", "armor", "medic", "recon", "sniper", "mortar", "atgun", "tank", "flame", "mortar_weapon", "atgun_weapon"]

static func sprite(canvas: CanvasItem, kind: String, team: int, at: Vector2, facing: float, dimensions: Vector2) -> void:
	var index = ORDER.find(kind)
	if index < 0: index = 0
	canvas.draw_set_transform(at, facing)
	canvas.draw_texture_rect_region(ATLAS, Rect2(-dimensions / 2.0, dimensions), Rect2(index * 128, team * 128, 128, 128))
	canvas.draw_set_transform(Vector2.ZERO)

static func draw_formation(canvas: CanvasItem, squad: CombatSquad, at: Vector2, time: float) -> void:
	if squad.vehicle():
		sprite(canvas, squad.kind, squad.team, at, squad.facing, Vector2(90, 90) if squad.kind == "tank" else Vector2(77, 77))
		if squad.moving:
			for side in [-1, 1]:
				canvas.draw_line(at + Vector2.from_angle(squad.facing + PI / 2) * side * 21, at + Vector2.from_angle(squad.facing + PI / 2) * side * 21 - Vector2.from_angle(squad.facing) * 32, Color(0.14, 0.2, 0.13, 0.13), 6, true)
	else:
		for i in range(squad.members()):
			var angle = TAU * float(i) / squad.data().men + squad.facing * 0.2
			var offset = Vector2.from_angle(angle) * (29 if i > 0 or squad.kind in ["mortar", "atgun"] else 1)
			var walk = sin(time * 12.0 + i * 2.0) * 2.2 if squad.moving else 0.0
			var position = at + offset + Vector2(walk, -walk)
			sprite(canvas, squad.kind, squad.team, position, squad.facing, Vector2(39, 39))
			if squad.shot_flash > 0 and i < 2:
				var muzzle = position + Vector2.from_angle(squad.facing) * 17
				canvas.draw_circle(muzzle, 4.5, Color("ffe09a"))
		if squad.kind in ["atgun", "mortar"]: sprite(canvas, squad.kind + "_weapon", squad.team, at, squad.facing, Vector2(62, 62))
	if squad.smoke_time > 0:
		for i in range(6):
			var offset = Vector2.from_angle(time * 0.15 + i * TAU / 6) * (23 + sin(time + i) * 8)
			canvas.draw_circle(at + offset, 24, Color(0.75, 0.78, 0.69, 0.22))
