extends SceneTree

var assertions: int = 0
var failures: int = 0

func _initialize() -> void:
	_run.call_deferred()

func check(condition: bool, text: String) -> void:
	assertions += 1
	if not condition:
		failures += 1
		push_error("FAIL: " + text)

func fresh(seed_number: int = 42) -> TheaterCampaign:
	var c = TheaterCampaign.new()
	c.setup(1, seed_number)
	return c

func peaceful_turn(c: TheaterCampaign) -> void:
	for i in range(c.armies.size() - 1, -1, -1):
		if c.armies[i].team == 1: c.armies.remove_at(i)
	c.end_turn()

func _run() -> void:
	var c = fresh()
	check(c.regions.size() == 15 and c.player_armies().size() == 2, "Campaign starts with fifteen provinces and two player armies")
	check(c.owned_count(0) == 4 and c.regions[10].connected, "Haven and four starting provinces are supplied")
	check(CombatSquad.TYPES.size() == 12 and c.allowed_kinds().size() == 6, "Twelve roles exist; six initially available in campaign")
	for id in range(15):
		for n in TheaterCampaign.neighbours(id):
			check(id in TheaterCampaign.neighbours(n), "Campaign routes are bidirectional")
	var fuel = c.economy.cargo.fuel
	check(not c.march(0, 4) and c.economy.cargo.fuel == fuel, "Illegal long-distance march cannot debit fuel")
	check(c.march(0, 11), "Army marches to adjacent friendly province")
	check(c.army(0).region == 11 and c.army(0).movement == 1 and c.economy.cargo.fuel == fuel - 1, "Movement consumes exactly one point and one fuel")
	check(c.march(0, 12) and c.phase == "battle", "Attacking a defended province creates a pending battle")
	check(c.army(0).region == 11 and c.pending.region == 12, "Army remains in its origin until result is committed")
	check(not c.end_turn() and not c.march(0, 7), "Pending battle locks strategic actions")
	var context = c.pending.duplicate(true)
	var saved = JSON.parse_string(JSON.stringify(c.snapshot()))
	var restored = fresh(17)
	check(restored.restore(saved), "Pending campaign survives a JSON save round trip")
	check(restored.phase == "battle" and restored.pending.id == context.id, "Pending battle identity and phase are restored")
	var b = BattleSimulation.new()
	b.setup(1, int(context.seed), context.biome)
	b.configure_campaign(context, c.economy, c.allowed_kinds())
	b.set_process(false)
	root.add_child(b)
	check(b.map_style == "farmland" and not b.water_at(Vector2(1260, 400)), "Province biome changes tactical navigation")
	check(b.economy == c.economy, "Campaign and battle use the same resource ledger")
	check(b.living(0).size() == 4 and b.living(1).size() == 1, "Army and garrison become actual tactical sections")
	var credits = c.economy.credits
	check(not b.recruit("tank") and c.economy.credits == credits, "Technology locks apply in tactical recruitment")
	b.get_squad(0).hp = 80
	b.get_squad(0).veterancy = 260
	b.get_squad(1).alive = false
	b.get_squad(1).hp = 0
	check(b.recruit("medic"), "Tactical reinforcements are paid from campaign funds")
	check(b.force_finish(0) and not b.force_finish(1), "Battle can finish exactly once")
	var friendly = b.campaign_survivors(0)
	var enemy = b.campaign_survivors(1)
	check(c.resolve_battle(context.id, 0, friendly, enemy), "Battle result commits to campaign")
	check(c.regions[12].owner == 0 and c.army(0).region == 12, "Victory captures province and moves the army")
	check(c.army(0).roster.size() == 4, "Casualties are removed and tactical recruits persist")
	check(c.army(0).roster[0].hp == 80 and c.army(0).roster[0].veterancy == 260, "Wounds and veteran experience persist")
	var ids = {}
	for unit in c.army(0).roster:
		check(unit.uid >= 0 and not ids.has(unit.uid), "Returning tactical recruits receive unique persistent IDs")
		ids[unit.uid] = true
	credits = c.economy.credits
	check(not c.resolve_battle(context.id, 0, friendly, enemy) and c.economy.credits == credits, "Duplicate result cannot grant duplicate rewards")
	b.free()

	# Research, construction, stance, resupply and attrition.
	c = fresh()
	c.economy.credits = 10000
	check(c.construct(10, "industry") and not c.construct(10, "fort"), "Construction charges once and allows only one queue per province")
	check(c.start_research("signals") and not c.start_research("mechanized"), "Research charges once and prevents simultaneous projects")
	check(not c.recruit(0, "sniper"), "Specialists remain locked while research is in progress")
	peaceful_turn(c)
	check(c.regions[10].industry == 1 and c.research.remaining == 1, "Multi-turn construction and research do not complete early")
	peaceful_turn(c)
	check(c.regions[10].industry == 2 and c.regions[10].job.is_empty(), "Completed industry upgrades province output")
	check("signals" in c.technology and "sniper" in c.allowed_kinds(), "Completed research unlocks correct unit roles")
	check(c.recruit(0, "sniper") and not c.recruit(0, "tank"), "Only unlocked unit families can be recruited")
	var entry = c.army(0)
	entry.roster[0].hp = 90
	check(c.set_stance(0, "replenish") and entry.movement == 0, "Replenish stance commits movement")
	c.set_stance(0, "march")
	check(entry.movement == 0, "Stance switching never refunds spent movement")
	c.set_stance(0, "replenish")
	peaceful_turn(c)
	check(entry.roster[0].hp > 90 and entry.movement == 0, "Replenishing supplied army heals at turn end")
	check(c.reinforce(0) and entry.roster[0].hp == CombatSquad.TYPES.rifle.hp, "Campaign reinforcement restores wounded veterans")
	check(not c.reinforce(0), "Full-strength army cannot consume reinforcement resources")
	c.regions[5].owner = 1
	c.regions[11].owner = 1
	c._reconnect()
	check(not c.regions[6].connected, "Cutting both routes isolates Green Vale")
	var stranded = c.army(1)
	stranded.supply = 20
	var hp: float = stranded.roster[0].hp
	peaceful_turn(c)
	check(stranded.supply == 0 and stranded.roster[0].hp < hp, "Unsupplied army takes actual attrition")
	check(not c.recruit(1, "rifle") and not c.reinforce(1), "Disconnected army cannot receive new sections or replacements")

	# Provincial markets are distinct, stock-limited and tied to army access.
	c = fresh()
	check(not is_equal_approx(c.markets[10].prices.fuel, c.markets[6].prices.fuel), "Provincial markets have different commodity prices")
	credits = c.economy.credits
	var stock: float = c.economy.cargo.supplies
	var price = c.markets[10].quote("supplies", true)
	check(c.trade(10, "supplies", true), "Capital market accepts a valid purchase")
	check(c.economy.credits == credits - price and c.economy.cargo.supplies == stock + 10, "Regional trade transfers the exact credit and cargo amounts")
	c.trade(10, "supplies", false)
	check(c.economy.credits < credits, "Regional market spread prevents free round-trip profit")
	credits = c.economy.credits
	check(not c.trade(5, "fuel", true) and c.economy.credits == credits, "Remote unstaffed market cannot be used without an army")
	c.markets[10].stock.fuel = 0
	check(not c.trade(10, "fuel", true) and c.economy.credits == credits, "Empty market cannot sell nonexistent stock")
	c.economy.cargo.supplies = 999
	check(not c.trade(10, "supplies", true) and c.economy.credits == credits, "Warehouse limit prevents paid cargo from being discarded on the next turn")
	c.economy.cargo.supplies = 150
	check(not c.raise_army(10), "Cannot stack a new army on an occupied province")
	check(c.raise_army(5) and c.player_armies().size() == 3, "Raising an army creates a persistent paid formation")
	c.economy.credits = 2000
	check(c.raise_army(11) and c.player_armies().size() == 4, "Fourth player army can be raised")
	c.regions[0].owner = 0
	c._reconnect()
	check(not c.raise_army(0), "Four-army limit prevents a fifth formation even in an empty supplied province")

	# Corrupt saves are rejected without overwriting the live campaign.
	saved = JSON.parse_string(JSON.stringify(c.snapshot()))
	restored = fresh()
	check(restored.restore(saved), "Campaign with markets and extra army saves correctly")
	credits = restored.economy.credits
	var bad: Dictionary = saved.duplicate(true)
	bad.markets[0].prices.fuel = "invalid"
	check(not restored.restore(bad) and restored.economy.credits == credits, "Invalid market field leaves the live state intact")
	bad = saved.duplicate(true)
	bad.armies[1].id = bad.armies[0].id
	check(not restored.restore(bad), "Duplicate army identifiers are rejected")
	bad = saved.duplicate(true)
	bad.armies[0].roster[0].kind = "invalid"
	check(not restored.restore(bad), "Unknown unit types are rejected")
	bad = saved.duplicate(true)
	bad.selected_region = 99
	check(not restored.restore(bad), "Out-of-bounds province selection is rejected")
	bad = saved.duplicate(true)
	bad.erase("phase")
	check(not restored.restore(bad), "Missing campaign phase is rejected safely")

	# New tactical roles exercise real combat/support mechanics.
	b = BattleSimulation.new()
	b.setup()
	b.set_process(false)
	root.add_child(b)
	for squad in b.squads: squad.alive = false
	b.fog = false
	var medic = b._spawn(0, "medic", Vector2(500, 1000))
	var wounded = b._spawn(0, "rifle", Vector2(540, 1000))
	wounded.hp = 100
	b._update_support(2)
	check(wounded.hp > 100, "Medic passive heals nearby wounded infantry out of combat")
	b.selected.assign([medic.id])
	check(b.ability(wounded.pos) and wounded.hp > 130, "Field-aid ability heals actual section health")
	var tank = b._spawn(1, "tank", Vector2(820, 1000))
	var atgun = b._spawn(0, "atgun", Vector2(500, 1000))
	var rifle = b._spawn(0, "rifle", Vector2(500, 1000))
	hp = tank.hp
	b._fire(rifle, tank)
	var rifle_damage = hp - tank.hp
	hp = tank.hp
	b._fire(atgun, tank)
	check(hp - tank.hp > rifle_damage * 3, "Anti-tank gun counters vehicle armor")
	var machine_gun = b._spawn(0, "support", Vector2(500, 1000))
	for i in range(8): b._fire(machine_gun, tank)
	check(tank.suppression == 0, "Machine-gun suppression cannot permanently pin an armored vehicle")
	var mortar = b._spawn(0, "mortar", Vector2(680, 640))
	var victim = b._spawn(1, "rifle", Vector2(920, 640))
	mortar.stationary = 3
	check(not b.line_of_sight(mortar.pos, victim.pos) and b._clear_shot(mortar, victim), "Mortar fires indirectly across a building")
	victim.pos = mortar.pos + Vector2(50, 0)
	check(not b._clear_shot(mortar, victim), "Mortar minimum range prevents point-blank fire")
	var scout = b._spawn(0, "recon", Vector2(500, 1000))
	b.selected.assign([scout.id])
	check(b.ability(Vector2(1000, 1000)) and b.reveal_zones.size() == 1, "Recon flare adds a timed visibility source")
	b._update_support(26)
	check(b.reveal_zones.is_empty(), "Recon flare expires")
	var carrier = b._spawn(0, "armor", Vector2(400, 1000))
	b.selected.assign([carrier.id])
	check(b.ability(carrier.pos) and carrier.smoke_time > 0, "Armored smoke ability creates timed protection")
	var flame = b._spawn(0, "flame", Vector2(400, 1100))
	b.selected.assign([flame.id])
	check(b.ability(Vector2(520, 1100)) and b.hazards.size() == 1, "Flame pioneers create a persistent damage zone")
	var burn_target = b._spawn(1, "rifle", Vector2(520, 1100))
	hp = burn_target.hp
	b._update_support(1)
	check(burn_target.hp < hp, "Fire zone deals actual damage over time")
	b._update_support(9)
	check(b.hazards.is_empty(), "Fire zones expire instead of persisting indefinitely")
	var marksman = b._spawn(0, "sniper", Vector2(400, 1300))
	var marked = b._spawn(1, "rifle", Vector2(600, 1300))
	b.selected.assign([marksman.id])
	hp = marked.hp
	check(b.ability(marked.pos) and marked.hp < hp - 90, "Marksman aimed shot applies precision damage")
	b.free()
	b = BattleSimulation.new()
	b.setup()
	b.get_squad(0).campaign_id = 777
	b.get_squad(0).last_hit = 0.0
	b.get_squad(0).stationary = 1.8
	b.get_squad(0).smoke_time = 14.0
	var saved_battle = JSON.parse_string(JSON.stringify(b.snapshot()))
	var resumed_battle = BattleSimulation.new()
	resumed_battle.setup()
	check(resumed_battle.restore(saved_battle), "Battle with advanced per-section state restores")
	check(resumed_battle.get_squad(0).campaign_id == 777, "Battle save retains persistent campaign identity")
	check(resumed_battle.get_squad(0).last_hit == 0.0, "Battle save retains the injury recovery delay")
	check(is_equal_approx(resumed_battle.get_squad(0).stationary, 1.8) and resumed_battle.get_squad(0).smoke_time == 14.0, "Battle save retains weapon setup and smoke duration")
	b.free()
	resumed_battle.free()

	# A mature campaign can actually complete through its normal battle resolver.
	c = fresh()
	for i in range(c.armies.size() - 1, -1, -1):
		if c.armies[i].team == 1 and c.armies[i].region != 4: c.armies.remove_at(i)
	for region in c.regions:
		if region.id != 4: region.owner = 0
	c.army(0).region = 3
	c.technology.append("mechanized")
	c.economy.credits = 10000
	c.economy.cargo = {"supplies": 900.0, "ammo": 900.0, "fuel": 900.0}
	c._reconnect()
	for i in range(4): check(c.recruit(0, "tank"), "Mature campaign fields unlocked tank sections")
	check(c.march(0, 4), "Final offensive can target Iron Crown")
	check(c.auto_resolve() and c.phase == "victory", "Taking Iron Crown with nine provinces completes the campaign")
	check(fresh().restore(JSON.parse_string(JSON.stringify(c.snapshot()))), "Completed victorious campaign can be saved and restored")
	c = fresh()
	for i in range(c.armies.size() - 1, -1, -1):
		if c.armies[i].team == 1: c.armies.remove_at(i)
	for region in c.regions:
		if region.id != 4: region.owner = 0
	c.regions[4].garrison = 0
	c.army(0).region = 3
	c._reconnect()
	check(c.march(0, 4) and c.phase == "victory", "Capturing an undefended capital also ends the campaign immediately")

	# Several complete strategic AI phases, including actual pending defenses.
	for seed_number in [42, 77, 123]:
		c = fresh(seed_number)
		var defenses = 0
		for i in range(25):
			if c.phase in ["victory", "defeat"]: break
			if c.phase == "player": c.end_turn()
			var guard = 0
			while c.phase in ["battle", "enemy"] and guard < 10:
				guard += 1
				if c.phase == "battle":
					defenses += 1
					check(c.auto_resolve(), "AI offensive can auto-resolve with persistent casualties")
				else: c.advance_enemy_phase()
			check(guard < 10, "Enemy phase does not loop indefinitely")
			check(c.economy.credits >= 0 and c.economy.cargo.fuel >= 0, "Strategic economy never becomes negative")
			var snapshot = JSON.parse_string(JSON.stringify(c.snapshot()))
			check(fresh().restore(snapshot), "Real multi-turn campaign remains serializable")
		check(defenses > 0, "Strategic AI actually attacks allied provinces")
		check(c.phase == "defeat", "Unopposed strategic offensive can capture Haven and end the campaign")
		print("CAMPAIGN seed=%d turn=%d phase=%s defenses=%d" % [seed_number, c.turn, c.phase, defenses])

	print("CAMPAIGN TESTS: %d assertions, %d failures" % [assertions, failures])
	quit(0 if failures == 0 else 1)
