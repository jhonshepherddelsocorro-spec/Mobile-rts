extends SceneTree

var assertions: int = 0
var failures: int = 0
var game: Node

func _initialize() -> void:
	_run.call_deferred()

func check(condition: bool, text: String) -> void:
	assertions += 1
	if not condition:
		failures += 1
		push_error("FAIL: " + text)

func frames(count: int = 4) -> void:
	for i in range(count): await process_frame

func find_button(node: Node, text: String, exact: bool = false) -> Button:
	if node is Button and (node.text == text if exact else text in node.text): return node
	for child in node.get_children():
		var found = find_button(child, text, exact)
		if found: return found
	return null

func touch(at: Vector2, pressed: bool, index: int = 0) -> void:
	var event = InputEventScreenTouch.new()
	event.index = index
	event.position = root.get_final_transform() * at
	event.pressed = pressed
	Input.parse_input_event(event)
	await frames(2)

func tap(at: Vector2) -> void:
	await touch(at, true)
	await touch(at, false)
	await frames()

func press(text: String, exact: bool = false) -> void:
	var surface = game.world_ui.root if is_instance_valid(game.world_ui) else game.ui.root
	var b = find_button(surface, text, exact)
	check(b != null and b.is_visible_in_tree(), "Button available: " + text)
	if b == null: return
	var ancestor: Node = b.get_parent()
	while ancestor != null:
		if ancestor is ScrollContainer:
			ancestor.ensure_control_visible(b)
			await frames()
		ancestor = ancestor.get_parent()
	check(not b.disabled, "Button enabled: " + text)
	await tap(b.get_global_rect().get_center())
	await frames(6)

func province(id: int) -> void:
	var atlas: RegionAtlas = game.world_ui.atlas
	var point = atlas.get_global_transform() * atlas.map_to_screen(TheaterCampaign.position_of(id))
	await tap(point)

func screenshot(name_value: String) -> void:
	if DisplayServer.get_name() == "headless": return
	await frames(5)
	await RenderingServer.frame_post_draw
	check(root.get_texture().get_image().save_png("res://docs/screenshots/" + name_value + ".png") == OK, "Screenshot: " + name_value)

func _run() -> void:
	game = preload("res://scripts/main.gd").new()
	root.add_child(game)
	await frames(12)
	check(game.mode == "home" and game.world_ui.home_mode, "Default app opens campaign-oriented home screen")
	await screenshot("home-v02")
	game._notification(Node.NOTIFICATION_WM_GO_BACK_REQUEST)
	await frames()
	check(game.world_ui._screen == "exit", "Android Back on home offers an exit confirmation")
	await press("KEEP PLAYING")
	await press("NEW CAMPAIGN", true)
	check(game.world_ui._screen == "new_campaign", "New campaign has an explicit deployment confirmation")
	await press("BEGIN CAMPAIGN")
	check(game.mode == "campaign" and game.campaign.turn == 1, "Touch starts a fresh campaign")
	check(game.campaign.player_armies().size() == 2, "Fresh campaign has two controllable armies")
	await screenshot("campaign-v02")
	await province(10)
	check(game.campaign.selected_region == 10 and game.campaign.selected_army == 0, "Province tap selects the friendly army")
	await press("MANAGE ARMY")
	check(game.world_ui._screen == "army", "Army-management sheet opens")
	await screenshot("army-v02")
	var old_roster: int = game.campaign.army(0).roster.size()
	await press("180 cr")
	check(game.campaign.army(0).roster.size() == old_roster + 1, "Touch campaign recruitment adds a paid section")
	await press("X", true)
	await press("RESEARCH", true)
	await screenshot("research-v02")
	await press("280 cr")
	check(game.campaign.research.get("kind") == "signals", "Touch commissions signal-corps research")
	await press("X", true)
	await press("DEVELOP PROVINCE")
	await press("180 cr")
	check(game.campaign.regions[10].job.get("kind") == "industry", "Touch queues province construction")
	await press("X", true)
	await press("MARKET", true)
	await screenshot("regional-market-v02")
	var supplies: float = game.campaign.economy.cargo.supplies
	await press("BUY 10")
	check(game.campaign.economy.cargo.supplies == supplies + 10, "Touch executes a regional market transaction")
	await press("X", true)
	await province(12)
	check(game.campaign.selected_region == 12, "Atlas touch selects hostile destination")
	await press("ATTACK PROVINCE")
	check(game.campaign.phase == "battle" and game.world_ui._screen == "battle_preview", "Attack produces a campaign battle preview")
	await screenshot("battle-preview-v02")
	await press("COMMAND BATTLE")
	await frames(12)
	check(game.mode == "battle" and game.ui is MobileCommandInterface, "Campaign deploys the actual mobile tactical interface")
	check(game.battle.map_style == "farmland" and not game.battle.campaign_context.is_empty(), "Tactical map uses the attacked province's biome")
	check(game.battle.living(0).size() == old_roster + 1, "The exact strategic army is deployed")
	check(game.battle.economy == game.campaign.economy, "Tactical spending and strategic treasury share one ledger")
	await screenshot("campaign-battle-v02")
	# Small touch-sensor movements must not accumulate into a false drag.
	var unit_point: Vector2 = game.field.get_canvas_transform() * game.battle.get_squad(0).pos
	var camera_before: Vector2 = game.field.camera.position
	game.battle.selected.clear()
	await touch(unit_point, true)
	for i in range(8):
		var jitter = InputEventScreenDrag.new()
		jitter.index = 0
		jitter.position = root.get_final_transform() * (unit_point + Vector2(2 if i % 2 == 0 else -2, 0))
		Input.parse_input_event(jitter)
		await frames(1)
	await touch(unit_point, false)
	check(game.battle.selected.has(0), "A jittering finger still selects a section")
	check(game.field.camera.position == camera_before, "Touch-sensor jitter does not pan the battlefield")
	await press("MULTI / OFF")
	check(game.battle.multi_select, "Mobile group-selection toggle works")
	await press("SELECT ALL")
	check(game.battle.selected.size() == game.battle.living(0).size(), "Select All includes all deployed sections")
	await press("MAP", true)
	check(game.ui.overview.visible, "Mobile tactical overview can be opened")
	await press("MAP", true)
	await press("+ RECRUIT")
	await screenshot("recruit-v02")
	var units_before: int = game.battle.living(0).size()
	await press("210 cr")
	check(game.battle.living(0).size() == units_before + 1, "Mobile tactical recruitment deploys field medics")
	var unit = game.battle.living(0)[0]
	unit.hp = 120
	unit.last_hit = game.battle.elapsed
	unit.veterancy = 180
	game.battle.selected.assign([unit.id])
	game.battle.command(Vector2(1000, 1030), true)
	check(game._save(), "Campaign and in-flight battle save atomically")
	var persistent_unit_id: int = unit.campaign_id
	var credits: float = game.campaign.economy.credits
	var order_destination: Vector2 = unit.destination
	game._resume_campaign()
	var restored_credits: float = game.campaign.economy.credits
	check(game.battle.get_squad(0).campaign_id == persistent_unit_id, "Resume preserves the original campaign section identity")
	await frames(12)
	check(game.mode == "battle" and game.battle.living(0).size() == units_before + 1, "Full campaign save restores an active tactical battle")
	check(is_equal_approx(restored_credits, credits), "Resume neither duplicates nor drops treasury resources")
	check(game.battle.get_squad(0).veterancy == 180 and game.battle.get_squad(0).hp <= 120, "Veteran status and injuries survive app restoration")
	check(game.battle.get_squad(0).destination.distance_to(order_destination) < 1, "Active squad orders survive restoration")
	game._notification(Node.NOTIFICATION_APPLICATION_PAUSED)
	await frames()
	check(game.battle.paused and game.ui._screen == "pause", "Mobile backgrounding pauses the match and opens resume controls")
	await press("BATTERY & DISPLAY")
	var old_quality: int = game.preferences.quality
	await press("EFFECTS /")
	check(game.preferences.quality != old_quality and game.battle.quality == game.preferences.quality, "In-battle effects preference applies to the live battlefield")
	await press("RETURN TO BATTLE")
	await press("PAUSE", true)
	await press("SAVE & MAIN MENU")
	check(game.mode == "home", "Saving from battle returns safely to the main menu")
	await press("CONTINUE CAMPAIGN")
	check(game.mode == "battle" and game.battle.living(0).size() == units_before + 1, "Home Continue resumes the same campaign battle")
	await press("PAUSE", true)
	await press("WITHDRAW FROM BATTLE")
	await press("CONFIRM WITHDRAWAL")
	check(game.battle.finished and game.battle.winner == 1 and game.ui._screen == "results", "Confirmed withdrawal creates a real defeat result")
	await screenshot("campaign-result-v02")
	check(game._save(), "Completed battle result is saved before returning to campaign")
	game._show_home()
	await frames(8)
	await press("CONTINUE CAMPAIGN")
	check(game.battle.finished and game.battle.winner == 1 and game.ui._screen == "results", "Completed result survives quitting and resuming without replaying battle")
	await press("RETURN TO CAMPAIGN")
	check(game.mode == "campaign" and game.campaign.phase == "player", "Battle result returns to strategic command")
	check(game.campaign.army(0).roster.size() == units_before + 1, "Paid tactical recruits persist after withdrawal")
	check(game.campaign.army(0).region == 10 and game.campaign.regions[12].owner == -1, "Failed attack preserves defender ownership and retreats attacker to origin")
	check(game.campaign.army(0).roster[0].veterancy == 180, "Returning campaign army retains battle veterans")
	for i in range(2):
		await press("END TURN", true)
		await press("COMMIT TURN")
		var guard = 0
		while game.campaign.phase in ["battle", "enemy"] and guard < 6:
			guard += 1
			await frames(6)
			if game.campaign.phase == "battle": await press("AUTO RESOLVE")
		check(guard < 6, "Defensive battles resolve and return control")
	check("signals" in game.campaign.technology and game.campaign.regions[10].industry == 2, "UI-driven turns complete research and construction")
	root.size = Vector2i(1920, 864)
	await frames(10)
	check(root.get_visible_rect().size.x / root.get_visible_rect().size.y > 2, "Wide phone viewport expands without letterboxing")
	check(game.world_ui.sidebar.get_global_rect().position.x < root.get_visible_rect().size.x, "Province commands remain inside phone viewport")
	await screenshot("campaign-phone-v02")
	var atlas: RegionAtlas = game.world_ui.atlas
	var selected_before: int = game.campaign.selected_region
	var center = atlas.get_global_rect().get_center()
	await touch(center - Vector2(80, 0), true, 0)
	await touch(center + Vector2(80, 0), true, 1)
	var drag = InputEventScreenDrag.new()
	drag.index = 1
	drag.position = root.get_final_transform() * (center + Vector2(160, 0))
	drag.relative = Vector2(80, 0) * root.get_final_transform().get_scale()
	Input.parse_input_event(drag)
	await frames()
	await touch(center - Vector2(80, 0), false, 0)
	await touch(center + Vector2(160, 0), false, 1)
	check(atlas.zoom > 1, "Native two-finger pinch zooms the regional atlas")
	check(game.campaign.selected_region == selected_before, "Pinch release does not select or invade a province")
	await press("MENU", true)
	await press("MOBILE & AUDIO SETTINGS")
	await screenshot("settings-v02")
	var previous_fps: int = game.preferences.fps
	await press("FRAME RATE")
	check(game.preferences.fps != previous_fps and Engine.max_fps == game.preferences.fps, "Mobile battery/frame-rate preference applies immediately")
	await press("X", true)
	check(game._save_campaign(), "Campaign saves after completed tactical and strategic phases")
	var saved_turn: int = game.campaign.turn
	game._show_home()
	await frames(8)
	await press("CONTINUE CAMPAIGN")
	check(game.mode == "campaign" and game.campaign.turn == saved_turn, "Strategic campaign resumes from home after battle results and turn processing")
	game.queue_free()
	await frames(5)
	await create_timer(0.15).timeout
	print("CAMPAIGN INTERFACE TESTS: %d assertions, %d failures" % [assertions, failures])
	quit(0 if failures == 0 else 1)
