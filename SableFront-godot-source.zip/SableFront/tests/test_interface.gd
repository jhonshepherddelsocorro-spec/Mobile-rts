extends SceneTree

var assertions: int = 0
var failures: int = 0
var game: Node

func _initialize() -> void:
	_run.call_deferred()

func check(condition: bool, text: String) -> void:
	assertions += 1
	if not condition:
		failures += 1
		push_error("FAIL: " + text)

func frames(count: int = 3) -> void:
	for i in range(count): await process_frame

func find_button(node: Node, text: String) -> Button:
	if node is Button and text in node.text: return node
	for child in node.get_children():
		var found = find_button(child, text)
		if found: return found
	return null

func tap(at: Vector2) -> void:
	at = root.get_final_transform() * at
	var down = InputEventScreenTouch.new()
	down.index = 0
	down.position = at
	down.pressed = true
	Input.parse_input_event(down)
	await frames(2)
	var up = InputEventScreenTouch.new()
	up.index = 0
	up.position = at
	up.pressed = false
	Input.parse_input_event(up)
	await frames()

func click_button(text: String) -> void:
	var b = find_button(game.ui.root, text)
	check(b != null and b.is_visible_in_tree(), "Button visible: " + text)
	if b:
		await tap(b.get_global_rect().get_center())

func screenshot(name_value: String) -> void:
	if DisplayServer.get_name() == "headless": return
	await frames(4)
	await RenderingServer.frame_post_draw
	var path = "res://docs/screenshots/" + name_value + ".png"
	check(root.get_texture().get_image().save_png(path) == OK, "Screenshot: " + name_value)

func _run() -> void:
	game = preload("res://scripts/main.gd").new()
	game.testing_skirmish = true
	root.add_child(game)
	await frames(8)
	print("DISPLAY size=", root.size, " viewport=", root.get_visible_rect(), " transform=", root.get_final_transform())
	check(game.battle.paused and game.ui.overlay != null, "Briefing pauses the battle")
	await screenshot("briefing")
	await click_button("FIELD MANUAL")
	check(game.ui._screen == "guide" and game.battle.paused, "Briefing field guide keeps operation paused")
	await click_button("RETURN TO BRIEFING")
	check(game.ui._screen == "briefing" and game.battle.paused, "Field guide returns to deployment screen")
	await click_button("DEPLOY PLATOON")
	await frames(8)
	check(not game.battle.paused and game.ui.overlay == null, "Touch deploy starts a new battle")
	check(game.ui.hint_panel.get_global_rect().position.y > 0, "Control hint on screen")
	var recruit = find_button(game.ui.root, "+ RECRUIT")
	check(recruit.get_global_rect().position.x >= 0 and recruit.get_global_rect().position.y >= 0, "Recruit button on screen")
	await click_button("+ RECRUIT")
	check(game.battle.paused and game.ui._screen == "recruit", "Recruit modal opens and pauses match")
	await screenshot("recruit")
	var old_count = game.battle.living(0).size()
	await click_button("180 cr")
	check(game.battle.living(0).size() == old_count + 1, "Touch recruitment spends resources and adds squad")
	check(not game.battle.paused, "Recruitment returns to live battle")
	await click_button("FIELD MARKET")
	check(game.ui._screen == "market" and game.battle.paused, "Touch opens field market")
	await screenshot("market")
	var old_cargo = game.battle.economy.cargo.supplies
	var buy: Button = game.ui.market_buttons.supplies.buy
	await tap(buy.get_global_rect().get_center())
	check(game.battle.economy.cargo.supplies == old_cargo + 10, "Touch trade buys supplies")
	await click_button("BACK TO THE FRONT")
	check(not game.battle.paused and game.ui.overlay == null, "Closing market resumes match")
	# Map tap commands must not be swallowed by a full-screen HUD.
	game.field.focus(Vector2(700, 900))
	await frames()
	var squad = game.battle.get_squad(0)
	game.battle.selected.assign([0])
	var destination = Vector2(800, 1030)
	var screen_pos = game.field.get_canvas_transform() * destination
	await tap(screen_pos)
	check(squad.destination.distance_to(destination) < 32, "Touch map issues movement order through HUD (40m navigation grid)")
	# A drag pans instead of accidentally issuing a move command.
	var old_destination: Vector2 = squad.destination
	var old_camera: Vector2 = game.field.camera.position
	var down = InputEventScreenTouch.new()
	down.index = 0
	down.position = Vector2(850, 400)
	down.pressed = true
	Input.parse_input_event(down)
	await frames()
	var drag = InputEventScreenDrag.new()
	drag.index = 0
	drag.position = Vector2(750, 400)
	drag.relative = Vector2(-100, 0)
	Input.parse_input_event(drag)
	await frames()
	down.pressed = false
	down.position = drag.position
	Input.parse_input_event(down)
	await frames()
	check(game.field.camera.position.x > old_camera.x, "One-finger drag pans camera")
	check(squad.destination == old_destination, "Pan does not issue a spurious movement order")
	# Two-finger pinch zooms without issuing a move on finger release.
	var zoom_before: float = game.field.camera.zoom.x
	for i in [0, 1]:
		var touch = InputEventScreenTouch.new()
		touch.index = i
		touch.position = Vector2(650 + i * 250, 400)
		touch.pressed = true
		Input.parse_input_event(touch)
	await frames()
	drag.index = 1
	drag.position = Vector2(1025, 400)
	Input.parse_input_event(drag)
	await frames()
	for i in [0, 1]:
		var touch = InputEventScreenTouch.new()
		touch.index = i
		touch.position = Vector2(650 if i == 0 else 1025, 400)
		touch.pressed = false
		Input.parse_input_event(touch)
	await frames()
	check(game.field.camera.zoom.x > zoom_before, "Two-finger pinch zooms battlefield")
	check(squad.destination == old_destination, "Pinch release does not issue movement")
	await screenshot("battle")
	# Saves exercise real filesystem and replacement, not only model serialization.
	check(game._save(), "Actual atomic save writes successfully")
	var credits = game.battle.economy.credits
	game.battle.economy.credits = 1
	game._resume()
	check(is_equal_approx(game.battle.economy.credits, credits), "Actual local save restores resources")
	game.ui.show_pause()
	await frames()
	await screenshot("pause")
	game.ui.close_popup()
	# Phone aspect ratio: canvas expands horizontally, HUD remains accessible.
	root.size = Vector2i(1920, 864)
	await frames(8)
	var viewport_size = root.get_visible_rect().size
	check(viewport_size.x / viewport_size.y > 2.0, "Landscape phone aspect ratio applied")
	check(recruit.get_global_rect().end.x <= viewport_size.x + 2, "Recruit stays inside phone viewport")
	check(game.ui.roster.get_global_rect().position.y < viewport_size.y, "Squad cards stay inside phone viewport")
	var half = viewport_size / game.field.camera.zoom / 2.0
	check(game.field.camera.position.x - half.x >= -1, "Camera cannot expose blank space beyond west map edge")
	check(game.field.camera.position.x + half.x <= BattleSimulation.WORLD.x + 1, "Camera cannot expose blank space beyond east map edge")
	await screenshot("mobile")
	await click_button("FIELD MARKET")
	await frames(5)
	check(game.ui.popup.get_global_rect().position.x >= 0, "Market remains on screen at phone aspect")
	check(game.ui.popup.get_global_rect().end.y <= viewport_size.y + 2, "Market fits phone viewport height")
	await click_button("BACK TO THE FRONT")
	root.size = Vector2i(1440, 900)
	await frames(8)
	# Match ending locks input and offers a new deployment.
	game.battle.tickets[1] = 0
	game.battle._ticket_clock = 2
	game.battle.step(0.1)
	await frames()
	check(game.battle.finished and game.ui._screen == "results", "Match victory displays results")
	await screenshot("victory")
	await click_button("DEPLOY AGAIN")
	await frames(8)
	check(not game.battle.finished and game.battle.living(0).size() == 3, "Touch restart creates a clean match")
	game.queue_free()
	await frames(5)
	await create_timer(0.15).timeout
	print("INTERFACE TESTS: %d assertions, %d failures" % [assertions, failures])
	quit(0 if failures == 0 else 1)
