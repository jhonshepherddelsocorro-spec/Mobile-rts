extends SceneTree

var assertions: int = 0
var failures: int = 0

func _initialize() -> void:
	_run.call_deferred()

func check(condition: bool, text: String) -> void:
	assertions += 1
	if not condition:
		failures += 1
		push_error("FAIL: " + text)

func new_battle(seed_value: int = 42) -> BattleSimulation:
	var b = BattleSimulation.new()
	b.setup(1, seed_value)
	b.set_process(false)
	root.add_child(b)
	return b

func advance(b: BattleSimulation, seconds: float) -> void:
	for i in range(int(seconds * 10.0)): b.step(0.1)

func _run() -> void:
	var b: BattleSimulation = new_battle()
	check(b.living(0).size() == 3 and b.living(1).size() == 3, "Initial platoons spawn")
	check(b.points[0].linked and b.points[4].linked, "Initial supply routes connect to both HQs")
	check(b.get_squad(0).members() == 5, "Rifle section has five living soldiers")
	check(not b.line_of_sight(Vector2(700, 640), Vector2(910, 640)), "Buildings block line of sight")
	check(b.line_of_sight(Vector2(600, 1000), Vector2(900, 1000)), "Open ground permits line of sight")
	var path = b.path_between(Vector2(600, 1040), Vector2(1940, 1330))
	check(not path.is_empty(), "Navigation finds a path across the canal")
	for p in path:
		check(not BattleSimulation.is_water(p), "Waypoint stays on navigable bridge or ground")
		for building in b.buildings: check(not building.grow(10).has_point(p), "Waypoint avoids buildings")
	b.selected = [0]
	b.command(Vector2(600, 1040))
	advance(b, 7)
	check(b.get_squad(0).pos.distance_to(Vector2(600, 1040)) < 80, "Ordered squad reaches sector")
	b.paused = true
	var time_before = b.elapsed
	b.step(10)
	check(b.elapsed == time_before, "Tactical pause stops simulation")
	b.paused = false
	b.free()

	# Capture, neutralization, contested progress and disconnected production.
	b = new_battle()
	for s in b.squads: s.alive = false
	var engineer = b._spawn(0, "engineer", b.points[1].pos)
	b._capture(9)
	check(b.points[1].owner == 0 and b.points[1].linked, "Engineer captures and connects rail depot")
	b.points[0].owner = 1
	b._reconnect()
	check(not b.points[1].linked, "Losing Orchard disconnects downstream player territory")
	var ammo_before = b.economy.cargo.ammo
	b._market_tick()
	check(is_equal_approx(b.economy.cargo.ammo - ammo_before, 1.0), "Disconnected depot provides no production")
	var enemy = b._spawn(1, "rifle", b.points[1].pos + Vector2(20, 0))
	var progress = b.points[1].progress
	b._capture(4)
	check(b.points[1].contested and b.points[1].progress == progress, "Contested sectors freeze capture")
	engineer.alive = false
	b._capture(24)
	check(b.points[1].owner == 1, "Enemy neutralizes and captures occupied sector")
	enemy.alive = false
	b.free()

	# Transactions are atomic and cannot create resources on failed purchases.
	var econ = WarEconomy.new(91)
	var old_credits = econ.credits
	var old_supplies = econ.cargo.supplies
	var quote = econ.quote("supplies", true)
	econ.trade("supplies", true)
	check(econ.cargo.supplies == old_supplies + 10 and econ.credits == old_credits - quote, "Buying transfers exact cargo and credits")
	econ.trade("supplies", false)
	check(econ.credits < old_credits, "Round-trip trade has a spread")
	econ.credits = 0
	old_supplies = econ.cargo.supplies
	econ.trade("supplies", true)
	check(econ.cargo.supplies == old_supplies, "Unaffordable purchase cannot add cargo")
	econ.cargo.fuel = 0
	econ.trade("fuel", false)
	check(econ.cargo.fuel == 0 and econ.credits == 0, "Cannot sell cargo not owned")
	econ.stock.ammo = 160
	econ._reprice(false)
	var baseline = econ.prices.ammo
	econ.stock.ammo = 30
	econ._reprice(false)
	check(econ.prices.ammo > baseline, "Shortages raise market prices")
	var scarce_price = econ.prices.ammo
	econ.stock.ammo = 300
	econ._reprice(false)
	check(econ.prices.ammo < scarce_price, "Oversupply lowers market prices")
	for i in range(100): econ.tick({}, 5, 8.0, 0)
	for good in WarEconomy.GOODS:
		check(econ.history[good].size() == 24, "Market history stays bounded")
		check(econ.stock[good] >= 0 and econ.prices[good] > 0, "Market remains solvent under sustained war demand")

	# Combat must apply suppression, cover, retreat and lethality.
	b = new_battle()
	for s in b.squads: s.alive = false
	b.fog = false
	var attacker = b._spawn(0, "support", Vector2(960, 860))
	var target = b._spawn(1, "rifle", Vector2(960, 1000))
	var health = target.hp
	b._fire(attacker, target)
	var exposed_damage = health - target.hp
	check(exposed_damage > 0 and target.suppression > 0, "Automatic weapon damages and suppresses")
	target.hp = health
	target.cover = 0.55
	b._fire(attacker, target)
	check(health - target.hp < exposed_damage, "Cover reduces frontal damage")
	target.hp = health
	target.cover = 0
	target.order = "retreat"
	b._fire(attacker, target)
	check(health - target.hp < exposed_damage, "Retreat grants damage reduction")
	for i in range(150): b._fire(attacker, target)
	check(not target.alive and b.kills[0] == 1, "Elimination awards exactly one kill")
	check(b.tickets[1] == 288, "Losing a section drains command strength")
	check(attacker.rank() > 0, "Surviving combat builds veterancy")
	b.free()

	# Reinforcement, recruitment costs, squad limits and abilities.
	b = new_battle()
	b.selected = [0]
	var unit = b.get_squad(0)
	unit.hp = 50
	unit.pos = BattleSimulation.BASES[0]
	check(b.reinforce() and unit.hp == unit.max_hp, "Wounded squad reinforces at HQ")
	unit.hp = 50
	unit.pos = Vector2(900, 500)
	check(not b.reinforce() and unit.hp == 50, "Cannot reinforce away from HQ")
	b.economy.credits = 5000
	b.economy.cargo = {"supplies": 900.0, "ammo": 900.0, "fuel": 900.0}
	check(b.recruit("armor") and b.living(0).back().kind == "armor", "Scout carrier can be recruited")
	for i in range(5): b.recruit("rifle")
	check(b.living(0).size() == 8 and not b.recruit("rifle"), "Eight-squad command limit enforced")
	b.selected = [2]
	var count = b.covers.size()
	check(b.ability(b.get_squad(2).pos + Vector2(0, 70)), "Engineers build sandbags")
	check(b.covers.size() == count + 1, "Sandbag ability adds functional cover")
	check(not b.ability(b.get_squad(2).pos), "Ability cooldown prevents spam")
	b.selected = [0]
	unit = b.get_squad(0)
	var victim = b.get_squad(3)
	victim.pos = unit.pos + Vector2(100, 0)
	health = victim.hp
	check(b.ability(victim.pos) and victim.hp < health, "Grenade applies area damage")
	b.free()

	# Convoy success and enemy interdiction use actual delivery simulation.
	b = new_battle()
	for s in b.squads: s.alive = false
	old_supplies = b.economy.cargo.supplies
	check(b.dispatch_convoy(), "Convoy can be dispatched")
	check(not b.dispatch_convoy(), "Cannot stack simultaneous convoys")
	b._update_convoys(25)
	check(b.convoys.is_empty() and b.economy.cargo.supplies == old_supplies + 45, "Convoy delivers promised cargo")
	b.economy.credits = 1000
	b.dispatch_convoy()
	b._spawn(1, "rifle", BattleSimulation.BASES[0])
	old_supplies = b.economy.cargo.supplies
	for i in range(24): b._update_convoys(1)
	check(b.convoys.is_empty() and b.economy.cargo.supplies == old_supplies, "Enemy intercepts unprotected convoy")
	b.free()

	# Save/resume round-trip survives JSON and reconstructs routes, economy and abilities.
	b = new_battle()
	b.selected = [0, 2]
	b.command(Vector2(990, 540))
	advance(b, 5)
	b.dispatch_convoy()
	var saved = JSON.parse_string(JSON.stringify(b.snapshot()))
	var restored = new_battle(11)
	check(restored.restore(saved), "JSON save restores successfully")
	check(restored.living(0).size() == b.living(0).size(), "Save preserves army")
	check(restored.get_squad(0).pos.distance_to(b.get_squad(0).pos) < 0.01, "Save preserves exact squad position")
	check(is_equal_approx(restored.economy.credits, b.economy.credits), "Save preserves credit balance")
	check(restored.convoys.size() == 1, "Save preserves inbound convoy")
	check(not restored.get_squad(0).route.is_empty(), "Save reconstructs active movement path")
	check(not restored.restore({"version": 1}), "Malformed save is rejected")
	var damaged: Dictionary = saved.duplicate(true)
	damaged.squads[0].veterancy = "invalid"
	check(not restored.restore(damaged), "Invalid optional save field is rejected before mutation")
	damaged = saved.duplicate(true)
	damaged.kills = "invalid"
	check(not restored.restore(damaged), "Invalid save array is rejected before mutation")
	check(restored.get_squad(0).pos.distance_to(b.get_squad(0).pos) < 0.01, "Failed save load leaves current match untouched")
	b.free()
	restored.free()

	# End-to-end matches with real AI and orders must finish, not silently zero-test.
	for seed_value in [42, 77, 123]:
		b = new_battle(seed_value)
		var shots = [0]
		b.shot.connect(func(_a, _z, _t, _h): shots[0] += 1)
		for tick in range(11000):
			if b.finished: break
			# A simple test commander contests sectors, replenishes troops and trades.
			if tick % 70 == 0:
				var target_index = 0
				for s in b.living(0):
					if s.hp < s.max_hp * 0.25:
						b._move(s, BattleSimulation.BASES[0], "retreat")
					elif s.order != "retreat":
						b.selected = [s.id]
						b.command(b.points[[1, 2, 3, 0, 4][target_index % 5]].pos, true)
					target_index += 1
				if b.living(0).size() < 4: b.recruit("rifle")
				b.selected.assign(b.living(0).map(func(s): return s.id))
				b.reinforce()
			b.step(0.1)
		check(shots[0] > 30, "Seed %d: active combat actually executed" % seed_value)
		check(b.finished and b.winner in [0, 1], "Seed %d: full match reaches a valid result" % seed_value)
		for good in WarEconomy.GOODS: check(b.economy.cargo[good] >= 0, "Seed %d: no negative inventory" % seed_value)
		for s in b.squads: check(s.hp >= 0 and s.hp <= s.max_hp, "Squad health remains valid")
		print("MATCH seed=%d time=%.1fs winner=%d shots=%d squads=%d" % [seed_value, b.elapsed, b.winner, shots[0], b.squads.size()])
		b.free()
	print("SIMULATION TESTS: %d assertions, %d failures" % [assertions, failures])
	quit(0 if failures == 0 else 1)
