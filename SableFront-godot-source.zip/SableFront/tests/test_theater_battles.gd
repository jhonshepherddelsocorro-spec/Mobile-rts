extends SceneTree

var assertions: int = 0
var failures: int = 0

func _initialize() -> void:
	_run.call_deferred()

func check(condition: bool, text: String) -> void:
	assertions += 1
	if not condition:
		failures += 1
		push_error("FAIL: " + text)

func command_platoon(b: BattleSimulation) -> void:
	var index = 0
	for squad in b.living(0):
		if squad.hp < squad.max_hp * 0.22:
			b._move(squad, BattleSimulation.BASES[0], "retreat")
		elif squad.order != "retreat":
			b.selected.assign([squad.id])
			b.command(b.points[[1, 2, 3, 0, 4][index % 5]].pos, true)
		index += 1
	b.selected.assign(b.living(0).map(func(s): return s.id))
	b.reinforce()

func fight(b: BattleSimulation, limit: int = 11000) -> int:
	var shots = [0]
	b.shot.connect(func(_a, _b, _c, _d): shots[0] += 1)
	for tick in range(limit):
		if b.finished: break
		if tick % 60 == 0:
			command_platoon(b)
			if b.living(0).size() < 5: b.recruit("rifle")
		b.step(0.1)
	return shots[0]

func _run() -> void:
	for biome in ["forest", "ridge", "city", "farmland"]:
		var b = BattleSimulation.new()
		b.setup(1, 54, biome)
		b.set_process(false)
		root.add_child(b)
		for kind in ["support", "medic", "mortar", "tank", "sniper"]: b._spawn(0, kind, BattleSimulation.BASES[0] + Vector2(130, -150))
		b.economy.credits = 3500
		b.economy.cargo = {"supplies": 700.0, "ammo": 700.0, "fuel": 500.0}
		var path = b.path_between(Vector2(300, 1300), Vector2(2100, 500))
		check(not path.is_empty(), biome + ": traversable tactical map")
		var saved = JSON.parse_string(JSON.stringify(b.snapshot()))
		var restored = BattleSimulation.new()
		restored.setup()
		check(restored.restore(saved) and restored.map_style == biome, biome + ": biome and geometry restore from save")
		restored.free()
		var shots = fight(b)
		check(shots > 20, biome + ": actual combined-arms combat executed")
		check(b.finished and b.winner in [0, 1], biome + ": complete skirmish reaches a valid outcome")
		print("BIOME %s elapsed=%.1f winner=%d shots=%d" % [biome, b.elapsed, b.winner, shots])
		b.free()

	var c = TheaterCampaign.new()
	c.setup(1, 42)
	check(c.march(0, 12) and c.phase == "battle", "Actual campaign offensive creates a valid tactical context")
	var b = BattleSimulation.new()
	b.setup(1, int(c.pending.seed), c.pending.biome)
	b.configure_campaign(c.pending, c.economy, c.allowed_kinds())
	b.set_process(false)
	root.add_child(b)
	var context_id: int = c.pending.id
	var shots = fight(b)
	check(b.finished and shots > 0, "A campaign battle plays to completion with real simulation and AI")
	var result: int = b.winner
	var expected_roster: int = b.campaign_survivors(0).size()
	check(c.resolve_battle(context_id, result, b.campaign_survivors(0), b.campaign_survivors(1)), "Actual completed battle commits back to campaign")
	check(c.phase == "player" and c.pending.is_empty(), "Committed battle returns strategic control")
	check(c.regions[12].owner == (0 if result == 0 else -1), "Actual battle outcome determines province ownership")
	if not c.army(0).is_empty(): check(c.army(0).roster.size() == expected_roster, "Actual battle survivors become the strategic army")
	check(TheaterCampaign.new().restore(JSON.parse_string(JSON.stringify(c.snapshot()))), "Actual post-battle campaign state remains saveable")
	print("CAMPAIGN BATTLE elapsed=%.1f winner=%d shots=%d survivors=%d" % [b.elapsed, result, shots, expected_roster])
	b.free()
	print("THEATER BATTLE TESTS: %d assertions, %d failures" % [assertions, failures])
	quit(0 if failures == 0 else 1)
