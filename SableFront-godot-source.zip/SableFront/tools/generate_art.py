"""Original Sable Front unit atlas and ground material. Requires Pillow."""
from pathlib import Path
from PIL import Image, ImageDraw, ImageFilter
import random

ROOT = Path(__file__).resolve().parents[1] / 'assets'
ROOT.mkdir(exist_ok=True)
N = 128
AA = 3
KINDS = ['rifle', 'assault', 'support', 'engineer', 'armor', 'medic', 'recon', 'sniper', 'mortar', 'atgun', 'tank', 'flame', 'mortar_weapon', 'atgun_weapon']
atlas = Image.new('RGBA', (N * len(KINDS), N * 2))


def draw_sprite(kind, team):
    im = Image.new('RGBA', (N * AA, N * AA))
    d = ImageDraw.Draw(im)
    cloth = '#71866a' if team == 0 else '#967961'
    light = '#a0ac83' if team == 0 else '#bca080'
    helmet = '#4a6551' if team == 0 else '#6c5949'
    stripe = '#83bdb2' if team == 0 else '#c58568'
    dark = '#27372d'

    def rect(box, fill, radius=0):
        box = tuple(round(v * AA) for v in box)
        if radius:
            d.rounded_rectangle(box, radius=radius * AA, fill=fill)
        else:
            d.rectangle(box, fill=fill)

    def ellipse(box, fill):
        d.ellipse(tuple(round(v * AA) for v in box), fill=fill)

    def line(points, fill, width):
        d.line([(int(x * AA), int(y * AA)) for x, y in points], fill=fill, width=int(width * AA))

    if kind in ['armor', 'tank']:
        rect((19, 24, 103, 103), '#17251d', 10)
        rect((22, 28, 102, 43), '#303a2e', 4)
        rect((22, 85, 102, 100), '#303a2e', 4)
        for x in range(26, 100, 8):
            line([(x, 29), (x, 41)], '#71755e', 3)
            line([(x, 87), (x, 98)], '#71755e', 3)
        rect((24, 43, 104, 86), cloth, 7)
        rect((30, 44, 95, 50), light, 2)
        rect((32, 54, 56, 79), '#475c46', 3)
        rect((33, 57, 37, 75), light)
        if kind == 'tank':
            rect((48, 48, 93, 81), '#3e5845', 9)
            rect((53, 50, 86, 56), light, 3)
            line([(79, 64), (125, 64)], '#27392e', 8)
            line([(82, 62), (122, 62)], '#a1ab84', 3)
            ellipse((59, 55, 76, 72), helmet)
            ellipse((61, 56, 71, 65), light)
        else:
            rect((70, 47, 95, 82), '#475d4d', 3)
            rect((77, 52, 93, 57), '#c3c2a1')
            rect((77, 72, 93, 77), '#c3c2a1')
            line([(65, 62), (112, 62)], '#263e32', 4)
        rect((26, 53, 33, 78), stripe, 1)
        for x, y in [(36, 47), (96, 47), (36, 82), (96, 82)]:
            ellipse((x - 1, y - 1, x + 1, y + 1), '#d5ccb0')
    elif kind == 'mortar_weapon':
        ellipse((32, 38, 92, 98), '#394b3b')
        ellipse((38, 44, 86, 92), '#6e7862')
        line([(61, 66), (106, 35)], dark, 15)
        line([(60, 62), (106, 31)], '#a4ae8c', 9)
        ellipse((99, 27, 113, 40), '#22382a')
        line([(63, 61), (40, 103)], '#a4aa83', 5)
        line([(63, 61), (96, 105)], '#8d9878', 5)
    elif kind == 'atgun_weapon':
        line([(39, 60), (115, 60)], '#26382e', 14)
        line([(37, 56), (119, 56)], light, 7)
        rect((46, 37, 71, 90), cloth, 4)
        rect((48, 39, 54, 87), light)
        ellipse((35, 27, 57, 49), '#23352a')
        ellipse((35, 80, 57, 102), '#23352a')
        ellipse((41, 32, 51, 43), '#9eab83')
        ellipse((41, 85, 51, 96), '#9eab83')
        line([(42, 61), (11, 27)], '#5c7359', 6)
        line([(42, 61), (11, 102)], '#5c7359', 6)
    else:
        # Top-down infantry silhouette, oriented east. Equipment distinguishes roles.
        rect((39, 40, 62, 51), '#283b2e', 4)
        rect((36, 76, 64, 88), '#25382d', 4)
        rect((34, 40, 44, 53), '#1b2d23', 4)
        rect((32, 76, 43, 89), '#1b2d23', 4)
        ellipse((44, 36, 79, 91), cloth)
        ellipse((44, 39, 62, 84), light)
        rect((44, 47, 56, 78), helmet, 4)
        rect((46, 49, 50, 76), light, 2)
        ellipse((56, 39, 75, 52), '#c1b38b')
        ellipse((62, 76, 83, 89), '#c1b38b')
        line([(67, 48), (84, 57), (95, 58)], cloth, 9)
        line([(69, 82), (83, 72), (94, 65)], cloth, 9)
        line([(82, 64), (113 if kind != 'sniper' else 125, 64)], dark, 5 if kind != 'support' else 8)
        rect((79, 60, 95, 69), '#7d7050', 2)
        ellipse((62, 48, 84, 79), '#2e4634')
        ellipse((63, 46, 84, 73), helmet)
        ellipse((63, 47, 78, 66), light)
        line([(62, 70), (79, 70)], helmet, 3)
        rect((54, 41, 59, 49), stripe, 1)
        if kind == 'medic':
            rect((41, 50, 58, 78), '#e4dfc8', 3)
            rect((47, 54, 52, 74), '#bd6f59')
            rect((43, 61, 56, 66), '#bd6f59')
        elif kind == 'engineer':
            line([(41, 45), (52, 84)], '#d1c6a0', 3)
            line([(37, 48), (53, 43)], '#383b2d', 5)
        elif kind == 'sniper':
            ellipse((58, 43, 82, 77), '#63774e')
            line([(92, 58), (105, 58)], '#253c2e', 5)
        elif kind == 'recon':
            rect((43, 48, 60, 81), '#3d5b48', 5)
            line([(48, 49), (44, 24)], dark, 2)
        elif kind == 'flame':
            ellipse((40, 49, 54, 78), '#aa8757')
            ellipse((49, 49, 62, 78), '#cab17e')
            line([(53, 75), (77, 78), (95, 66)], '#4e4933', 4)
            ellipse((110, 60, 121, 68), '#de9e51')
        elif kind == 'support':
            rect((90, 55, 98, 74), '#55664c')
            line([(105, 64), (113, 78)], dark, 2)
    shadow = im.getchannel('A').filter(ImageFilter.GaussianBlur(3 * AA))
    silhouette = Image.new('RGBA', im.size, '#0b2116')
    silhouette.putalpha(shadow.point(lambda v: int(v * 0.38)))
    combined = Image.new('RGBA', im.size)
    combined.alpha_composite(silhouette, (4 * AA, 6 * AA))
    combined.alpha_composite(im)
    return combined.resize((N, N), Image.Resampling.LANCZOS)


for team in range(2):
    for index, kind in enumerate(KINDS):
        atlas.alpha_composite(draw_sprite(kind, team), (index * N, team * N))
atlas.save(ROOT / 'unit_atlas.png')
rng = random.Random(8247)
grain = Image.new('RGBA', (512, 512))
grain.putdata([(rng.randrange(115, 235),) * 3 + (255,) for _ in range(512 * 512)])
grain = grain.filter(ImageFilter.GaussianBlur(0.45))
grain.save(ROOT / 'terrain_grain.png')
print('Generated original unit atlas and ground material.')
