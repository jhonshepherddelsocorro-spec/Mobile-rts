"""Generate Sable Front's original PCM sound effects. Python standard library only."""
from pathlib import Path
import math
import random
import struct
import wave

DEST = Path(__file__).resolve().parents[1] / "assets" / "audio"
DEST.mkdir(parents=True, exist_ok=True)
RATE = 22050
rng = random.Random(2026)


def save(name, seconds, sample):
    values = []
    previous = 0.0
    for i in range(int(RATE * seconds)):
        t = i / RATE
        noise = rng.uniform(-1, 1)
        previous = previous * 0.92 + noise * 0.08
        v = max(-1, min(1, sample(t, noise, previous)))
        values.append(int(v * 28000))
    with wave.open(str(DEST / f"{name}.wav"), "wb") as f:
        f.setparams((1, 2, RATE, len(values), "NONE", "not compressed"))
        f.writeframes(struct.pack(f"<{len(values)}h", *values))


save("rifle", 0.22, lambda t, n, p: (n * 0.7 + math.sin(t * 1900) * 0.3) * math.exp(-t * 42))
save("cannon", 0.6, lambda t, n, p: (p * 2.5 + math.sin(t * 370 - t * t * 160) * 0.5) * math.exp(-t * 9))
save("blast", 0.9, lambda t, n, p: (p * 3 + math.sin(t * 260) * 0.35) * math.exp(-t * 5.5))
notes = [440, 554.36, 659.25, 880]
save("capture", 0.65, lambda t, n, p: math.sin(t * math.tau * notes[min(3, int(t / 0.13))]) * 0.3 * math.exp(-(t % 0.13) * 18) * min(1, (0.65 - t) * 12))
save("wind", 8, lambda t, n, p: p * 1.1 * (0.4 + math.sin(t * math.tau / 8) ** 2 * 0.25) * min(1, t * 3, (8 - t) * 3))
print("Generated five original sound effects in", DEST)
