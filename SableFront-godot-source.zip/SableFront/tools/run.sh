#!/usr/bin/env bash
set -euo pipefail
project_dir=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
# Keep editor caches and local saves writable in restricted cloud workspaces.
export XDG_DATA_HOME="${XDG_DATA_HOME:-$project_dir/.local/share}"
export XDG_CACHE_HOME="${XDG_CACHE_HOME:-$project_dir/.local/cache}"
export XDG_CONFIG_HOME="${XDG_CONFIG_HOME:-$project_dir/.local/config}"
mkdir -p "$XDG_DATA_HOME" "$XDG_CACHE_HOME" "$XDG_CONFIG_HOME"
exec godot --path "$project_dir" "$@"
